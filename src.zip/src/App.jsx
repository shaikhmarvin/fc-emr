import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "./lib/supabase";
import { createPatientInSupabase, updatePatientInSupabase } from "./api/patients";
import {
  parseLabsFromText,
  extractPatientNameFromLabText as extractPatientNameFromLabTextFromParser,
  formatPatientName,
} from "./lib/labParser";
import * as pdfjsLib from "pdfjs-dist";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

window.testLabParser = parseLabsFromText;
import LabImportView from "./components/LabImportView";
import LabQueueView from "./components/LabQueueView";
import {
  createEncounterInSupabase,
  updateEncounterInSupabase,
  createMedicationInSupabase,
  updateMedicationInSupabase,
  deleteMedicationInSupabase,
  deleteEncounterInSupabase,
  createRefillRequest,
  fetchRefillRequests,
  approveRefillRequestInSupabase,
  deleteRefillRequestInSupabase,
  deleteRefillRequestsForPatient,
} from "./api/encounters";
import {
  fetchStaffRoster,
  saveStaffRoster,
} from "./api/clinicStaffRoster";
import { useAuthSession } from "./hooks/useAuthSession";
import { useClinicData } from "./hooks/useClinicData";
import {
  fetchClinicResourceSettings,
  updateClinicResourceSetting,
} from "./api/clinicResourceSettings";
import ToastStack from "./components/ToastStack";
import { canStartIntake, canManageRoomBoard, canEditFormulary, canPrescribe, canChart, canUseLabQueue, } from "./utils/permissions";
import { fetchProfiles, updateProfileRole, updateProfileDetails } from "./api/profiles";
import { createAuditLog, fetchAuditLogForEncounter } from "./api/audit";
import { sendPasswordReset } from "./api/auth";
import PatientSearch from "./components/PatientSearch";
import PatientTable from "./components/PatientTable";
import PatientInfoEditModal from "./components/PatientInfoEditModal";
import { deletePatientInSupabase } from "./api/patients";
import QueueView from "./components/QueueView";
import RoomBoard from "./components/RoomBoard";
import MedicationModal from "./components/MedicationModal";
import { createAllergyInSupabase, updateAllergyInSupabase, deleteAllergyInSupabase, } from "./api/allergies";
import AllergyModal from "./components/AllergyModal";
import IntakeModal from "./components/IntakeModal";
import UndergradIntakeView from "./components/UndergradIntakeView";
import RegistrationView from "./components/RegistrationView";
import SpecialtyQueueView from "./components/SpecialtyQueueView";
import UndergradRegistrationModal from "./components/UndergradRegistrationModal";
import ChartView from "./components/ChartView";
import BoardDisplay from "./components/BoardDisplay";
import {
  fetchFormularyItems,
  createFormularyItemInSupabase,
  updateFormularyItemInSupabase,
  deleteFormularyItemInSupabase,
} from "./api/formulary";
import FormularyView from "./components/FormularyView";
import AppSidebar from "./components/AppSidebar";
import UserManagementView from "./components/UserManagementView";
import AppHeader from "./components/AppHeader";
import DashboardView from "./components/DashboardView";
import ClinicSummaryView from "./components/ClinicSummaryView";
import ProgramsView from "./components/ProgramsView";
import { fetchProgramSettings } from "./api/programSettings";
import PAPView from "./components/PAPView";
import {
  fetchProgramEntries,
  createProgramEntryInSupabase,
  updateProgramEntryInSupabase,
  deleteProgramEntryInSupabase,
  deleteProgramEntriesForPatient,
} from "./api/programs";
import {
  fetchPapEntries,
  createPapEntryInSupabase,
  updatePapEntryInSupabase,
  deletePapEntryInSupabase,
  deletePapEntriesForPatient,
} from "./api/pap";
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
  AlignmentType,
} from "docx";
import { saveAs } from "file-saver";
import {
  ROOM_OPTIONS,
  EMPTY_FORM,
  EMPTY_VITALS,
  EMPTY_MEDICATION,
  EMPTY_SEARCH,
  PT_TIME_SLOTS,
  PROGRAM_TYPES,
  PROGRAM_STATUSES,
  VISIT_TYPE_BADGE_STYLES,
} from "./constants";
import {
  calculateAge,
  getPatientBoardName,
  getFullPatientName,
  getStudentBoardName,
  formatWaitTime,
  isPapRestricted,
  getStatusClasses,
  calculateBmi,
  normalizeBp,
  normalizePain,
  normalizeHeight,
  createEncounterFromIntake,
  formatDate,
  formatClinicDate,
  normalizeClinicDate,
  canAssignRoom,
  mapDbStatusToUi,
  findPotentialDuplicatePatient,
  patientMatchesSearch,
  mrnExists,
  sortEncountersByDate,
} from "./utils";

function newReturningBadge(encounter) {
  const value = String(encounter?.newReturning || encounter?.new_returning || "").trim().toLowerCase();

  if (value === "new") {
    return (
      <span className="rounded-full bg-emerald-100 px-2 py-1 text-xs font-semibold text-emerald-700">
        New
      </span>
    );
  }

  if (value === "returning") {
    return (
      <span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-700">
        Returning
      </span>
    );
  }

  return null;
}

function getDailyVisitNumber(row) {
  const patient = row?.patient || {};
  const encounter = row?.encounter || {};

  // This is the temporary number on the paper card for today's clinic.
  // MRN is intentionally NOT used because it gets added later.
  const candidates = [
    encounter.dailyNumber, encounter.daily_number,
    encounter.cardNumber, encounter.card_number,
    encounter.queueNumber, encounter.queue_number,
    encounter.visitNumber, encounter.visit_number,
    encounter.registrationNumber, encounter.registration_number,
    encounter.patientNumber, encounter.patient_number,
    patient.dailyNumber, patient.daily_number,
    patient.cardNumber, patient.card_number,
    patient.queueNumber, patient.queue_number,
    patient.visitNumber, patient.visit_number,
    patient.registrationNumber, patient.registration_number,
    patient.patientNumber, patient.patient_number,
  ];

  for (const value of candidates) {
    const match = String(value || "").match(/\d+/);
    if (match) return Number(match[0]);
  }

  return Number.POSITIVE_INFINITY;
}

function sortRowsByDailyNumberThenTime(a, b) {
  const aNumber = getDailyVisitNumber(a);
  const bNumber = getDailyVisitNumber(b);

  if (aNumber !== bNumber) return aNumber - bNumber;

  const aTime = new Date(a?.encounter?.createdAt || 0).getTime();
  const bTime = new Date(b?.encounter?.createdAt || 0).getTime();
  return aTime - bTime;
}

function getEncounterIntakeValue(encounter, ...keys) {
  const intakeData = encounter?.intakeData || encounter?.intake_data || {};

  for (const key of keys) {
    if (encounter?.[key] !== undefined && encounter?.[key] !== null && encounter?.[key] !== "") {
      return encounter[key];
    }

    if (intakeData?.[key] !== undefined && intakeData?.[key] !== null && intakeData?.[key] !== "") {
      return intakeData[key];
    }
  }

  return undefined;
}

function priorityBadge(encounter) {
  const transportation = getEncounterIntakeValue(encounter, "transportation");

  if (transportation === "Bus/Public Transport") {
    return (
      <span className="rounded-full bg-red-100 px-2 py-1 text-xs font-semibold text-red-700">
        Bus Priority
      </span>
    );
  }

  return null;
}

function spanishBadge(encounter) {
  const spanishSpeaking = getEncounterIntakeValue(encounter, "spanishSpeaking");

  if (spanishSpeaking === true || spanishSpeaking === "true" || spanishSpeaking === "Yes") {
    return (
      <span className="rounded-full bg-blue-100 px-2 py-1 text-xs font-semibold text-blue-700">
        Spanish
      </span>
    );
  }

  return null;
}

function htnBadge(encounter) {
  const hasHTN = getEncounterIntakeValue(encounter, "htn");

  if (hasHTN === true || hasHTN === "true" || hasHTN === "Yes") {
    return (
      <span className="rounded-full bg-rose-100 px-2 py-1 text-xs font-semibold text-rose-700">
        HTN
      </span>
    );
  }

  return null;
}

function diabetesBadge(encounter) {
  const hasDM = getEncounterIntakeValue(encounter, "dm");

  if (hasDM === true || hasDM === "true" || hasDM === "Yes") {
    return (
      <span className="rounded-full bg-orange-100 px-2 py-1 text-xs font-semibold text-orange-700">
        DM
      </span>
    );
  }

  return null;
}

function fluBadge(encounter) {
  const fluShot = getEncounterIntakeValue(encounter, "fluShot");

  if (fluShot === "Interested" || fluShot === "Yes") {
    return (
      <span className="rounded-full bg-cyan-100 px-2 py-1 text-xs font-semibold text-cyan-700">
        Flu
      </span>
    );
  }

  return null;
}

function elevatorBadge(encounter) {
  const needsElevator = getEncounterIntakeValue(encounter, "needsElevator");

  if (needsElevator === true || needsElevator === "true" || needsElevator === "Yes") {
    return (
      <span className="rounded-full bg-purple-100 px-2 py-1 text-xs font-semibold text-purple-700">
        Elevator
      </span>
    );
  }

  return null;
}

function papBadge(encounter) {
  const papStatus = getEncounterIntakeValue(encounter, "papStatus");

  if (papStatus === "Interested") {
    return (
      <span className="rounded-full bg-pink-100 px-2 py-1 text-xs font-semibold text-pink-700">
        Pap
      </span>
    );
  }

  return null;
}

function dualVisitBadge(encounter) {
  const intakeData = encounter?.intakeData || encounter?.intake_data || {};

  const visitType =
    encounter?.visitType ||
    encounter?.visit_type ||
    intakeData?.visitType ||
    intakeData?.visit_type ||
    "";

  const specialtyType =
    encounter?.specialtyType ||
    encounter?.specialty_type ||
    intakeData?.specialtyType ||
    intakeData?.specialty_type ||
    "";

  const isDualVisit =
    visitType === "both" ||
    encounter?.dualVisit === true ||
    intakeData?.dualVisit === true ||
    (visitType === "general" && Boolean(specialtyType));

  if (!isDualVisit) return null;

  const specialtyMap = {
    dermatology: "Derm",
    derm: "Derm",
    physical_therapy: "PT",
    physicaltherapy: "PT",
    pt: "PT",
    mental_health: "Mental Health",
    mentalhealth: "Mental Health",
    counseling: "Mental Health",
    addiction: "Addiction",
    ophthalmology: "Ophthalmology",
    optometry: "Optometry",
  };

  const specialtyLabel =
    specialtyMap[String(specialtyType).toLowerCase()] ||
    specialtyType ||
    "Specialty";

  return (
    <span className={`rounded-full border px-2 py-1 text-xs font-semibold ${VISIT_TYPE_BADGE_STYLES.both.badgeClass}`}>
      General + {specialtyLabel}
    </span>
  );
}

function pharmacyStatusBadge(encounter) {
  if (encounter?.pharmacyStatus === "meds_ready") {
    return (
      <span className="rounded-full bg-emerald-100 px-2 py-1 text-xs font-semibold text-emerald-800">
        Meds Ready
      </span>
    );
  }

  if (encounter?.pharmacyStatus === "patient_sent") {
    return (
      <span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-700">
        Sent to Pharmacy
      </span>
    );
  }

  if (encounter?.pharmacyStatus === "picked_up") {
    return (
      <span className="rounded-full bg-blue-100 px-2 py-1 text-xs font-semibold text-blue-800">
        Meds Picked Up
      </span>
    );
  }

  if (encounter?.pharmacyStatus === "no_meds_needed") {
    return (
      <span className="rounded-full bg-zinc-100 px-2 py-1 text-xs font-semibold text-zinc-700">
        No Medications Needed
      </span>
    );
  }

  if (encounter?.pharmacyStatus === "meds_not_picked_up") {
    return (
      <span className="rounded-full bg-orange-100 px-2 py-1 text-xs font-semibold text-orange-800">
        Meds Not Picked Up
      </span>
    );
  }

  return null;
}

async function runGoogleOCR(base64Images) {
  const { data, error } = await supabase.functions.invoke("google-ocr", {
    body: { images: base64Images },
  });

  if (error) {
    console.error("OCR error object:", error);

    try {
      const bodyText = await error.context?.text?.();
      console.error("OCR error body:", bodyText);
      throw new Error(bodyText || error.message || "OCR request failed");
    } catch {
      throw new Error(error.message || "OCR request failed");
    }
  }

  return data?.texts || [];
}

async function runGoogleOCRInChunks(base64Images = [], chunkSize = 16) {
  const allTexts = [];

  for (let i = 0; i < base64Images.length; i += chunkSize) {
    const chunk = base64Images.slice(i, i + chunkSize);
    const texts = await runGoogleOCR(chunk);
    allTexts.push(...(texts || []));
  }

  return allTexts;
}


function getLocalDateInputValue(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function computeLabCounts(labs = []) {
  let missing_count = 0;
  let autofilled_count = 0;
  let needs_review_count = 0;

  labs.forEach((lab) => {
    const isMissing = lab.missing === true || lab.value == null || lab.value === "";
    const isAutofilled = lab.autoFilled === true;

    const isSuspicious =
      lab.suspicious === true ||
      lab.duplicateType === "same_encounter" ||
      lab.duplicateType === "recent";

    if (isMissing) missing_count++;
    if (isAutofilled) autofilled_count++;
    if (isSuspicious || isMissing) needs_review_count++;
  });

  return {
    missing_count,
    autofilled_count,
    needs_review_count,
  };
}

function categorizeLabsForExport(labs = []) {
  const trueMissingLabs = [];
  const panelPlaceholders = [];
  const suspiciousLabs = [];

  labs.forEach((lab) => {
    const isMissing = lab.missing === true || lab.value == null || lab.value === "";
    const isAutofilled = lab.autoFilled === true;

    const isSuspicious =
      lab.suspicious === true ||
      lab.duplicateType === "same_encounter" ||
      lab.duplicateType === "recent";

    // 🔴 TRUE missing (should exist but no value)
    if (isMissing && !isAutofilled) {
      trueMissingLabs.push(lab);
    }

    // ⚪ panel placeholders (expected but intentionally blank)
    if (isMissing && isAutofilled) {
      panelPlaceholders.push(lab);
    }

    // 🟡 suspicious
    if (isSuspicious) {
      suspiciousLabs.push(lab);
    }
  });

  return {
    trueMissingLabs,
    panelPlaceholders,
    suspiciousLabs,
  };
}

export default function App() {
  async function testSupabaseConnection() {
    const { error } = await supabase.from("patients").select("*").limit(1);

    if (error) {
      console.error(error);
      showToast({
        title: "Supabase error",
        message: error.message,
        type: "error",
      });
    } else {
      showToast({
        title: "Connection works",
        message: "Supabase is reachable.",
        type: "success",
      });
    }
  }

  const [toasts, setToasts] = useState([]);

  function dismissToast(toastId) {
    setToasts((prev) => prev.filter((toast) => toast.id !== toastId));
  }

  function showToast({
    title = "Notice",
    message = "",
    type = "info",
    duration = 3500,
    onClick = null,
    actionLabel = "",
  }) {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

    setToasts((prev) => [
      ...prev,
      { id, title, message, type, onClick, actionLabel },
    ]);

    if (duration > 0) {
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((toast) => toast.id !== id));
      }, duration);
    }
  }

  const {
    session,
    userRole,
    authReady,
    isLeadershipView,
    authEmail,
    setAuthEmail,
    authPassword,
    setAuthPassword,
    authFullName,
    setAuthFullName,
    authClassification,
    setAuthClassification,
    authLoading,
    authMessage,
    handleSignUp,
    handleSignIn,
    handleSignOut,
    handleResetSession,
    needsOnboarding,
    onboardingFullName,
    setOnboardingFullName,
    onboardingClassification,
    setOnboardingClassification,
    handleCompleteOnboarding,
    authRole,
    setAuthRole,
    authPin,
    setAuthPin,
    authPinConfirm,
    setAuthPinConfirm,
    canRefillAccess,
  } = useAuthSession();

  useEffect(() => {
    if (!session?.user?.id) return;

    async function updateLastSeen() {
      try {
        await supabase
          .from("profiles")
          .update({ last_seen_at: new Date().toISOString() })
          .eq("id", session.user.id);

        await loadProfiles(); // refresh UI immediately
      } catch (err) {
        console.error("Failed to update last_seen_at:", err);
      }
    }

    updateLastSeen();
  }, [session]);

  async function addFormularyItem(itemForm) {
    try {
      const saved = await createFormularyItemInSupabase(itemForm);
      setFormulary((prev) => [saved, ...prev]);
    } catch (error) {
      console.error("Failed to add formulary item:", error);
      alert(error.message);
    }
  }

  async function editFormularyItem(itemId, itemForm) {
    try {
      const saved = await updateFormularyItemInSupabase(itemId, itemForm);
      setFormulary((prev) =>
        prev.map((item) => (item.id === itemId ? saved : item))
      );
    } catch (error) {
      console.error("Failed to update formulary item:", error);
      alert(error.message);
    }
  }

  async function removeFormularyItem(itemId) {
    try {
      await deleteFormularyItemInSupabase(itemId);
      setFormulary((prev) => prev.filter((item) => item.id !== itemId));
    } catch (error) {
      console.error("Failed to delete formulary item:", error);
      alert(error.message);
    }
  }

  async function toggleFormularyStock(itemId) {
    const item = formulary.find((entry) => entry.id === itemId);
    if (!item) return;

    try {
      const saved = await updateFormularyItemInSupabase(itemId, {
        inStock: !item.inStock,
      });

      setFormulary((prev) =>
        prev.map((entry) => (entry.id === itemId ? saved : entry))
      );
    } catch (error) {
      console.error("Failed to toggle stock:", error);
      alert(error.message);
    }
  }

  useEffect(() => {
    if (!session?.user?.id) return;

    const interval = setInterval(async () => {
      await supabase
        .from("profiles")
        .update({ last_seen_at: new Date().toISOString() })
        .eq("id", session.user.id);
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [session]);

  const canOpenIntake = canStartIntake(userRole);
  const canManageRooms = canManageRoomBoard(userRole);
  const canModifyFormulary = canEditFormulary(userRole);
  const canPrescribeMeds = canPrescribe(userRole);
  const canChartInEncounter = canChart(userRole);
  const isLeadership = userRole === "leadership";
  const [authMode, setAuthMode] = useState("login");
  const [showPatientInfoEditModal, setShowPatientInfoEditModal] = useState(false);
  const [dashboardSelectedPatientId, setDashboardSelectedPatientId] = useState(null);
  const [formulary, setFormulary] = useState([]);
  const [formularyLoaded, setFormularyLoaded] = useState(false);

  function getNextSoapStatus(authorRole) {
    if (authorRole === "student" || authorRole === "leadership") {
      return "awaiting_upper";
    }

    if (authorRole === "upper_level") {
      return "awaiting_attending";
    }

    if (authorRole === "attending") {
      return "signed";
    }

    return "draft";
  }

  function canUpperLevelSignSoap(role, encounter) {
    if (role !== "upper_level") return false;
    return encounter?.soapStatus === "awaiting_upper";
  }

  function canSubmitSoapForUpperLevel(role, encounter) {
    if (!encounter) return false;
    return (
      (role === "student" || role === "leadership") &&
      (encounter.soapStatus === "draft" || !encounter.soapStatus)
    );
  }

  function canSubmitSoapForAttending(role, encounter) {
    if (!encounter) return false;

    const isDraft = encounter.soapStatus === "draft" || !encounter.soapStatus;
    const skipUpperApproved = !!encounter.skipUpperLevel;

    return (
      (role === "upper_level" && isDraft) ||
      ((role === "student" || role === "leadership") && isDraft && skipUpperApproved)
    );
  }

  function canAttendingSignSoap(role, encounter) {
    if (!encounter) return false;

    const allowedRole =
      role === "student" ||
      role === "upper_level" ||
      role === "leadership" ||
      role === "attending";

    if (!allowedRole || !!encounter.attendingSignedAt) return false;

    return encounter.soapStatus === "awaiting_attending";
  }

  function formatRoleLabel(role) {
    switch (role) {
      case "student":
        return "Student";
      case "upper_level":
        return "Upper Level";
      case "attending":
        return "Attending";
      case "leadership":
        return "Leadership";
      default:
        return role || "Unknown";
    }
  }

  function getMissingSoapFields(source, encounter = selectedEncounter) {
    if (!source) return [];

    const isOphthoEncounter =
      encounter?.specialtyType === "ophthalmology";

    if (isOphthoEncounter) {
      const ophtho = {
        ...EMPTY_OPHTHO_NOTE,
        ...(source.ophthalmologyNote || {}),
      };

      const missing = [];

      if (!(ophtho.hpi || "").trim()) missing.push("Chief Complaint & HPI");
      if (!(ophtho.ocularHistory || "").trim()) missing.push("Medical / Ocular History");
      if (!(ophtho.assessment || "").trim()) missing.push("Assessment");
      if (!(ophtho.plan || "").trim()) missing.push("Plan");

      return missing;
    }

    const missing = [];

    if (!(source.soapSubjective || "").trim()) missing.push("Subjective");
    if (!(source.soapObjective || "").trim()) missing.push("Objective");
    if (!(source.soapAssessment || "").trim()) missing.push("Assessment");
    if (!(source.soapPlan || "").trim()) missing.push("Plan");

    return missing;
  }

  function showSoapMessage(message) {
    setSoapUiMessage(message);
    window.clearTimeout(window.__soapMessageTimeout);
    window.__soapMessageTimeout = window.setTimeout(() => {
      setSoapUiMessage("");
    }, 2500);
  }

  async function logAuditEvent(action, details = {}) {
    if (!selectedEncounter || !selectedPatient || !session?.user?.id) return;

    try {
      await createAuditLog({
        encounterId: selectedEncounter.id,
        patientId: selectedPatient.id,
        actorUserId: session.user.id,
        actorName: profileNameMap[session.user.id] || authFullName || "Unknown User",
        actorRole: userRole || "",
        action,
        details,
      });
    } catch (error) {
      console.error("Failed to write audit log:", error);
    }
  }

  async function loadAuditLog() {
    if (!selectedEncounter?.id) {
      setAuditEntries([]);
      return;
    }

    try {
      setAuditLoading(true);
      const rows = await fetchAuditLogForEncounter(selectedEncounter.id);
      setAuditEntries(rows);
    } catch (error) {
      console.error("Failed to load audit log:", error);
      setAuditEntries([]);
    } finally {
      setAuditLoading(false);
    }
  }

  function setIsLeadershipView() {
    // no-op now that role comes from auth
  }

  const EMPTY_UNDERGRAD_REGISTRATION_FORM = {
    firstName: "",
    lastName: "",
    dob: "",
    mrn: "",
    addressLine1: "",
    city: "",
    state: "",
    zipCode: "",
    emergencyContactName: "",
    emergencyContactRelation: "",
    emergencyContactPhone: "",
    last4Ssn: "",
    incomeRange: "",
    spanishOnly: "",
    chronicConditions: [],
    chronicConditionsOther: "",
    dailyNumber: "",
    refillNumber: "",
    visitType: "general",
    specialtyType: "",
    refillMedicationRequest: "",
  };

  const [showUndergradRegistrationModal, setShowUndergradRegistrationModal] = useState(false);
  const [undergradRegistrationForm, setUndergradRegistrationForm] = useState(
    EMPTY_UNDERGRAD_REGISTRATION_FORM
  );
  const [registrationPatientId, setRegistrationPatientId] = useState(null);
  const [registrationEncounterId, setRegistrationEncounterId] = useState(null);

  const [activeView, setActiveView] = useState(() => {
    return window.localStorage.getItem("active-view") || "dashboard";
  });
  const [pharmacyToast, setPharmacyToast] = useState(null);
  const [lastPharmacyToastKey, setLastPharmacyToastKey] = useState("");

  useEffect(() => {
    if (!userRole) return;

    if (userRole === "undergraduate") {
      setActiveView("undergrad-intake");
      return;
    }

    if (userRole === "pharmacy") {
      setActiveView("pharmacy-queue");
      return;
    }

    if (userRole === "social_work") {
      setActiveView("queue");
      return;
    }

    if (userRole === "lab") {
      setActiveView("lab-queue");
      return;
    }

    if (
      userRole === "student" ||
      userRole === "upper_level" ||
      userRole === "attending"
    ) {
      setActiveView("queue");
      return;
    }

    // Leadership should keep whatever page was saved in localStorage.
  }, [userRole]);

  useEffect(() => {
    if (!activeView) return;

    window.localStorage.setItem("active-view", activeView);
  }, [activeView]);

  const canLabQueueAccess = canUseLabQueue(userRole);
  const canRefill = canRefillAccess || userRole === "attending" || userRole === "leadership";
  const canAccessDashboard =
    userRole === "leadership" ||
    userRole === "undergraduate" ||
    userRole === "upper_level" ||
    userRole === "attending" ||
    canRefill;


  const [clinicSummary, setClinicSummary] = useState({
    refillCount: "",
    labsCount: "",
    mentalHealthCount: "",
    addictionMedicineCount: "",
    ptCount: "",
    dermatologyCount: "",
    socialWorkCount: "",
    ophthalmologyCount: "",
    lwobsCount: "",
    zoomCount: "",
    phoneCount: "",
    attendingNames: "",
    residentNames: "",
    ms34Names: "",
    ms12Names: "",
  });

  const [summaryRefreshStatus, setSummaryRefreshStatus] = useState("");
  const [programEntries, setProgramEntries] = useState([]);
  const [programsLoaded, setProgramsLoaded] = useState(false);
  const [programSettings, setProgramSettings] = useState([]);
  const [clinicResourceSettings, setClinicResourceSettings] = useState([]);
  const [clinicResourceSettingsLoaded, setClinicResourceSettingsLoaded] = useState(false);
  const todayIso = formatClinicDate();

  const tonightSpecialtyPrograms = useMemo(() => {
    return (programSettings || []).filter(
      (program) =>
        program?.next_specialty_date &&
        String(program.next_specialty_date).slice(0, 10) === todayIso
    );
  }, [programSettings, todayIso]);

  const tonightSpecialtyNames = tonightSpecialtyPrograms.map(
    (program) => program.program_type
  );

  const tonightReservedRooms = tonightSpecialtyPrograms.flatMap((program) =>
    (program.rooms_assigned?.rooms || []).map((roomNumber) => ({
      roomNumber: String(roomNumber),
      specialty: program.program_type,
    }))
  );


  const [papEntries, setPapEntries] = useState([]);
  const [papLoaded, setPapLoaded] = useState(false);


  useEffect(() => {
    if (!session || clinicResourceSettingsLoaded) return;

    async function loadClinicResourceSettings() {
      try {
        const rows = await fetchClinicResourceSettings();
        setClinicResourceSettings(rows || []);
        setClinicResourceSettingsLoaded(true);
      } catch (error) {
        console.error("Failed to load clinic resource settings:", error);
        showToast({
          title: "Settings error",
          message: "Unable to load intake resource settings.",
          type: "error",
        });
      }
    }

    loadClinicResourceSettings();
  }, [session, clinicResourceSettingsLoaded]);

  useEffect(() => {
    if (!session || papLoaded) return;

    async function loadPapEntries() {
      try {
        const rows = await fetchPapEntries();
        setPapEntries(rows);
        setPapLoaded(true);
      } catch (error) {
        console.error("Failed to load PAP entries:", error);
      }
    }

    loadPapEntries();
  }, [session, papLoaded]);

  useEffect(() => {
    if (!session || programsLoaded) return;

    async function loadProgramEntries() {
      try {
        const rows = await fetchProgramEntries();
        setProgramEntries(rows);
        setProgramsLoaded(true);
      } catch (error) {
        console.error("Failed to load program entries:", error);
      }
    }

    loadProgramEntries();
  }, [session, programsLoaded]);

  useEffect(() => {
    if (!session) return;

    async function loadProgramSettingsForBoard() {
      try {
        const rows = await fetchProgramSettings();
        setProgramSettings(rows || []);
      } catch (error) {
        console.error("Failed to load program settings:", error);
      }
    }

    loadProgramSettingsForBoard();
  }, [session]);


  async function addProgramEntry(entry) {
    setProgramEntries((prev) => [entry, ...prev]);

    try {
      const saved = await createProgramEntryInSupabase(entry);

      setProgramEntries((prev) =>
        prev.map((item) => (item.id === entry.id ? saved : item))
      );
    } catch (error) {
      console.error("Failed to create program entry:", error);
      alert(`Failed to save program entry: ${error.message}`);

      setProgramEntries((prev) => prev.filter((item) => item.id !== entry.id));
    }
  }

  async function updateProgramEntry(entryId, field, value) {
    const previousEntries = [...programEntries];

    setProgramEntries((prev) =>
      prev.map((entry) =>
        entry.id === entryId ? { ...entry, [field]: value } : entry
      )
    );

    try {
      const saved = await updateProgramEntryInSupabase(entryId, { [field]: value });

      setProgramEntries((prev) =>
        prev.map((entry) => (entry.id === entryId ? saved : entry))
      );
    } catch (error) {
      console.error("Failed to update program entry:", error);
      alert(`Failed to update program entry: ${error.message}`);
      setProgramEntries(previousEntries);
    }
  }

  async function removeProgramEntry(entryId) {
    const previousEntries = [...programEntries];

    setProgramEntries((prev) => prev.filter((entry) => entry.id !== entryId));

    try {
      await deleteProgramEntryInSupabase(entryId);
    } catch (error) {
      console.error("Failed to delete program entry:", error);
      alert(`Failed to delete program entry: ${error.message}`);
      setProgramEntries(previousEntries);
    }
  }

  async function addPapEntry(entry) {
    setPapEntries((prev) => [entry, ...prev]);

    try {
      const saved = await createPapEntryInSupabase(entry);

      setPapEntries((prev) =>
        prev.map((item) => (item.id === entry.id ? saved : item))
      );
    } catch (error) {
      console.error("Failed to create PAP entry:", error);
      alert(`Failed to save PAP entry: ${error.message}`);

      setPapEntries((prev) => prev.filter((item) => item.id !== entry.id));
    }
  }

  async function updatePapEntry(entryId, field, value) {
    const previousEntries = [...papEntries];

    setPapEntries((prev) =>
      prev.map((entry) =>
        entry.id === entryId ? { ...entry, [field]: value } : entry
      )
    );

    try {
      const saved = await updatePapEntryInSupabase(entryId, { [field]: value });

      setPapEntries((prev) =>
        prev.map((entry) => (entry.id === entryId ? saved : entry))
      );
    } catch (error) {
      console.error("Failed to update PAP entry:", error);
      alert(`Failed to update PAP entry: ${error.message}`);
      setPapEntries(previousEntries);
    }
  }

  async function removePapEntry(entryId) {
    const previousEntries = [...papEntries];

    setPapEntries((prev) => prev.filter((entry) => entry.id !== entryId));

    try {
      await deletePapEntryInSupabase(entryId);
    } catch (error) {
      console.error("Failed to delete PAP entry:", error);
      alert(`Failed to delete PAP entry: ${error.message}`);
      setPapEntries(previousEntries);
    }
  }

  useEffect(() => {
    if (!session || formularyLoaded) return;

    async function loadFormulary() {
      try {
        const rows = await fetchFormularyItems();
        console.log("FORMULARY FROM DB:", rows); // debug
        setFormulary(rows);
        setFormularyLoaded(true);
      } catch (error) {
        console.error("Failed to load formulary:", error);
      }
    }

    loadFormulary();
  }, [session, formularyLoaded]);

  async function loadRefillRequests() {
    try {
      const rows = await fetchRefillRequests();
      setRefillRequests(rows);
    } catch (error) {
      console.error("Failed to load refill requests:", error);
    }
  }

  useEffect(() => {
    if (!session) return;
    loadRefillRequests();
  }, [session]);

  async function refreshClinicSummaryData() {
    try {
      setSummaryRefreshStatus("Refreshing...");

      await Promise.all([
        refreshClinicData(),
        loadRefillRequests(),
        loadProfiles(),
      ]);

      setSummaryRefreshStatus("Refreshed");

      setTimeout(() => {
        setSummaryRefreshStatus("");
      }, 2000);
    } catch (error) {
      console.error("Failed to refresh clinic summary:", error);
      setSummaryRefreshStatus("Refresh failed");
      alert(`Failed to refresh clinic summary: ${error.message}`);
    }
  }


  // Formulary realtime disabled to reduce Supabase memory/realtime load.
  // Formulary still loads on sign-in and updates optimistically after saves.

  useEffect(() => {
    if (!session) return;

    const channel = supabase
      .channel("refill-requests-realtime")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "refill_requests",
        },
        (payload) => {
          console.log("REFILL REALTIME:", payload);

          if (payload.eventType === "INSERT") {
            setRefillRequests((prev) => {
              const exists = prev.some((r) => String(r.id) === String(payload.new.id));
              if (exists) return prev;
              return [payload.new, ...prev];
            });
          }

          if (payload.eventType === "UPDATE") {
            setRefillRequests((prev) => {
              let changed = false;

              const updated = prev.map((r) => {
                if (String(r.id) === String(payload.new.id)) {
                  changed = true;
                  return payload.new;
                }
                return r;
              });

              return changed ? updated : prev;
            });
          }

          if (payload.eventType === "DELETE") {
            setRefillRequests((prev) =>
              prev.filter((r) => r.id !== payload.old.id)
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [session]);

  // Global profiles realtime disabled. User Management reloads profiles when opened,
  // and each signed-in user still has their own approval listener in useAuthSession.

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showIntakeModal, setShowIntakeModal] = useState(false);
  const [isSubmittingIntake, setIsSubmittingIntake] = useState(false);
  const isSubmittingIntakeRef = useRef(false);
  const [labImportRawText, setLabImportRawText] = useState("");
  const [labImportPacket, setLabImportPacket] = useState(null);
  const [labImportPackets, setLabImportPackets] = useState([]);
  const [selectedLabImportPacketId, setSelectedLabImportPacketId] = useState(null);
  const [activeLabImportBatchId, setActiveLabImportBatchId] = useState(null);
  const [labImportLoading, setLabImportLoading] = useState(false);
  const [ocrUploading, setOcrUploading] = useState(false);
  const [ocrError, setOcrError] = useState("");
  const [intakeTab, setIntakeTab] = useState(0);
  const [intakeForm, setIntakeForm] = useState(EMPTY_FORM);
  const [searchForm, setSearchForm] = useState(EMPTY_SEARCH);
  const [debouncedSearchForm, setDebouncedSearchForm] = useState(EMPTY_SEARCH);
  const isBoardDisplayMode =
    new URLSearchParams(window.location.search).get("display") === "board";
  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const [selectedEncounterId, setSelectedEncounterId] = useState(null);
  const [todayStaffRoster, setTodayStaffRoster] = useState({
    attendings: "",
    residents: "",
    upperLevels: "",
  });
  const [refillRequests, setRefillRequests] = useState([]);
  const { patients, setPatients, refreshClinicData } = useClinicData({
    authReady,
    session,
    userRole,
  });



  async function saveClinicResourceSetting(resourceKey, updates) {
    const previousSettings = [...clinicResourceSettings];

    setClinicResourceSettings((prev) =>
      prev.map((setting) =>
        setting.resource_key === resourceKey
          ? { ...setting, ...updates }
          : setting
      )
    );

    try {
      const saved = await updateClinicResourceSetting(resourceKey, updates);

      setClinicResourceSettings((prev) =>
        prev.map((setting) =>
          setting.resource_key === resourceKey ? saved : setting
        )
      );
    } catch (error) {
      console.error("Failed to save clinic resource setting:", error);
      setClinicResourceSettings(previousSettings);
      alert(`Failed to save setting: ${error.message}`);
    }
  }

  const dashboardSelectedPatient =
    patients.find((p) => p.id === dashboardSelectedPatientId) || null;


  function normalizeExtractedDate(value = "") {
    const text = String(value || "").trim();
    if (!text) return "";

    // matches 3/4/2026 or 03/04/2026
    const slashMatch = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{2,4})\b/);
    if (slashMatch) {
      let [, month, day, year] = slashMatch;
      if (year.length === 2) {
        year = `20${year}`;
      }

      return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    }

    // already yyyy-mm-dd
    const isoMatch = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) {
      return isoMatch[0];
    }

    return "";
  }

  function extractPatientNameFromLabText(rawText = "") {
    const lines = String(rawText || "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);

    function cleanName(value = "") {
      let cleaned = String(value || "")
        .replace(/\bmedical record number\b.*$/i, "")
        .replace(/\bmrn\b.*$/i, "")
        .replace(/\bdob\b.*$/i, "")
        .replace(/\bage\b.*$/i, "")
        .replace(/\bmale\b.*$/i, "")
        .replace(/\bfemale\b.*$/i, "")
        .replace(/\bsex\b.*$/i, "")
        .replace(/\s+/g, " ")
        .trim();

      if (cleaned.includes(",")) {
        const parts = cleaned.split(",").map((part) => part.trim()).filter(Boolean);
        if (parts.length >= 2) {
          cleaned = `${parts.slice(1).join(" ")} ${parts[0]}`.trim();
        }
      }

      return cleaned;
    }

    function looksLikePersonName(value = "") {
      const text = String(value || "").trim();
      if (!text) return false;
      if (/\d/.test(text)) return false;
      if (
        /(egfr|legend|critical|footnote|corrected abnormal|result symbol|reference range|units|molecular diagnostics|procedure|collected|specimen|reactive|non-reactive|detected|not detected|health system|hospital lab|chemistry|cbc|immunology|hiv screen)/i.test(text)
      ) {
        return false;
      }

      const words = text.split(/\s+/).filter(Boolean);
      if (words.length < 2 || words.length > 4) return false;

      return true;
    }

    for (let i = 0; i < lines.length; i += 1) {
      const compact = lines[i].replace(/\s+/g, " ").trim();

      const patientSameLine = compact.match(
        /\bpat(?:ient|lent|lient|ent)\s*[:\-]?\s*(.*)$/i
      );

      if (patientSameLine) {
        const candidates = [
          cleanName(patientSameLine[1]),
          cleanName(lines[i + 1] || ""),
          cleanName(lines[i - 1] || ""),
          cleanName(lines[i + 2] || ""),
          cleanName(lines[i - 2] || ""),
        ];

        for (const candidate of candidates) {
          if (looksLikePersonName(candidate)) return candidate;
        }
      }
    }

    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];

      if (/^[A-Z' -]+,\s*[A-Z][A-Z' -]+$/.test(line)) {
        const cleaned = cleanName(line);
        const nearby = [
          lines[i - 1] || "",
          lines[i + 1] || "",
          lines[i + 2] || "",
        ].join(" ");

        if (
          looksLikePersonName(cleaned) &&
          /patient|dob|mrn/i.test(nearby)
        ) {
          return cleaned;
        }
      }
    }

    return "";
  }

  function extractDobFromLabText(rawText = "") {
    const lines = String(rawText || "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);

    for (const line of lines) {
      const dobMatch = line.match(/\bdob\s*[:\-]?\s*(\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2})/i);
      if (dobMatch) {
        return normalizeExtractedDate(dobMatch[1]);
      }
    }

    // fallback for OCR lines like:
    // "M, 57 yr, 1/12/1969"
    for (const line of lines) {
      const anyDateMatch = line.match(/\b(\d{1,2}\/\d{1,2}\/\d{2,4})\b/);
      if (anyDateMatch) {
        return normalizeExtractedDate(anyDateMatch[1]);
      }
    }

    return "";
  }

  function extractCollectedDateFromLabText(rawText = "") {
    const lines = String(rawText || "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);

    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];

      const collectedMatch = line.match(
        /\bcollected\b.*?(\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2})/i
      );
      if (collectedMatch) {
        return normalizeExtractedDate(collectedMatch[1]);
      }

      if (/^collected date\/time$/i.test(line) || /^collected$/i.test(line)) {
        const nextLine = lines[i + 1] || "";
        const nextDateMatch = nextLine.match(
          /\b(\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2})\b/i
        );
        if (nextDateMatch) {
          return normalizeExtractedDate(nextDateMatch[1]);
        }
      }
    }

    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];

      const orderedMatch = line.match(
        /\bordered\b.*?(\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2})/i
      );
      if (orderedMatch) {
        return normalizeExtractedDate(orderedMatch[1]);
      }

      if (/^ordered date\/time$/i.test(line) || /^ordered$/i.test(line)) {
        const nextLine = lines[i + 1] || "";
        const nextDateMatch = nextLine.match(
          /\b(\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{2}-\d{2})\b/i
        );
        if (nextDateMatch) {
          return normalizeExtractedDate(nextDateMatch[1]);
        }
      }
    }

    return "";
  }

  function normalizePatientMatchText(value = "") {
    let text = String(value || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/medical record number:.*$/i, "")
      .replace(/\bmrn:.*$/i, "")
      .replace(/[^a-z0-9,\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    if (text.includes(",")) {
      const parts = text.split(",").map((part) => part.trim()).filter(Boolean);
      if (parts.length >= 2) {
        text = `${parts.slice(1).join(" ")} ${parts[0]}`.trim();
      }
    }

    return text.replace(/\s+/g, " ").trim();
  }

  function buildCanonicalPatientNameKey(value = "") {
    const cleaned = normalizePatientMatchText(value);

    if (!cleaned) return "";

    const rawParts = cleaned
      .split(" ")
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => part.replace(/[^a-z0-9]/g, ""));

    if (rawParts.length === 0) return "";

    const mergedParts = [];
    for (const part of rawParts) {
      const last = mergedParts[mergedParts.length - 1] || "";

      if (
        last &&
        last.length > 1 &&
        part.length === 1
      ) {
        mergedParts[mergedParts.length - 1] = `${last}${part}`;
        continue;
      }

      mergedParts.push(part);
    }

    return mergedParts.sort().join(" ");
  }

  function splitNameParts(fullName = "") {
    const cleaned = normalizePatientMatchText(fullName);

    if (!cleaned) {
      return {
        full: "",
        first: "",
        last: "",
      };
    }

    const parts = cleaned.split(" ").filter(Boolean);

    return {
      full: cleaned,
      first: parts[0] || "",
      last: parts.length > 1 ? parts[parts.length - 1] : "",
    };
  }

  function datesMatchExactly(a = "", b = "") {
    return String(a || "").trim() !== "" && String(a || "").trim() === String(b || "").trim();
  }

  function scorePatientLabMatch(patient, extractedPatientName, extractedDob) {
    const patientFullName = `${patient.firstName || ""} ${patient.lastName || ""}`.trim();

    const extracted = splitNameParts(extractedPatientName);
    const patientName = splitNameParts(patientFullName);

    let score = 0;

    if (extracted.full && patientName.full && extracted.full === patientName.full) {
      score += 100;
    }

    if (extracted.first && patientName.first && extracted.first === patientName.first) {
      score += 25;
    }

    if (extracted.last && patientName.last && extracted.last === patientName.last) {
      score += 40;
    }

    if (
      extracted.last &&
      patientName.last &&
      (extracted.last.includes(patientName.last) ||
        patientName.last.includes(extracted.last))
    ) {
      score += 15;
    }

    if (
      extracted.first &&
      patientName.first &&
      (extracted.first.includes(patientName.first) ||
        patientName.first.includes(extracted.first))
    ) {
      score += 10;
    }

    if (
      extracted.first &&
      patientName.first &&
      extracted.first[0] &&
      patientName.first[0] &&
      extracted.first[0] === patientName.first[0]
    ) {
      score += 5;
    }

    if (
      extracted.last &&
      patientName.last &&
      extracted.last[0] &&
      patientName.last[0] &&
      extracted.last[0] === patientName.last[0]
    ) {
      score += 10;
    }

    if (datesMatchExactly(patient.dob, extractedDob)) {
      score += 60;
    }

    return score;
  }

  function findBestPatientMatch(patients = [], extractedName = "", extractedDob = "") {
    if (!patients || patients.length === 0) {
      return {
        status: "unresolved",
        match: null,
        possible: [],
        reason: "No patients loaded yet.",
      };
    }

    let bestMatch = null;
    let bestScore = 0;
    const possibleMatches = [];

    for (const patient of patients) {
      const score = scorePatientLabMatch(patient, extractedName, extractedDob);

      if (score > bestScore) {
        bestScore = score;
        bestMatch = patient;
      }

      if (score >= 60) {
        possibleMatches.push({ patient, score });
      }
    }

    if (bestScore >= 120 && bestMatch) {
      return {
        status: "matched",
        match: bestMatch,
        possible: [],
        reason: "",
      };
    }

    if (possibleMatches.length > 0) {
      return {
        status: "possible_match",
        match: null,
        possible: possibleMatches
          .sort((a, b) => b.score - a.score)
          .slice(0, 3)
          .map((entry) => entry.patient),
        reason: "Possible patient matches found.",
      };
    }

    return {
      status: "unresolved",
      match: null,
      possible: [],
      reason: "No confident patient match found.",
    };
  }

  function normalizeBulkLabLines(rawText = "") {
    return String(rawText || "")
      .replace(/\r\n/g, "\n")
      .replace(/\r/g, "\n")
      .split("\n")
      .map((line) => line.trimEnd());
  }

  function looksLikePatientStart(line = "", prev = "", next = "", nextTwo = "") {
    const text = String(line || "").trim();
    const prevText = String(prev || "").trim();
    const nextText = String(next || "").trim();
    const nextTwoText = String(nextTwo || "").trim();

    if (!text) return false;

    if (
      /^pat(?:ient|lent|lient|ent)\s*[:\s-]/i.test(text) ||
      /\bpat(?:ient|lent|lient|ent)\s+.+\bmrn\b/i.test(text) ||
      /^name\s*[:\s-]/i.test(text)
    ) {
      return true;
    }

    const looksLikeCommaName =
      /^[A-Z' -]+,\s*[A-Z][A-Z' -]+$/.test(text) &&
      !/EGFR|LEGEND|CRITICAL|FOOTNOTE|CORRECTED ABNORMAL|MOLECULAR DIAGNOSTICS|CHEMISTRY|CBC|IMMUNOLOGY|HIV/.test(text);

    if (!looksLikeCommaName) return false;

    return (
      /^pat(?:ient|lent|lient|ent)\s*[:\s-]*$/i.test(nextText) ||
      /^pat(?:ient|lent|lient|ent)\s*[:\s-]/i.test(nextText) ||
      /^pat(?:ient|lent|lient|ent)\s*[:\s-]*$/i.test(prevText) ||
      /^dob\s*[:\-]/i.test(nextText) ||
      /^dob\s*[:\-]/i.test(nextTwoText)
    );
  }

  function looksLikeDobLine(line = "") {
    return /\bdob\s*[:\-]?\s*\d{1,2}\/\d{1,2}\/\d{2,4}/i.test(String(line || "").trim());
  }

  function looksLikeMrnLine(line = "") {
    return /\bmrn\b/i.test(String(line || "").trim());
  }

  function cleanOcrLabText(rawText = "") {
    const lines = String(rawText || "")
      .replace(/\r\n/g, "\n")
      .replace(/\r/g, "\n")
      .split("\n")
      .map((line) => line.replace(/\s+/g, " ").trim())
      .filter(Boolean);

    const cleaned = [];
    let skipInterpretiveBlock = false;

    for (const line of lines) {
      const lower = line.toLowerCase();

      if (
        /^@@@\s*\d+\s*@@@$/.test(line) ||
        /system generated/i.test(line) ||
        /page \d+ of \d+/i.test(line) ||
        /umctxrrd/i.test(line) ||
        /rrd/i.test(line) && /180679/i.test(line) ||
        /^\(?806\)?\s*775[-–]?\d+/i.test(line) ||
        /602 indiana avenue/i.test(line) ||
        /lubbock,\s*tx\s*7941/i.test(line) ||
        /^legend:/i.test(line) ||
        /^attending physician:/i.test(line) ||
        /^ordering physician:/i.test(line) ||
        /^financial number:/i.test(line) ||
        /^location:/i.test(line) ||
        /^consulting physician:/i.test(line) ||
        /^entered by:/i.test(line) ||
        /^order details:/i.test(line) ||
        /^order comment:/i.test(line) ||
        /^order start date/i.test(line) ||
        /^order status:/i.test(line) ||
        /^end-state/i.test(line) ||
        /^catalog type:/i.test(line) ||
        /^activity type:/i.test(line)
      ) {
        continue;
      }

      if (/^interpretive data$/i.test(line) || /^order comments$/i.test(line)) {
        skipInterpretiveBlock = true;
        continue;
      }

      if (skipInterpretiveBlock) {
        const looksLikeNewSection =
          /^patient name:/i.test(line) ||
          /^patient:/i.test(line) ||
          /^dob:/i.test(line) ||
          /^collected/i.test(line) ||
          /^procedure/i.test(line) ||
          /^chlamydia/i.test(line) ||
          /^neisseria/i.test(line) ||
          /^hiv /i.test(line) ||
          /^syphilis/i.test(line) ||
          /^hepatitis/i.test(line) ||
          /^wbc$/i.test(line) ||
          /^rbc$/i.test(line) ||
          /^hemoglobin/i.test(line) ||
          /^hematocrit/i.test(line) ||
          /^sodium/i.test(line) ||
          /^potassium/i.test(line) ||
          /^chloride/i.test(line) ||
          /^glucose/i.test(line) ||
          /^bun$/i.test(line) ||
          /^creatinine/i.test(line) ||
          /^calcium/i.test(line) ||
          /^cholesterol/i.test(line) ||
          /^triglycerides/i.test(line) ||
          /^hdl/i.test(line) ||
          /^ldl/i.test(line) ||
          /^tsh/i.test(line) ||
          /^t4/i.test(line) ||
          /^estradiol/i.test(line);

        if (!looksLikeNewSection) {
          continue;
        }

        skipInterpretiveBlock = false;
      }

      const normalizedLine = line
        .replace(/Medical Record Number:/gi, "MRN:")
        .replace(/Patient Name:\s*/i, "Patient: ")
        .replace(/\bDORB:\b/i, "DOB:")
        .replace(/\bCoflected\b|\bCollected Dato\b|\bCollegted\b|\bCollacted\b/gi, "Collected")
        .replace(/\bChiamydia\b/gi, "Chlamydia")
        .replace(/\bHemaogiobin\b/gi, "Hemoglobin")
        .replace(/\bSereen\b/gi, "Screen")
        .replace(/\bResuit\b/gi, "Result")
        .replace(/\bNeisseria gonorthoeae\b/gi, "Neisseria gonorrhoeae")
        .replace(/\s{2,}/g, " ")
        .trim();

      cleaned.push(normalizedLine);
    }

    return cleaned.join("\n");
  }

  function splitBulkLabTextIntoPackets(rawText = "") {
    const lines = normalizeBulkLabLines(rawText).filter((line) => line.trim() !== "");

    if (lines.length === 0) return [];

    const packets = [];
    let current = [];

    function pushCurrent() {
      const text = current.join("\n").trim();
      if (text) {
        packets.push({
          packetId: `packet-${packets.length + 1}`,
          rawText: text,
        });
      }
      current = [];
    }

    function looksLikeDivider(line = "") {
      const text = String(line || "").trim();
      return /^[-_=]{5,}$/.test(text);
    }

    function windowHasDob(startIndex, endIndex) {
      const start = Math.max(0, startIndex);
      const end = Math.min(lines.length - 1, endIndex);

      for (let i = start; i <= end; i += 1) {
        if (looksLikeDobLine(lines[i])) return true;
      }
      return false;
    }

    function currentPacketLooksReal() {
      if (current.length === 0) return false;

      const joined = current.join("\n").toLowerCase();
      return (
        joined.includes("collected date") ||
        joined.includes("procedure") ||
        joined.includes("result") ||
        joined.includes("chemistry") ||
        joined.includes("cbc") ||
        joined.includes("immunology") ||
        joined.includes("molecular diagnostics")
      );
    }

    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      const prev = i > 0 ? lines[i - 1] : "";
      const next = i < lines.length - 1 ? lines[i + 1] : "";
      const next2 = i < lines.length - 2 ? lines[i + 2] : "";
      const next3 = i < lines.length - 3 ? lines[i + 3] : "";

      if (looksLikeDivider(line)) {
        continue;
      }

      const patientBoundary =
        current.length > 0 &&
        currentPacketLooksReal() &&
        (
          (
            looksLikePatientStart(line) &&
            (
              looksLikeDobLine(line) ||
              looksLikeDobLine(prev) ||
              looksLikeDobLine(next) ||
              looksLikeDobLine(next2) ||
              looksLikeDobLine(next3) ||
              windowHasDob(i - 1, i + 3)
            )
          ) ||
          (
            /^patient\s*:/i.test(String(line || "").trim()) &&
            windowHasDob(i, i + 3)
          )
        );

      if (patientBoundary) {
        pushCurrent();
      }

      current.push(line);
    }

    pushCurrent();

    return packets;
  }

  function classifyLabPacket(rawText = "") {
    const text = rawText.toLowerCase();

    const hasInfectious =
      text.includes("chlamydia") ||
      text.includes("gonorrhea") ||
      text.includes("trichomonas") ||
      text.includes("syphilis") ||
      text.includes("hiv") ||
      text.includes("hepatitis");

    const hasPathology =
      text.includes("pap") ||
      text.includes("cytology") ||
      text.includes("hpv") ||
      text.includes("specimen adequacy");

    const hasRadiology =
      text.includes("findings") &&
      text.includes("impression");

    const hasSingleTest =
      text.includes("thyroid") ||
      text.includes("tsh") ||
      text.includes("a1c") ||
      text.includes("hemoglobin a1c") ||
      text.includes("ferritin") ||
      text.includes("iron level") ||
      text.includes("tibc") ||
      text.includes("vitamin d") ||
      text.includes("b12");

    const hasLiver =
      /\bast\b/.test(text) ||
      /\balt\b/.test(text) ||
      /\balk(?:aline)?\s+phos(?:phatase)?\b/.test(text) ||
      /\bbilirubin\b/.test(text);

    const hasRenal =
      /\begfr\b/.test(text) ||
      /\brenal\b/.test(text) ||
      /\bcreatinine clearance\b/.test(text) ||
      /\bphosphorus\b/.test(text);

    const hasCbc =
      text.includes("white blood cell") ||
      text.includes("wbc") ||
      text.includes("hematocrit") ||
      text.includes("mcv") ||
      text.includes("platelet") ||
      text.includes("cbc");

    const hasChemistry =
      text.includes("sodium") ||
      text.includes("potassium") ||
      text.includes("glucose") ||
      text.includes("creatinine") ||
      text.includes("bun") ||
      text.includes("chemistry");

    const structuredHits = [hasLiver, hasRenal, hasCbc, hasChemistry].filter(Boolean).length;

    // IMPORTANT:
    // if a packet clearly has multi-panel structure, keep it multi-panel
    // even if it also contains hepatitis/HIV/TSH/A1c pages merged into the same patient packet
    if (structuredHits >= 2) {
      return "Multi-Panel Report";
    }

    if (hasPathology) return "Pathology / PAP";
    if (hasRadiology) return "Radiology / Report";
    if (hasInfectious) return "Infectious / STD";
    if (hasSingleTest) return "Single Test Report";

    if (hasLiver) return "liver";
    if (hasRenal) return "renal";
    if (hasCbc) return "cbc";
    if (hasChemistry) return "chemistry";

    if (text.includes("umc")) {
      return "umc_structured";
    }

    return "unknown";
  }

  function buildLabImportPacketFromText(rawText, packetType = "unknown") {
    const rawExtractedPatientName =
      extractPatientNameFromLabTextFromParser(rawText) ||
      extractPatientNameFromLabText(rawText);

    const extractedPatientName = formatPatientName(rawExtractedPatientName);
    const extractedDob = extractDobFromLabText(rawText);
    const collectedDate =
      extractCollectedDateFromLabText(rawText) || formatClinicDate();

    const shouldParseAsStructuredLabs =
      packetType !== "Pathology / PAP" &&
      packetType !== "Radiology / Report";

    const parsedLabs = shouldParseAsStructuredLabs
      ? window.testLabParser(rawText, [], collectedDate)
      : [];

    const matchResult = findBestPatientMatch(
      patients,
      extractedPatientName,
      extractedDob
    );

    return {
      extractedPatientName,
      extractedDob,
      collectedDate,
      matchStatus: matchResult.status,
      matchedPatient: matchResult.match || null,
      possibleMatches: matchResult.possible || [],
      unresolvedReason: matchResult.reason || "",
      confirmedPatient: matchResult.match || null,
      labs: parsedLabs,
      rawText,
      reviewStatus: "unsaved",
      savedAt: null,
      skippedAt: null,
    };
  }

  function buildBulkLabImportPacketsFromText(rawText) {
    const chunks = mergeConsecutivePacketsForSamePatient(
      splitBulkLabTextIntoPackets(rawText)
    );

    const builtPackets = chunks
      .map((chunk, index) => {
        const packetType = classifyLabPacket(chunk.rawText);
        const packet = buildLabImportPacketFromText(chunk.rawText, packetType);

        return {
          ...packet,
          packetId: chunk.packetId || `packet-${index + 1}`,
          sourceRawText: chunk.rawText,
          packetType,
          reviewStatus: packet.reviewStatus || "unsaved",
          savedAt: packet.savedAt || null,
          skippedAt: packet.skippedAt || null,
        };
      })
      .filter((packet) => {
        const hasLabs = (packet.labs || []).length > 0;
        const hasExtractedPatient =
          !!String(packet.extractedPatientName || "").trim() &&
          !!String(packet.extractedDob || "").trim();

        const isNonNumericButImportant =
          packet.packetType === "Pathology / PAP" ||
          packet.packetType === "Radiology / Report" ||
          packet.packetType === "Single Test Report";

        return hasLabs || isNonNumericButImportant || hasExtractedPatient;
      });

    return mergeDuplicatePacketsByPatientDobAndType(builtPackets);
  }

  function mergeConsecutivePacketsForSamePatient(chunks = []) {
    if (!Array.isArray(chunks) || chunks.length <= 1) return chunks;

    const merged = [];

    function normalizeNameForMerge(value = "") {
      return buildCanonicalPatientNameKey(value);
    }

    for (const chunk of chunks) {
      const rawText = chunk?.rawText || "";
      const patientName = normalizeNameForMerge(extractPatientNameFromLabText(rawText));
      const dob = extractDobFromLabText(rawText);

      const last = merged[merged.length - 1];

      if (last) {
        const lastPatientName = normalizeNameForMerge(
          extractPatientNameFromLabText(last.rawText)
        );
        const lastDob = extractDobFromLabText(last.rawText);

        const samePatient =
          (
            patientName &&
            lastPatientName &&
            patientName === lastPatientName &&
            dob &&
            lastDob &&
            dob === lastDob
          ) ||
          (
            !patientName &&
            !!lastPatientName &&
            dob &&
            lastDob &&
            dob === lastDob
          );

        if (samePatient) {
          last.rawText = `${last.rawText}\n${rawText}`.trim();
          continue;
        }
      }

      merged.push({ ...chunk });
    }

    return merged.map((chunk, index) => ({
      ...chunk,
      packetId: `packet-${index + 1}`,
    }));
  }

  function mergeDuplicatePacketsByPatientDobAndType(packets = []) {
    if (!Array.isArray(packets) || packets.length <= 1) return packets;

    const mergedMap = new Map();

    function makeKey(packet) {
      let name = buildCanonicalPatientNameKey(packet.extractedPatientName || "");

      name = name
        .replace(/[^a-z]/gi, "")   // remove commas, spaces, punctuation
        .toLowerCase();

      const dob = String(packet.extractedDob || "").trim();

      return `${name}__${dob}`;
    }

    function pickPreferredPacketType(existingType = "", nextType = "") {
      const priority = {
        "multi-panel report": 5,
        "infectious / std": 4,
        "single test report": 3,
        "cbc": 2,
        "chemistry": 2,
        "unknown": 1,
      };

      const a = String(existingType || "").trim().toLowerCase();
      const b = String(nextType || "").trim().toLowerCase();

      return (priority[b] || 0) > (priority[a] || 0) ? nextType : existingType;
    }

    for (const packet of packets) {
      const key = makeKey(packet);

      if (!mergedMap.has(key)) {
        mergedMap.set(key, {
          ...packet,
          rawText: packet.rawText || packet.sourceRawText || "",
          sourceRawText: packet.sourceRawText || packet.rawText || "",
        });
        continue;
      }

      const existing = mergedMap.get(key);

      const combinedLabs = [...(existing.labs || [])];
      const seenLabKeys = new Set(
        combinedLabs.map(
          (lab) =>
            `${lab.key || lab.displayName || ""}__${String(lab.value ?? "").trim()}__${lab.group || ""}`
        )
      );

      for (const lab of packet.labs || []) {
        const labKey = `${lab.key || lab.displayName || ""}__${String(lab.value ?? "").trim()}__${lab.group || ""}`;
        if (!seenLabKeys.has(labKey)) {
          combinedLabs.push(lab);
          seenLabKeys.add(labKey);
        }
      }

      const existingName = String(existing.extractedPatientName || "").trim();
      const nextName = String(packet.extractedPatientName || "").trim();

      const preferredExtractedPatientName =
        existingName && nextName
          ? (existingName.length >= nextName.length ? existingName : nextName)
          : (existingName || nextName);

      mergedMap.set(key, {
        ...existing,
        extractedPatientName: preferredExtractedPatientName,
        packetType: pickPreferredPacketType(existing.packetType, packet.packetType),
        labs: combinedLabs,
        rawText: `${existing.rawText}\n${packet.rawText || packet.sourceRawText || ""}`.trim(),
        sourceRawText: `${existing.sourceRawText}\n${packet.sourceRawText || packet.rawText || ""}`.trim(),
        possibleMatches:
          existing.possibleMatches?.length > 0
            ? existing.possibleMatches
            : packet.possibleMatches || [],
        matchedPatient: existing.matchedPatient || packet.matchedPatient || null,
        confirmedPatient: existing.confirmedPatient || packet.confirmedPatient || null,
      });
    }

    return Array.from(mergedMap.values()).map((packet, index) => ({
      ...packet,
      packetId: `packet-${index + 1}`,
    }));
  }

  function mapLabImportDbRowToPacket(row) {
    const matchedPatient =
      row.matched_patient_id
        ? patients.find((p) => String(p.id) === String(row.matched_patient_id)) || null
        : null;

    const possibleMatches = Array.isArray(row.match_candidates_json)
      ? row.match_candidates_json
        .map((entry) => {
          const id =
            entry?.id ||
            entry?.patient_id ||
            entry?.patientId ||
            null;

          if (!id) return null;

          return patients.find((p) => String(p.id) === String(id)) || null;
        })
        .filter(Boolean)
      : [];

    return {
      packetId: row.id,
      batchId: row.batch_id,
      extractedPatientName: row.extracted_name || "",
      extractedDob: row.extracted_dob || "",
      collectedDate: row.collected_date || "",
      packetType: row.packet_type || "unknown",
      rawText: row.raw_text || "",
      sourceRawText: row.raw_text || "",
      labs: Array.isArray(row.parsed_labs_json) ? row.parsed_labs_json : [],
      reviewStatus: row.review_status || "unreviewed",
      savedAt: row.saved_at || null,
      skippedAt: row.skipped_at || null,
      matchedPatient,
      confirmedPatient: matchedPatient,
      matchStatus: matchedPatient
        ? "matched"
        : possibleMatches.length > 0
          ? "possible_match"
          : "unresolved",
      possibleMatches,
      unresolvedReason: matchedPatient
        ? ""
        : "No confident patient match found.",
      matchedEncounterId: row.matched_encounter_id || null,
      suspiciousCount: row.suspicious_count || 0,
      missingCount: row.missing_count || 0,
      totalLabCount: row.total_lab_count || 0,
    };
  }

  async function loadSharedLabImportBatch(batchId = null) {
    if (!session) return;

    setLabImportLoading(true);

    try {
      let activeBatchId = batchId;

      if (!activeBatchId) {
        const { data: batchRows, error: batchError } = await supabase
          .from("lab_import_batches")
          .select("id, created_at, status")
          .eq("status", "active")
          .order("created_at", { ascending: false })
          .limit(1);

        if (batchError) throw batchError;

        activeBatchId = batchRows?.[0]?.id || null;
      }

      if (!activeBatchId) {
        setActiveLabImportBatchId(null);
        setLabImportPackets([]);
        setLabImportPacket(null);
        setSelectedLabImportPacketId(null);
        return;
      }

      const { data: packetRows, error: packetError } = await supabase
        .from("lab_import_packets")
        .select("*")
        .eq("batch_id", activeBatchId)
        .order("created_at", { ascending: true });

      if (packetError) throw packetError;

      const mappedPackets = (packetRows || []).map(mapLabImportDbRowToPacket);

      setActiveLabImportBatchId(activeBatchId);
      setLabImportPackets(mappedPackets);

      const nextSelectedId =
        selectedLabImportPacketId &&
          mappedPackets.some((packet) => packet.packetId === selectedLabImportPacketId)
          ? selectedLabImportPacketId
          : mappedPackets[0]?.packetId || null;

      setSelectedLabImportPacketId(nextSelectedId);
      setLabImportPacket(
        mappedPackets.find((packet) => packet.packetId === nextSelectedId) || null
      );
    } catch (error) {
      console.error("Failed to load shared lab import batch:", error);
      showToast({
        title: "Failed to load lab batch",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    } finally {
      setLabImportLoading(false);
    }
  }

  async function createSharedLabImportBatchWithPackets(packets, source = "manual") {
    if (!session?.user?.id) {
      throw new Error("No signed-in user found.");
    }

    const { data: batchRow, error: batchError } = await supabase
      .from("lab_import_batches")
      .insert({
        created_by: session.user.id,
        status: "active",
        source,
      })
      .select()
      .single();

    if (batchError) throw batchError;

    const rowsToInsert = (packets || []).map((packet) => ({
      batch_id: batchRow.id,
      extracted_name: packet.extractedPatientName || "",
      extracted_dob: packet.extractedDob || null,
      collected_date: packet.collectedDate || null,
      packet_type: packet.packetType || "unknown",
      matched_patient_id: packet.confirmedPatient?.id || null,
      matched_encounter_id: null,
      review_status: packet.reviewStatus || "unreviewed",
      raw_text: packet.rawText || packet.sourceRawText || "",
      parsed_labs_json: packet.labs || [],
      duplicate_summary_json: {},
      match_candidates_json: (packet.possibleMatches || []).map((p) => ({
        id: p.id,
      })),
      suspicious_count: (packet.labs || []).filter((lab) => !!lab?.suspicious).length,
      missing_count: (packet.labs || []).filter((lab) => !!lab?.missing || !!lab?.autoFilled).length,
      total_lab_count: (packet.labs || []).length,
      last_opened_by: session.user.id,
      last_opened_at: new Date().toISOString(),
    }));

    const { error: insertError } = await supabase
      .from("lab_import_packets")
      .insert(rowsToInsert);

    if (insertError) throw insertError;

    return batchRow.id;
  }

  async function updateSharedLabImportPacket(packetId, updates = {}) {
    const { error } = await supabase
      .from("lab_import_packets")
      .update(updates)
      .eq("id", packetId);

    if (error) throw error;
  }

  async function cleanupSavedLabImportPacket(packetId, batchId) {
    if (!packetId) return;

    const { error: packetDeleteError } = await supabase
      .from("lab_import_packets")
      .delete()
      .eq("id", packetId);

    if (packetDeleteError) throw packetDeleteError;

    if (!batchId) {
      setLabImportPackets((prev) => prev.filter((packet) => packet.packetId !== packetId));

      if (selectedLabImportPacketId === packetId) {
        setSelectedLabImportPacketId(null);
        setLabImportPacket(null);
      }

      return;
    }

    const { data: remainingPackets, error: remainingError } = await supabase
      .from("lab_import_packets")
      .select("id")
      .eq("batch_id", batchId)
      .limit(1);

    if (remainingError) throw remainingError;

    if ((remainingPackets || []).length === 0) {
      const { error: batchDeleteError } = await supabase
        .from("lab_import_batches")
        .delete()
        .eq("id", batchId);

      if (batchDeleteError) throw batchDeleteError;

      setActiveLabImportBatchId(null);
      setLabImportPackets([]);
      setLabImportPacket(null);
      setSelectedLabImportPacketId(null);
      return;
    }

    await loadSharedLabImportBatch(batchId);
  }

  async function handleLiveUpdateLabPacketLabs(packetId, reviewedLabs) {
    if (!packetId) return;

    const existingPacket = labImportPackets.find(
      (packet) => String(packet.packetId) === String(packetId)
    );

    const existingJson = JSON.stringify(existingPacket?.labs || []);
    const nextJson = JSON.stringify(reviewedLabs || []);

    if (existingJson === nextJson) {
      return;
    }

    try {
      await updateSharedLabImportPacket(packetId, {
        parsed_labs_json: reviewedLabs,
        suspicious_count: (reviewedLabs || []).filter((lab) => !!lab?.suspicious).length,
        missing_count: (reviewedLabs || []).filter(
          (lab) => !!lab?.missing || !!lab?.autoFilled
        ).length,
        total_lab_count: (reviewedLabs || []).length,
      });

      setLabImportPackets((prev) =>
        prev.map((packet) =>
          packet.packetId === packetId
            ? {
              ...packet,
              labs: reviewedLabs,
              suspiciousCount: (reviewedLabs || []).filter((lab) => !!lab?.suspicious).length,
              missingCount: (reviewedLabs || []).filter(
                (lab) => !!lab?.missing || !!lab?.autoFilled
              ).length,
              totalLabCount: (reviewedLabs || []).length,
            }
            : packet
        )
      );

      setLabImportPacket((prev) =>
        prev && prev.packetId === packetId
          ? {
            ...prev,
            labs: reviewedLabs,
            suspiciousCount: (reviewedLabs || []).filter((lab) => !!lab?.suspicious).length,
            missingCount: (reviewedLabs || []).filter(
              (lab) => !!lab?.missing || !!lab?.autoFilled
            ).length,
            totalLabCount: (reviewedLabs || []).length,
          }
          : prev
      );
    } catch (error) {
      console.error("Failed to live-update lab packet labs:", error);
    }
  }

  async function handleParseLabImportText() {
    if (!labImportRawText.trim()) {
      showToast({
        title: "No lab text",
        message: "Paste lab text first.",
        type: "warning",
      });
      return;
    }

    try {
      const cleanedText = cleanOcrLabText(labImportRawText);
      setLabImportRawText(cleanedText);

      const packets = buildBulkLabImportPacketsFromText(cleanedText);

      if (!packets || packets.length === 0) {
        showToast({
          title: "No labs detected",
          message: "No labs were detected from the pasted text.",
          type: "warning",
        });
        return;
      }

      const batchId = await createSharedLabImportBatchWithPackets(packets, "manual");

      await loadSharedLabImportBatch(batchId);
      setActiveView("lab-import");
    } catch (error) {
      console.error("Failed to create shared lab import batch:", error);
      showToast({
        title: "Failed to create lab batch",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  async function fileToBase64(file) {
    return await new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        try {
          const result = String(reader.result || "");
          const base64 = result.split(",")[1] || "";
          resolve(base64);
        } catch (error) {
          reject(error);
        }
      };

      reader.onerror = () => reject(reader.error || new Error("Failed to read file"));
      reader.readAsDataURL(file);
    });
  }

  async function convertPdfToBase64Images(file) {
    const arrayBuffer = await file.arrayBuffer();

    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const images = [];

    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum += 1) {
      const page = await pdf.getPage(pageNum);

      const viewport = page.getViewport({ scale: 2.0 });

      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");

      canvas.width = viewport.width;
      canvas.height = viewport.height;

      await page.render({
        canvasContext: context,
        viewport,
      }).promise;

      const dataUrl = canvas.toDataURL("image/png");
      const base64 = dataUrl.split(",")[1] || "";
      images.push(base64);
    }

    return images;
  }

  async function handleGoogleOCRImport(file) {
    if (!file) return;

    setOcrUploading(true);
    setOcrError("");

    try {
      let base64Images = [];

      if (file.type === "application/pdf") {
        base64Images = await convertPdfToBase64Images(file);
      } else if (file.type.startsWith("image/")) {
        base64Images = [await fileToBase64(file)];
      } else {
        throw new Error("Only PDF and image files are supported.");
      }

      const ocrTexts = await runGoogleOCRInChunks(base64Images, 16);
      const combinedText = ocrTexts.join("\n\n").trim();

      if (!combinedText) {
        throw new Error("OCR returned no text.");
      }

      const cleanedText = cleanOcrLabText(combinedText);
      setLabImportRawText(cleanedText);

      const packets = buildBulkLabImportPacketsFromText(cleanedText);

      if (!packets || packets.length === 0) {
        throw new Error("OCR worked, but no labs were detected from the extracted text.");
      }

      const batchId = await createSharedLabImportBatchWithPackets(packets, "google_ocr");

      await loadSharedLabImportBatch(batchId);
      setActiveView("lab-import");
    } catch (error) {
      console.error("Google OCR import failed:", error);
      setOcrError(error.message || "OCR failed.");
    } finally {
      setOcrUploading(false);
    }
  }

  async function handleConfirmLabImportPatient(packetId, patient) {
    if (!packetId || !patient) return;

    try {
      await updateSharedLabImportPacket(packetId, {
        matched_patient_id: patient.id,
        match_candidates_json: [],
      });

      setLabImportPackets((prev) =>
        prev.map((packet) =>
          packet.packetId === packetId
            ? {
              ...packet,
              confirmedPatient: patient,
              matchStatus: "matched",
              matchedPatient: patient,
              possibleMatches: [],
              unresolvedReason: "",
            }
            : packet
        )
      );

      setLabImportPacket((prev) =>
        prev && prev.packetId === packetId
          ? {
            ...prev,
            confirmedPatient: patient,
            matchStatus: "matched",
            matchedPatient: patient,
            possibleMatches: [],
            unresolvedReason: "",
          }
          : prev
      );
    } catch (error) {
      console.error("Failed to confirm patient for lab packet:", error);
      showToast({
        title: "Failed to confirm patient",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  async function handleSkipLabImportPacket(packetId) {
    if (!packetId) return;

    const skippedAt = new Date().toISOString();

    try {
      await updateSharedLabImportPacket(packetId, {
        review_status: "skipped",
        skipped_at: skippedAt,
      });

      setLabImportPackets((prev) =>
        prev.map((packet) =>
          packet.packetId === packetId
            ? {
              ...packet,
              reviewStatus: "skipped",
              skippedAt,
            }
            : packet
        )
      );

      setLabImportPacket((prev) =>
        prev && prev.packetId === packetId
          ? {
            ...prev,
            reviewStatus: "skipped",
            skippedAt,
          }
          : prev
      );
    } catch (error) {
      console.error("Failed to skip lab packet:", error);
      showToast({
        title: "Failed to skip packet",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  useEffect(() => {
    if (!session) return;
    if (!isLeadershipView) return;
    if (activeView !== "lab-import") return;

    loadSharedLabImportBatch(activeLabImportBatchId || null);
  }, [session, isLeadershipView, activeView]);

  async function handleSelectLabImportPacket(packetId) {
    if (!packetId) return;

    setSelectedLabImportPacketId(packetId);

    const found = labImportPackets.find((packet) => packet.packetId === packetId) || null;
    setLabImportPacket(found);

    if (session?.user?.id) {
      try {
        await updateSharedLabImportPacket(packetId, {
          last_opened_by: session.user.id,
          last_opened_at: new Date().toISOString(),
        });
      } catch (error) {
        console.error("Failed to update last opened packet info:", error);
      }
    }
  }

  function handleExportLabDebug() {
    try {
      const packets = labImportPackets || [];

      function buildIndexedLines(text = "") {
        return String(text || "")
          .split("\n")
          .map((line, index) => ({
            index,
            text: String(line || ""),
          }));
      }

      const exportData = {
        timestamp: new Date().toISOString(),
        rawText: labImportRawText || "",
        indexedRawTextLines: buildIndexedLines(labImportRawText || ""),
        packetCount: packets.length,

        packetSummary: packets.map((packet) => {
          const packetLabs = packet.labs || [];
          const counts = computeLabCounts(packetLabs);

          return {
            packetId: packet.packetId,
            extractedPatientName: packet.extractedPatientName || "",
            extractedDob: packet.extractedDob || "",
            collectedDate: packet.collectedDate || "",
            packetType: packet.packetType || "unknown",
            reviewStatus: packet.reviewStatus || "unsaved",
            labCount: packetLabs.length,
            suspiciousCount: packetLabs.filter((lab) => !!lab?.suspicious).length,
            missingCount: counts.missing_count,
            autoFilledCount: counts.autofilled_count,
            needsReviewCount: counts.needs_review_count,
          };
        }),

        packets: packets.map((packet) => {
          const finalLabs = (packet.labs || []).map((lab) => ({
            key: lab.key || "",
            displayName: lab.displayName || "",
            group: lab.group || "",
            value: lab.value ?? null,
            rawLine: lab.rawLine || "",
            confidence: lab.confidence || "",
            suspicious: !!lab.suspicious,
            missing: !!lab.missing,
            autoFilled: !!lab.autoFilled,
            expectedRangeText: lab.expectedRangeText || "",
            duplicateType: lab.duplicateType || null,
            duplicateInfo: lab.duplicateInfo || null,

            debugMeta: {
              parseMethod: lab.debugMeta?.parseMethod || null,
              matchIndex:
                Number.isInteger(lab.debugMeta?.matchIndex)
                  ? lab.debugMeta.matchIndex
                  : null,
              valueLineIndex:
                Number.isInteger(lab.debugMeta?.valueLineIndex)
                  ? lab.debugMeta.valueLineIndex
                  : null,
              valueSourceLine: lab.debugMeta?.valueSourceLine || "",
              candidateNumbers: Array.isArray(lab.debugMeta?.candidateNumbers)
                ? lab.debugMeta.candidateNumbers
                : [],
              debugCandidates: Array.isArray(lab.debugMeta?.debugCandidates)
                ? lab.debugMeta.debugCandidates
                : [],
              rangeUsed: lab.debugMeta?.rangeUsed || "",
            },
          }));

          const counts = computeLabCounts(finalLabs);
          const categorized = categorizeLabsForExport(finalLabs);

          const parsingFails = finalLabs.filter(
            (lab) =>
              lab.missing ||
              lab.suspicious ||
              lab.autoFilled ||
              lab.value === null ||
              lab.value === undefined ||
              lab.value === ""
          );

          return {
            packetId: packet.packetId,

            summary: {
              total_labs: finalLabs.length,
              missing_count: counts.missing_count,
              autofilled_count: counts.autofilled_count,
              needs_review_count: counts.needs_review_count,
            },

            categorized: {
              trueMissingLabs: categorized.trueMissingLabs,
              panelPlaceholders: categorized.panelPlaceholders,
              suspiciousLabs: categorized.suspiciousLabs,
            },

            patient: {
              extractedName: packet.extractedPatientName || "",
              extractedDob: packet.extractedDob || "",
              confirmedPatient: packet.confirmedPatient || null,
              matchStatus: packet.matchStatus || "unresolved",
              matchedPatient: packet.matchedPatient || null,
              possibleMatches: packet.possibleMatches || [],
              unresolvedReason: packet.unresolvedReason || "",
            },

            metadata: {
              collectedDate: packet.collectedDate || "",
              packetType: packet.packetType || "unknown",
              reviewStatus: packet.reviewStatus || "unsaved",
              savedAt: packet.savedAt || null,
              skippedAt: packet.skippedAt || null,
            },

            finalLabs,
            parsingFails,

            finalLabSummary: finalLabs.map((lab) => ({
              name: lab.displayName,
              value: lab.value,
              rawLine: lab.rawLine,
              suspicious: lab.suspicious,
              missing: lab.missing,
              autoFilled: lab.autoFilled,
              parseMethod: lab.debugMeta?.parseMethod || null,
              valueLineIndex: lab.debugMeta?.valueLineIndex ?? null,
            })),

            rawPacket: {
              extractedPatientName: packet.extractedPatientName || "",
              extractedDob: packet.extractedDob || "",
              collectedDate: packet.collectedDate || "",
              packetType: packet.packetType || "unknown",
              rawText: packet.rawText || "",
              sourceRawText: packet.sourceRawText || "",
              indexedLines: buildIndexedLines(packet.rawText || ""),
              indexedSourceLines: buildIndexedLines(packet.sourceRawText || ""),
            },
          };
        }),
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: "application/json",
      });

      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `lab_debug_${Date.now()}.json`;
      a.click();

      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Failed to export lab debug:", error);
      showToast({
        title: "Export failed",
        message: "Failed to export lab debug JSON.",
        type: "error",
        duration: 5000,
      });
    }
  }


  // Program entries realtime disabled to reduce background subscriptions.
  // The Programs view keeps local state in sync after edits and reloads on page open.

  // PAP realtime disabled to reduce background subscriptions.
  // PAP entries load once per session and update locally after edits.

  useEffect(() => {
    if (!session) return;
    if (!activeLabImportBatchId) return;

    const channel = supabase
      .channel(`lab-import-packets-${activeLabImportBatchId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "lab_import_packets",
          filter: `batch_id=eq.${activeLabImportBatchId}`,
        },
        async () => {
          await loadSharedLabImportBatch(activeLabImportBatchId);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [session, activeLabImportBatchId]);

  const [assignmentForm, setAssignmentForm] = useState({
    studentName: "",
    upperLevelName: "",
    roomNumber: "",
  });
  const [leadershipActionLocked, setLeadershipActionLocked] = useState(false);
  const [currentVitals, setCurrentVitals] = useState(EMPTY_VITALS);
  const [editingVitalsIndex, setEditingVitalsIndex] = useState(null);

  const [showMedicationModal, setShowMedicationModal] = useState(false);
  const [newMedication, setNewMedication] = useState(EMPTY_MEDICATION);
  const [editingMedicationId, setEditingMedicationId] = useState(null);
  const [isRefillRequestMode, setIsRefillRequestMode] = useState(false);
  const [refillSourceMedicationId, setRefillSourceMedicationId] = useState(null);
  const EMPTY_ALLERGY = { allergen: "", reaction: "", severity: "", notes: "", isActive: true, };

  const [showAllergyModal, setShowAllergyModal] = useState(false);
  const [newAllergy, setNewAllergy] = useState(EMPTY_ALLERGY);
  const [editingAllergyId, setEditingAllergyId] = useState(null);
  const [isEditingIntake, setIsEditingIntake] = useState(false);
  const [editingPatientId, setEditingPatientId] = useState(null);
  const [intakeMatchPatientId, setIntakeMatchPatientId] = useState(null);
  const [autoFilledMatchPatientId, setAutoFilledMatchPatientId] = useState(null);
  const intakeMatchedPatient =
    patients.find((p) => p.id === intakeMatchPatientId) || null;

  const [soapBusy, setSoapBusy] = useState(false);
  const [soapUiMessage, setSoapUiMessage] = useState("");
  const EMPTY_OPHTHO_NOTE = {
    hpi: "",
    ocularHistory: "",
    vaOd: "",
    vaOs: "",
    phOd: "",
    phOs: "",
    iopOd: "",
    iopOs: "",
    externalOd: "",
    externalOs: "",
    slitLampOd: "",
    slitLampOs: "",
    fundusOd: "",
    fundusOs: "",
    assessment: "",
    plan: "",
  };

  const [soapDraft, setSoapDraft] = useState({
    encounterId: null,
    soapSubjective: "",
    soapObjective: "",
    soapAssessment: "",
    soapPlan: "",
    notes: "",
    ophthalmologyNote: { ...EMPTY_OPHTHO_NOTE },
  });
  const [auditEntries, setAuditEntries] = useState([]);
  const [auditLoading, setAuditLoading] = useState(false);



  useEffect(() => {
    if (isEditingIntake || !showIntakeModal) {
      if (intakeMatchPatientId !== null) setIntakeMatchPatientId(null);
      if (autoFilledMatchPatientId !== null) setAutoFilledMatchPatientId(null);
      return;
    }

    if (!intakeForm.firstName || !intakeForm.lastName || !intakeForm.dob) {
      if (intakeMatchPatientId !== null) setIntakeMatchPatientId(null);
      if (autoFilledMatchPatientId !== null) setAutoFilledMatchPatientId(null);
      return;
    }

    const possibleMatch = findPotentialDuplicatePatient(
      patients,
      intakeForm.firstName,
      intakeForm.lastName,
      intakeForm.dob,
      intakeForm.last4ssn,
      editingPatientId
    );

    const nextMatchId = possibleMatch ? possibleMatch.id : null;

    if (nextMatchId !== intakeMatchPatientId) {
      setIntakeMatchPatientId(nextMatchId);
    }

    if (
      autoFilledMatchPatientId !== null &&
      autoFilledMatchPatientId !== nextMatchId
    ) {
      setAutoFilledMatchPatientId(null);
    }
  }, [
    intakeForm.firstName,
    intakeForm.lastName,
    intakeForm.dob,
    intakeForm.last4ssn,
    editingPatientId,
    isEditingIntake,
    showIntakeModal,
    intakeMatchPatientId,
    autoFilledMatchPatientId,
    patients,
  ]);
  useEffect(() => {
    if (activeView === "users" && isLeadershipView) {
      loadProfiles();
    }
  }, [activeView, isLeadershipView]);

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      setDebouncedSearchForm(searchForm);
    }, 250);

    return () => window.clearTimeout(timeout);
  }, [searchForm]);



  const [selectedClinicDate, setSelectedClinicDate] = useState(
    getLocalDateInputValue()
  );

  const [roomBoardDate, setRoomBoardDate] = useState(getLocalDateInputValue());
  const [specialtyQueueDate, setSpecialtyQueueDate] = useState(getLocalDateInputValue());
  const [queueClinicDate, setQueueClinicDate] = useState(getLocalDateInputValue());
  const [labQueueDate, setLabQueueDate] = useState(getLocalDateInputValue());
  const [, setNow] = useState(Date.now());
  const selectedPatient = patients.find((p) => p.id === selectedPatientId) || null;
  const selectedEncounter =
    selectedPatient?.encounters.find((e) => e.id === selectedEncounterId) || null;

  const patientMedicationList = selectedPatient?.medicationList || [];

  const sortedMedications = [...patientMedicationList].sort((a, b) => {
    if ((a.isActive ?? true) !== (b.isActive ?? true)) {
      return (b.isActive ?? true) - (a.isActive ?? true);
    }

    return (a.name || "").localeCompare(b.name || "");
  });

  const activeMedicationCount = patientMedicationList.filter(
    (med) => med.isActive ?? true
  ).length;

  useEffect(() => {
    if (!selectedEncounter?.id) {
      setSoapDraft({
        encounterId: null,
        soapSubjective: "",
        soapObjective: "",
        soapAssessment: "",
        soapPlan: "",
        notes: "",
        ophthalmologyNote: { ...EMPTY_OPHTHO_NOTE },
      });
      return;
    }

    setSoapDraft({
      encounterId: selectedEncounter.id,
      soapSubjective: selectedEncounter.soapSubjective || "",
      soapObjective: selectedEncounter.soapObjective || "",
      soapAssessment: selectedEncounter.soapAssessment || "",
      soapPlan: selectedEncounter.soapPlan || "",
      notes: selectedEncounter.notes || "",
      ophthalmologyNote: {
        ...EMPTY_OPHTHO_NOTE,
        ...(selectedEncounter.ophthalmologyNote || {}),
      },
    });
  }, [selectedEncounter?.id]);

  useEffect(() => {
    if (selectedEncounter?.id) {
      loadAuditLog();
    } else {
      setAuditEntries([]);
    }
  }, [selectedEncounter?.id]);

  const canSignAsUpperLevel = canUpperLevelSignSoap(userRole, selectedEncounter);
  const canSignAsAttending = canAttendingSignSoap(userRole, selectedEncounter);
  const canSubmitForUpperLevel = canSubmitSoapForUpperLevel(
    userRole,
    selectedEncounter
  );
  const canSubmitForAttending = canSubmitSoapForAttending(
    userRole,
    selectedEncounter
  );
  const canReopenSoap = userRole === "attending" && selectedEncounter?.soapStatus === "signed";
  useEffect(() => {
    const interval = setInterval(() => {
      setNow(Date.now());
    }, 60000);

    return () => clearInterval(interval);
  }, []);



  const sortedSelectedPatientEncounters = useMemo(() => {
    if (!selectedPatient) return [];

    return sortEncountersByDate(selectedPatient.encounters);
  }, [selectedPatient]);

  const patientRecordsTitle = selectedClinicDate
    ? `Patient Records — ${formatDate(selectedClinicDate)}`
    : "Patient Records — All Encounters";


  const allEncounterRows = useMemo(() => {
    return patients.flatMap((patient) =>
      patient.encounters.map((encounter) => {
        const dailyNumber =
          encounter?.dailyNumber ||
          encounter?.daily_number ||
          encounter?.intakeData?.dailyNumber ||
          encounter?.intake_data?.dailyNumber ||
          encounter?.intakeData?.daily_number ||
          encounter?.intake_data?.daily_number ||
          patient?.dailyNumber ||
          patient?.daily_number ||
          "";

        return {
          patient: {
            ...patient,
            dailyNumber: patient?.dailyNumber || dailyNumber,
          },
          encounter: {
            ...encounter,
            dailyNumber,
          },
        };
      })
    );
  }, [patients]);

  const specialtyEncounterRows = useMemo(() => {
    const clinicDateForSpecialtyQueue = specialtyQueueDate || formatClinicDate();

    return allEncounterRows
      .filter(({ encounter }) => {
        if (!encounter) return false;

        const visitType = encounter.visitType || "general";
        const specialtyType = encounter.specialtyType || "";

        if (normalizeClinicDate(encounter.clinicDate) !== clinicDateForSpecialtyQueue) return false;
        if (!specialtyType) return false;
        if (encounter.status === "cancelled") return false;

        return (
          visitType === "specialty_only" ||
          visitType === "both" ||
          encounter.dualVisit === true
        );
      })
      .sort((a, b) => {
        const aDone = a.encounter.status === "done" || a.encounter.soapStatus === "signed";
        const bDone = b.encounter.status === "done" || b.encounter.soapStatus === "signed";

        if (aDone !== bDone) return aDone ? 1 : -1;

        const aTime = new Date(a.encounter.createdAt || 0).getTime();
        const bTime = new Date(b.encounter.createdAt || 0).getTime();
        return aTime - bTime;
      });
  }, [allEncounterRows, specialtyQueueDate]);

  const specialtyRoomRulesForBoard = useMemo(() => {
    const today = formatClinicDate();

    const mapProgramTypeToEncounterType = {
      "Physical Therapy": "pt",
      Dermatology: "dermatology",
      Ophthalmology: "ophthalmology",
      "Mental Health": "mental_health",
      "Addiction Medicine": "addiction",
    };

    const rules = {};

    programSettings.forEach((row) => {
      const encounterType = mapProgramTypeToEncounterType[row.program_type];
      if (!encounterType) return;

      if (row.next_specialty_date !== today) return;

      rules[encounterType] = {
        label: row.program_type,
        allowedRooms: (row.rooms_assigned?.rooms || []).map((room) => String(room)),
      };
    });

    return rules;
  }, [programSettings]);

  const registrationRows = useMemo(() => {
    return allEncounterRows
      .filter(({ encounter }) => {
        if (!encounter) return false;

        const isSelectedRegistrationDate =
          normalizeClinicDate(encounter.clinicDate) === selectedClinicDate;

        const isGeneralRegistrationEncounter =
          encounter.visitType !== "specialty_only";

        if (!isSelectedRegistrationDate) return false;

        const isRegistrationStatus =
          encounter.status === "started" ||
          encounter.status === "undergrad_complete";

        const isActiveRegistrationEncounter =
          encounter.status !== "cancelled" &&
          encounter.status !== "done" &&
          encounter.status !== "completed" &&
          encounter.status !== "signed";

        if (userRole === "undergraduate") {
          const undergradEditableStatuses = new Set([
            "started",
            "undergrad_complete",
            "ready",
            "in_visit",
          ]);

          // Leadership can finish intake while undergrad is still adding MRN/details.
          // Keep those ready/in-visit patients visible until undergrad explicitly saves
          // Complete / Edit Undergrad Intake, then remove them from this registration list.
          return (
            isGeneralRegistrationEncounter &&
            undergradEditableStatuses.has(encounter.status) &&
            !encounter.undergradCompletedAt
          );
        }

        if (isLeadershipView) {
          // Leadership registration should only clear after leadership completes intake.
          // Undergrad completion can happen before/after leadership and should not
          // remove the patient from this list. Use the leadership flag as the source
          // of truth instead of relying only on status, so simultaneous workflows stay visible.
          return (
            isGeneralRegistrationEncounter &&
            isActiveRegistrationEncounter &&
            !encounter.leadershipIntakeComplete
          );
        }

        return false;
      })
      .sort(sortRowsByDailyNumberThenTime);
  }, [allEncounterRows, selectedClinicDate, userRole, isLeadershipView]);

  async function removeFromRegistration(patientId, encounterId) {
    const confirmed = window.confirm(
      "Remove this patient from registration? This will mark the encounter as cancelled."
    );
    if (!confirmed) return;

    try {
      await updateEncounterInSupabase(encounterId, {
        status: "cancelled",
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === patientId
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === encounterId
                  ? { ...encounter, status: "cancelled" }
                  : encounter
              ),
            }
            : patient
        )
      );
    } catch (error) {
      console.error("Failed to remove registration encounter:", error);
      alert(`Failed to remove patient from registration: ${error.message}`);
    }
  }

  const visibleEncounterRows = useMemo(() => {
    if (!selectedClinicDate) {
      return allEncounterRows;
    }

    return allEncounterRows.filter(
      ({ encounter }) =>
        normalizeClinicDate(encounter.clinicDate) === selectedClinicDate
    );
  }, [allEncounterRows, selectedClinicDate]);

  const boardClinicDate = roomBoardDate || formatClinicDate();

  const boardEncounterRows = useMemo(() => {
    return allEncounterRows.filter(
      ({ encounter }) =>
        normalizeClinicDate(encounter.clinicDate) === boardClinicDate
    );
  }, [allEncounterRows, boardClinicDate]);

  useEffect(() => {
    if (!session || !boardClinicDate) return;

    let cancelled = false;

    setTodayStaffRoster({
      attendings: "",
      residents: "",
      upperLevels: "",
    });

    async function loadRoster() {
      const roster = await fetchStaffRoster(boardClinicDate);
      if (!cancelled) {
        setTodayStaffRoster(roster);
      }
    }

    loadRoster();

    const channel = supabase
      .channel(`clinic_staff_roster_${boardClinicDate}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "clinic_staff_roster",
          filter: `clinic_date=eq.${boardClinicDate}`,
        },
        () => {
          loadRoster();
        }
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [session, boardClinicDate]);

  async function handleSaveTodayStaffRoster(nextRoster = todayStaffRoster) {
    try {
      await saveStaffRoster(boardClinicDate, nextRoster);
    } catch (error) {
      console.error("Failed to save staff roster:", error);
      showToast?.("Unable to save staff roster.", "error");
    }
  }


  const filteredPatients = patients.filter((patient) =>
    patientMatchesSearch(patient, debouncedSearchForm)
  );

  const visiblePatientIds = new Set(
    visibleEncounterRows.map(({ patient }) => patient.id)
  );

  const filteredVisiblePatients = filteredPatients.filter((patient) =>
    visiblePatientIds.has(patient.id)
  );

  const summaryPatientRows = useMemo(() => {
    const priorityForVisitType = (visitType) => {
      if (visitType === "general") return 1;
      if (visitType === "both") return 2;

      // specialty-only and refill-only should NOT count
      // toward new/returning general clinic totals
      if (visitType === "specialty_only") return 99;
      if (visitType === "refill_only") return 100;

      return 101;
    };

    const rowMap = new Map();

    visibleEncounterRows.forEach((row) => {
      const visitType = row.encounter?.visitType;

      // exclude specialty-only + refill-only
      if (
        visitType === "specialty_only" ||
        visitType === "refill_only"
      ) {
        return;
      }

      const patientKey = String(
        row.patient?.id || row.encounter?.patientId || ""
      );

      if (!patientKey) return;

      const existing = rowMap.get(patientKey);

      if (!existing) {
        rowMap.set(patientKey, row);
        return;
      }

      const existingPriority = priorityForVisitType(
        existing.encounter?.visitType
      );

      const nextPriority = priorityForVisitType(
        row.encounter?.visitType
      );

      if (nextPriority < existingPriority) {
        rowMap.set(patientKey, row);
      }
    });

    return Array.from(rowMap.values());
  }, [visibleEncounterRows]);

  const newPatientCount = summaryPatientRows.filter(
    ({ encounter }) => encounter.newReturning === "New"
  ).length;

  const returningPatientCount = summaryPatientRows.filter(
    ({ encounter }) => encounter.newReturning === "Returning"
  ).length;

  const totalPatientCount = summaryPatientRows.length;

  const autoLwobsCount = visibleEncounterRows.filter(
    ({ encounter }) => String(encounter.status || "").toLowerCase() === "cancelled"
  ).length;

  const clinicSummaryStorageKey = selectedClinicDate
    ? `clinic-summary-${selectedClinicDate}`
    : "";

  useEffect(() => {
    if (!clinicSummaryStorageKey) return;

    const saved = window.localStorage.getItem(clinicSummaryStorageKey);

    if (!saved) return;

    try {
      setClinicSummary((prev) => ({
        ...prev,
        ...JSON.parse(saved),
      }));
    } catch (error) {
      console.error("Failed to load saved clinic summary:", error);
    }
  }, [clinicSummaryStorageKey]);

  useEffect(() => {
    if (!clinicSummaryStorageKey) return;

    window.localStorage.setItem(
      clinicSummaryStorageKey,
      JSON.stringify(clinicSummary)
    );
  }, [clinicSummary, clinicSummaryStorageKey]);

  const [profiles, setProfiles] = useState([]);
  const [loadingProfiles, setLoadingProfiles] = useState(false);
  const [savingProfileId, setSavingProfileId] = useState(null);
  const [profilesMessage, setProfilesMessage] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const [editingProfileNameId, setEditingProfileNameId] = useState(null);
  const [editingProfileNameValue, setEditingProfileNameValue] = useState("");
  const [showOnlyActiveToday, setShowOnlyActiveToday] = useState(false);

  function dateKeyFromTimestamp(value) {
    if (!value) return "";

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return String(value).slice(0, 10);
    }

    return new Intl.DateTimeFormat("en-CA", {
      timeZone: "America/Chicago",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(date);
  }

  const profileById = useMemo(() => {
    const map = new Map();
    profiles.forEach((profile) => {
      map.set(String(profile.id), profile);
    });
    return map;
  }, [profiles]);

  const autoRefillPatientCount = useMemo(() => {
    const patientIds = new Set();
    patients.forEach((patient) => {
      patient.encounters.forEach((encounter) => {
        if (encounter.clinicDate !== selectedClinicDate) return;
        if (encounter.visitType !== "refill_only") return;

        patientIds.add(String(patient.id));
      });
    });

    refillRequests.forEach((request) => {
      const status = String(request.status || "").toLowerCase();
      if (status !== "approved") return;
      if (!request.patient_id) return;
      if (!request.approved_by || !request.approved_at) return;
      if (dateKeyFromTimestamp(request.approved_at) !== selectedClinicDate) return;

      const requester = profileById.get(String(request.requested_by));
      const approver = profileById.get(String(request.approved_by));
      const requesterHasRefillAccess =
        requester?.can_refill === true ||
        requester?.role === "attending" ||
        requester?.role === "leadership";
      const signedByAttending = approver?.role === "attending";

      if (!requesterHasRefillAccess || !signedByAttending) return;

      patientIds.add(String(request.patient_id));
    });

    return patientIds.size;
  }, [patients, refillRequests, profileById, selectedClinicDate]);

  const specialtyCounts = useMemo(() => {
    const counts = {
      pt: { specialtyOnly: 0, both: 0 },
      dermatology: { specialtyOnly: 0, both: 0 },
      ophthalmology: { specialtyOnly: 0, both: 0 },
      mental_health: { specialtyOnly: 0, both: 0 },
      addiction: { specialtyOnly: 0, both: 0 },
      social_work: { specialtyOnly: 0, both: 0 },
    };

    patients.forEach((patient) => {
      const encountersForDate = (patient.encounters || []).filter(
        (encounter) => normalizeClinicDate(encounter.clinicDate) === selectedClinicDate
      );

      encountersForDate.forEach((encounter) => {
        const specialty = String(encounter.specialtyType || "").toLowerCase();
        if (!specialty || !counts[specialty]) return;

        const visitType = String(encounter.visitType || "general").toLowerCase();

        const hasGeneralSameDay = encountersForDate.some((otherEncounter) => {
          if (!otherEncounter || otherEncounter.id === encounter.id) return false;

          const otherVisitType = String(otherEncounter.visitType || "general").toLowerCase();

          return (
            otherVisitType === "general" ||
            otherVisitType === "both" ||
            otherEncounter.dualVisit === true
          );
        });

        const isGeneralAndSpecialty =
          visitType === "both" ||
          encounter.dualVisit === true ||
          hasGeneralSameDay;

        if (isGeneralAndSpecialty) {
          counts[specialty].both += 1;
        } else if (visitType === "specialty_only") {
          counts[specialty].specialtyOnly += 1;
        }
      });
    });

    const formatSpecialtyCount = ({ specialtyOnly, both }) =>
      `${specialtyOnly} specialty-only + ${both} general/free clinic`;

    return {
      pt: formatSpecialtyCount(counts.pt),
      dermatology: formatSpecialtyCount(counts.dermatology),
      ophthalmology: formatSpecialtyCount(counts.ophthalmology),
      mental_health: formatSpecialtyCount(counts.mental_health),
      addiction: formatSpecialtyCount(counts.addiction),
      social_work: formatSpecialtyCount(counts.social_work),
    };
  }, [patients, selectedClinicDate]);

  useEffect(() => {
    setClinicSummary((prev) => ({
      ...prev,
      refillCount:
        prev.refillCount || String(autoRefillPatientCount),

      lwobsCount:
        prev.lwobsCount || String(autoLwobsCount),

      mentalHealthCount:
        prev.mentalHealthCount ||
        String(specialtyCounts.mental_health || 0),

      addictionMedicineCount:
        prev.addictionMedicineCount ||
        String(specialtyCounts.addiction || 0),

      ptCount:
        prev.ptCount ||
        String(specialtyCounts.pt || 0),

      dermatologyCount:
        prev.dermatologyCount ||
        String(specialtyCounts.dermatology || 0),

      ophthalmologyCount:
        prev.ophthalmologyCount ||
        String(specialtyCounts.ophthalmology || 0),
    }));
  }, [
    autoRefillPatientCount,
    autoLwobsCount,
    specialtyCounts.mental_health,
    specialtyCounts.addiction,
    specialtyCounts.pt,
    specialtyCounts.dermatology,
    specialtyCounts.ophthalmology,
  ]);



  const currentUserProfile = useMemo(() => {
    return profiles.find((profile) => profile.id === session?.user?.id) || null;
  }, [profiles, session?.user?.id]);

  const currentSpecialtyAccess = useMemo(() => {
    const value = currentUserProfile?.specialty_access;
    if (Array.isArray(value)) return value;
    if (typeof value === "string" && value.trim()) return [value.trim()];
    return [];
  }, [currentUserProfile]);

  const canUseOphthoQueueTools = currentSpecialtyAccess.includes("Ophthalmology");
  const canUseWholeClinicQueueTools = canUseOphthoQueueTools || userRole === "social_work";

  const canAccessPrograms = isLeadershipView || currentSpecialtyAccess.length > 0;

  const filteredProfiles = useMemo(() => {
    let nextProfiles = profiles;

    if (showOnlyActiveToday) {
      nextProfiles = nextProfiles.filter((profile) =>
        isToday(profile.last_seen_at)
      );
    }

    const query = userSearch.trim().toLowerCase();
    if (!query) return nextProfiles;

    return nextProfiles.filter((profile) => {
      const fullName = (profile.full_name || "").toLowerCase();
      const role = (profile.role || "").toLowerCase();
      const classification = (profile.classification || "").toLowerCase();
      const email = (profile.email || "").toLowerCase();
      const specialtyAccess = Array.isArray(profile.specialty_access)
        ? profile.specialty_access.join(" ").toLowerCase()
        : String(profile.specialty_access || "").toLowerCase();

      return (
        fullName.includes(query) ||
        role.includes(query) ||
        classification.includes(query) ||
        email.includes(query) ||
        specialtyAccess.includes(query)
      );
    });
  }, [profiles, userSearch, showOnlyActiveToday]);

  async function handleUndergradStartEncounter(data) {
    try {
      let targetPatient = null;

      if (data.matchedPatientId) {
        const existingPatient = patients.find((p) => p.id === data.matchedPatientId);

        if (!existingPatient) {
          throw new Error("Matched patient was not found.");
        }

        const patientUpdates = {
          preferredName: data.preferredName,
          phone: data.phone,
          sex: data.sex,
          ethnicity: data.ethnicity,
          address: data.addressLine1,
          city: data.city,
          state: data.state,
          zipCode: data.zipCode,
          emergencyContactName: data.emergencyContactName,
          emergencyContactRelation: data.emergencyContactRelation,
          emergencyContactPhone: data.emergencyContactPhone,
          last4ssn: data.last4Ssn,
          incomeRange: data.incomeRange,
          spanishOnly: data.spanishOnly,
          chronicConditions: data.chronicConditions,
          chronicConditionsOther: data.chronicConditionsOther,
        };

        targetPatient = await updatePatientInSupabase(existingPatient.id, patientUpdates);
      } else {
        const patientToSave = {
          ...data,
          mrn: "",
        };

        targetPatient = await createPatientInSupabase(patientToSave);
      }

      const encounterBase = {
        clinicDate: formatClinicDate(),
        createdAt: new Date().toISOString(),
        dailyNumber: data.dailyNumber || "",
        refillNumber: data.visitType === "refill_only" ? data.refillNumber || "" : "",
        newReturning: data.matchedPatientId ? "Returning" : (data.isReturning || "New"),
        visitLocation: "In Clinic",
        chiefComplaint: "",
        notes: "",
        transportation: "",
        needsElevator: false,
        spanishSpeaking: false,
        mammogramStatus: "",
        papStatus: "",
        fluShot: "",
        htn: false,
        dm: false,
        labsLast6Months: "",
        nicotineUse: "",
        nicotineDetails: "",
        substanceUseConcern: "",
        substanceUseTreatment: "",
        substanceUseNotes: "",
        dermatology: "N/A",
        ophthalmology: "N/A",
        optometry: "N/A",
        diabeticEyeExamPastYear: "N/A",
        physicalTherapy: "N/A",
        mentalHealthCombined: "N/A",
        counseling: "N/A",
        anyMentalHealthPositive: false,
        status: "started",
        assignedStudent: "",
        assignedUpperLevel: "",
        roomNumber: "",
        leadershipIntakeComplete: false,
        refillMedicationRequest: data.refillMedicationRequest || "",
      };

      let savedEncounter = null;

      if (data.visitType === "both") {
        const generalEncounter = {
          ...encounterBase,
          visitType: "general",
          specialtyType: "",
          status: "started",
          leadershipIntakeComplete: false,
          pharmacyStatus: "",
        };

        const specialtyEncounter = {
          ...encounterBase,
          visitType: "specialty_only",
          specialtyType: data.specialtyType || "",
          chiefComplaint: data.specialtyType
            ? `${data.specialtyType} Specialty Visit`
            : "Specialty Visit",
          status: "undergrad_complete",
          leadershipIntakeComplete: true,
          pharmacyStatus: "waiting",
        };

        savedEncounter = await createEncounterInSupabase(targetPatient.id, generalEncounter);
        await createEncounterInSupabase(targetPatient.id, specialtyEncounter);
      } else {
        const isRefillOnly = data.visitType === "refill_only";
        const isSpecialtyOnly = data.visitType === "specialty_only";

        const singleEncounter = {
          ...encounterBase,
          visitType: data.visitType || "general",
          specialtyType: isRefillOnly ? "" : data.specialtyType || "",
          chiefComplaint: isRefillOnly
            ? "Refills Only"
            : isSpecialtyOnly
              ? data.specialtyType
                ? `${data.specialtyType} Specialty Visit`
                : "Specialty Visit"
              : encounterBase.chiefComplaint || data.chiefComplaint || "",
          status: isRefillOnly || isSpecialtyOnly ? "undergrad_complete" : "started",
          leadershipIntakeComplete: isRefillOnly || isSpecialtyOnly,
          pharmacyStatus: isRefillOnly || isSpecialtyOnly ? "waiting" : "",
        };

        savedEncounter = await createEncounterInSupabase(targetPatient.id, singleEncounter);
      }

      await refreshClinicData();

      setSelectedPatientId(targetPatient.id);
      setSelectedEncounterId(savedEncounter.id);

      showToast({
        title: "Encounter started",
        message: "Patient was added successfully and you can start the next intake.",
        type: "success",
        duration: 3000,
      });

      return true;
    } catch (error) {
      console.error("Failed to save undergrad intake:", error);
      showToast({
        title: "Failed to save intake",
        message: error.message,
        type: "error",
        duration: 5000,
      });
      return false;
    }
  }

  function openUndergradRegistration(patientId, encounterId) {
    const patient = patients.find((p) => p.id === patientId);
    const encounter = patient?.encounters.find((e) => e.id === encounterId);

    if (!patient || !encounter) return;

    setRegistrationPatientId(patientId);
    setRegistrationEncounterId(encounterId);

    setUndergradRegistrationForm({
      firstName: patient.firstName || "",
      lastName: patient.lastName || "",
      dob: patient.dob || "",
      mrn: patient.mrn || "",
      addressLine1: patient.address || "",
      city: patient.city || "",
      state: patient.state || "",
      zipCode: patient.zipCode || "",
      emergencyContactName: patient.emergencyContactName || "",
      emergencyContactRelation: patient.emergencyContactRelation || "",
      emergencyContactPhone: patient.emergencyContactPhone || "",
      last4Ssn: patient.last4ssn || "",
      incomeRange: patient.incomeRange || "",
      spanishOnly: patient.spanishOnly || "",
      chronicConditions: patient.chronicConditions || [],
      chronicConditionsOther: patient.chronicConditionsOther || "",
      dailyNumber: encounter.dailyNumber || "",
      refillNumber: encounter.refillNumber || "",
      visitType: encounter.visitType || "general",
      specialtyType: encounter.specialtyType || "",
      refillMedicationRequest: encounter.refillMedicationRequest || "",
    });

    setShowUndergradRegistrationModal(true);
  }

  async function saveUndergradRegistration() {
    const patient = patients.find((p) => p.id === registrationPatientId);
    const encounter = patient?.encounters.find((e) => e.id === registrationEncounterId);

    if (!patient || !encounter) return;

    const patientUpdates = {
      mrn: undergradRegistrationForm.mrn,
      last4ssn: undergradRegistrationForm.last4Ssn,
      address: undergradRegistrationForm.addressLine1,
      city: undergradRegistrationForm.city,
      state: undergradRegistrationForm.state,
      zipCode: undergradRegistrationForm.zipCode,
      emergencyContactName: undergradRegistrationForm.emergencyContactName,
      emergencyContactRelation: undergradRegistrationForm.emergencyContactRelation,
      emergencyContactPhone: undergradRegistrationForm.emergencyContactPhone,
      incomeRange: undergradRegistrationForm.incomeRange,
      spanishOnly: undergradRegistrationForm.spanishOnly,
      chronicConditions: undergradRegistrationForm.chronicConditions,
      chronicConditionsOther: undergradRegistrationForm.chronicConditionsOther,
    };

    try {
      await updatePatientInSupabase(registrationPatientId, patientUpdates);

      const currentStatus = encounter.status || "started";
      const activeRegistrationStatuses = new Set(["started", "undergrad_complete"]);
      const nextStatus = activeRegistrationStatuses.has(currentStatus)
        ? encounter.leadershipIntakeComplete
          ? "ready"
          : "undergrad_complete"
        : currentStatus;

      const nextVisitType = undergradRegistrationForm.visitType || encounter.visitType || "general";
      const nextSpecialtyType =
        nextVisitType === "both" || nextVisitType === "specialty_only"
          ? undergradRegistrationForm.specialtyType || ""
          : "";
      const nextRefillMedicationRequest =
        nextVisitType === "refill_only"
          ? undergradRegistrationForm.refillMedicationRequest || ""
          : "";

      const undergradCompletedAt = encounter.undergradCompletedAt || new Date().toISOString();

      await updateEncounterInSupabase(registrationEncounterId, {
        status: nextStatus,
        undergradCompletedAt,
        dailyNumber: undergradRegistrationForm.dailyNumber || "",
        refillNumber: nextVisitType === "refill_only" ? undergradRegistrationForm.refillNumber || encounter.refillNumber || "" : "",
        visitType: nextVisitType,
        specialtyType: nextSpecialtyType,
        refillMedicationRequest: nextRefillMedicationRequest,
        dualVisit: nextVisitType === "both",
      });

      setPatients((prev) =>
        prev.map((p) =>
          p.id === registrationPatientId
            ? {
              ...p,
              ...patientUpdates,
              encounters: p.encounters.map((e) =>
                e.id === registrationEncounterId
                  ? {
                    ...e,
                    status: nextStatus,
                    undergradCompletedAt,
                    dailyNumber: undergradRegistrationForm.dailyNumber || "",
                    refillNumber: nextVisitType === "refill_only" ? undergradRegistrationForm.refillNumber || encounter.refillNumber || "" : "",
                    visitType: nextVisitType,
                    specialtyType: nextSpecialtyType,
                    refillMedicationRequest: nextRefillMedicationRequest,
                  }
                  : e
              ),
            }
            : p
        )
      );

      setShowUndergradRegistrationModal(false);
      setRegistrationPatientId(null);
      setRegistrationEncounterId(null);
      setUndergradRegistrationForm(EMPTY_UNDERGRAD_REGISTRATION_FORM);
    } catch (error) {
      console.error("Failed to save undergrad registration:", error);
      showToast({
        title: "Failed to save registration",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }
  function openLeadershipRegistration(patientId, encounterId) {
    const patient = patients.find((p) => p.id === patientId);
    const encounter = patient?.encounters.find((e) => e.id === encounterId);

    if (!patient || !encounter) return;

    setSelectedPatientId(patientId);
    setSelectedEncounterId(encounterId);

    setIntakeForm({
      patientId: patient.id,
      firstName: patient.firstName || "",
      lastName: patient.lastName || "",
      preferredName: patient.preferredName || "",
      mrn: patient.mrn || "",
      last4ssn: patient.last4ssn || "",
      dob: patient.dob || "",
      age: patient.age || "",
      phone: patient.phone || "",
      sex: patient.sex || "",
      ethnicity: patient.ethnicity || "",
      pronouns: patient.pronouns || "",
      dailyNumber: encounter.dailyNumber || "",
      newReturning: encounter.newReturning || "",
      ttuStudent: patient.ttuStudent || false,
      visitLocation: encounter.visitLocation || "In Clinic",
      chiefComplaint: encounter.chiefComplaint || "",
      notes: encounter.notes || "",
      transportation: encounter.transportation || "",
      needsElevator: encounter.needsElevator || false,
      spanishSpeaking: encounter.spanishSpeaking || "",
      over65: patient.age ? Number(patient.age) > 65 : false,
      mammogramStatus: encounter.mammogramStatus || encounter.mammogramPapSmear || "",
      papStatus: encounter.papStatus || "",
      fluShot: encounter.fluShot || "",
      htn: encounter.htn || false,
      dm: encounter.dm || false,
      labsLast6Months: encounter.labsLast6Months || "",
      nicotineUse: encounter.nicotineUse || "",
      nicotineDetails: encounter.nicotineDetails || "",
      substanceUseConcern: encounter.substanceUseConcern || "",
      substanceUseTreatment: encounter.substanceUseTreatment || "",
      substanceUseNotes: encounter.substanceUseNotes || "",
      dermatology: encounter.dermatology || "N/A",
      ophthalmology: encounter.ophthalmology || "N/A",
      optometry: encounter.optometry || "N/A",
      diabeticEyeExamPastYear: encounter.diabeticEyeExamPastYear || "N/A",
      physicalTherapy: encounter.physicalTherapy || "N/A",
      mentalHealthCombined: encounter.mentalHealthCombined || "N/A",
      counseling: encounter.counseling || "N/A",
      anyMentalHealthPositive: encounter.anyMentalHealthPositive || false,
      visitType: encounter.visitType || "general",
      specialtyType: encounter.specialtyType || "",
      leadershipIntakeComplete: false,
    });

    setEditingPatientId(patientId);
    setIsEditingIntake(true);
    setIntakeTab(0);
    setShowIntakeModal(true);
  }

  useEffect(() => {
    loadProfiles(); // initial load

    const interval = setInterval(() => {
      loadProfiles();
    }, 30000); // every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const profileNameMap = useMemo(() => {
    const map = {};

    profiles.forEach((profile) => {
      map[profile.id] = profile.full_name || "Unknown User";
    });

    if (session?.user?.id && authFullName) {
      map[session.user.id] = authFullName;
    }

    return map;
  }, [profiles, session?.user?.id, authFullName]);

  const soapAuthorName = selectedEncounter?.soapAuthorId
    ? profileNameMap[selectedEncounter.soapAuthorId] || "Unknown User"
    : "";

  const upperLevelSignerName = selectedEncounter?.upperLevelSignedBy
    ? profileNameMap[selectedEncounter.upperLevelSignedBy] || "Unknown User"
    : "";

  const attendingSignerName = selectedEncounter?.attendingSignedBy
    ? profileNameMap[selectedEncounter.attendingSignedBy] || "Unknown User"
    : "";



  const filteredEncounterRows = visibleEncounterRows.filter(({ patient }) =>
    filteredPatients.some((p) => p.id === patient.id)
  );

  const isPharmacyQueueView = activeView === "pharmacy-queue";

  const waitingEncounterRows = useMemo(() => {
    const effectiveQueueDate = queueClinicDate || formatClinicDate();

    const activeRows = allEncounterRows.filter(({ encounter }) => {
      const isSelectedQueueDate =
        normalizeClinicDate(encounter.clinicDate) === effectiveQueueDate;

      const isPharmacyWorkflow =
        encounter.visitType === "refill_only" ||
        encounter.visitType === "specialty_only";

      if (!isSelectedQueueDate) return false;
      if (encounter.status === "cancelled") return false;

      if (canUseWholeClinicQueueTools && !isPharmacyQueueView) {
        if (encounter.visitType === "refill_only") return false;

        return (
          encounter.status === "ready" ||
          encounter.status === "roomed" ||
          encounter.status === "in_visit" ||
          encounter.status === "done" ||
          encounter.soapStatus === "signed" ||
          isPharmacyWorkflow
        );
      }

      if (isPharmacyWorkflow) {
        return true;
      }

      return (
        encounter.status === "ready" ||
        encounter.status === "roomed" ||
        encounter.status === "in_visit" ||
        encounter.status === "done" ||
        encounter.soapStatus === "signed"
      );
    });

    const currentUserName = (
      profileNameMap[session?.user?.id] ||
      authFullName ||
      ""
    ).trim();

    let rows = activeRows;

    if (userRole === "student") {
      if (canRefillAccess) {
        rows = activeRows;
      } else if (canUseOphthoQueueTools) {
        rows = activeRows.filter(
          ({ encounter }) => encounter.visitType !== "refill_only"
        );
      } else {
        rows = activeRows.filter(({ encounter }) =>
          (encounter.assignedStudent || "")
            .trim()
            .toLowerCase()
            .includes(currentUserName.toLowerCase())
        );
      }
    } else if (userRole === "social_work") {
      rows = activeRows.filter(
        ({ encounter }) => encounter.visitType !== "refill_only"
      );
    } else if (userRole === "upper_level") {
      rows = activeRows.filter(({ encounter }) =>
        (encounter.assignedUpperLevel || "")
          .trim()
          .toLowerCase()
          .includes(currentUserName.toLowerCase())
      );
    } else if (userRole === "attending") {
      rows = activeRows.filter(
        ({ encounter }) => encounter.soapStatus === "awaiting_attending"
      );
    } else {
      // leadership/general queue should only show general encounters
      if (
        isPharmacyQueueView ||
        userRole === "pharmacy" ||
        userRole === "undergraduate" ||
        userRole === "social_work" ||
        canRefillAccess
      ) {
        rows = activeRows;
      } else {
        // leadership/general queue should only show general assignable encounters
        rows = activeRows.filter(
          ({ encounter }) =>
            encounter.visitType !== "specialty_only" &&
            encounter.visitType !== "refill_only"
        );
      }

      rows = [...rows].sort((a, b) => {
        const aUnassigned =
          !a.encounter.assignedStudent && !a.encounter.assignedUpperLevel
            ? 0
            : 1;
        const bUnassigned =
          !b.encounter.assignedStudent && !b.encounter.assignedUpperLevel
            ? 0
            : 1;

        if (aUnassigned !== bUnassigned) return aUnassigned - bUnassigned;

        return sortRowsByDailyNumberThenTime(a, b);
      });

      return rows;
    }

    return [...rows].sort(sortRowsByDailyNumberThenTime);
  }, [
    allEncounterRows,
    queueClinicDate,
    profileNameMap,
    session?.user?.id,
    authFullName,
    userRole,
    canUseOphthoQueueTools,
    canUseWholeClinicQueueTools,
    canRefillAccess,
    isPharmacyQueueView,
  ]);

  const labEncounterRows = useMemo(() => {
    const effectiveLabQueueDate = labQueueDate || formatClinicDate();

    return allEncounterRows
      .filter(({ encounter }) => {
        if (!encounter) return false;
        if (normalizeClinicDate(encounter.clinicDate) !== effectiveLabQueueDate) return false;
        if (encounter.status === "cancelled") return false;
        if (encounter.status === "done") return false;
        if (encounter.soapStatus === "signed") return false;

        return (
          encounter.status === "started" ||
          encounter.status === "undergrad_complete" ||
          encounter.status === "ready" ||
          encounter.status === "roomed" ||
          encounter.status === "in_visit"
        );
      })
      .sort(sortRowsByDailyNumberThenTime);
  }, [allEncounterRows, labQueueDate]);

  useEffect(() => {
    if (userRole !== "undergraduate") return;

    const medsReadyRows = waitingEncounterRows.filter(({ encounter }) => {
      if (encounter?.pharmacyStatus !== "meds_ready") return false;

      const readyBy = encounter?.pharmacyReadyBy || encounter?.pharmacy_ready_by;
      const readyByProfile = (profiles || []).find(
        (profile) => String(profile.id) === String(readyBy)
      );

      return readyByProfile?.role === "pharmacy";
    });

    if (medsReadyRows.length === 0) {
      if (lastPharmacyToastKey) {
        setLastPharmacyToastKey("");
        setPharmacyToast(null);
      }
      return;
    }

    const toastKey = medsReadyRows
      .map(({ encounter }) => encounter.id)
      .sort()
      .join("|");

    if (toastKey === lastPharmacyToastKey) return;

    setLastPharmacyToastKey(toastKey);
    setPharmacyToast({
      key: toastKey,
      count: medsReadyRows.length,
    });

    showToast({
      title: "Pharmacy Pickup Needed",
      message:
        medsReadyRows.length === 1
          ? "A patient has medications ready. Click to open Live Queue."
          : `${medsReadyRows.length} patients have medications ready. Click to open Live Queue.`,
      type: "success",
      duration: 0,
      actionLabel: "Open Live Queue",
      onClick: () => {
        setActiveView("queue");
        setPharmacyToast(null);
      },
    });
  }, [waitingEncounterRows, userRole, lastPharmacyToastKey, profiles]);

  const assignedCount = boardEncounterRows.filter(
    ({ encounter }) =>
      (encounter.status === "roomed" || encounter.status === "in_visit") &&
      encounter.soapStatus !== "signed"
  ).length;

  const inVisitCount = boardEncounterRows.filter(
    ({ encounter }) =>
      encounter.status === "in_visit" &&
      encounter.soapStatus !== "signed"
  ).length;

  function isEncounterStillOnRoomBoard(encounter) {
    if (!encounter?.roomNumber) return false;
    if (encounter.status === "done") return false;
    if (encounter.soapStatus === "signed") return false;
    return true;
  }

  function normalizeAssigneeName(value) {
    return String(value || "").trim().toLowerCase();
  }

  function getEncounterOwnerKey(encounterLike) {
    const student = normalizeAssigneeName(encounterLike?.assignedStudent);
    if (student) return `student:${student}`;

    const upperLevel = normalizeAssigneeName(encounterLike?.assignedUpperLevel);
    if (upperLevel) return `upper:${upperLevel}`;

    return "";
  }

  function getActiveRoomRows(roomNumber, clinicDateOverride = boardClinicDate) {
    const targetClinicDate = normalizeClinicDate(clinicDateOverride || boardClinicDate);

    return allEncounterRows.filter(
      ({ encounter }) =>
        Number(encounter.roomNumber) === Number(roomNumber) &&
        (!targetClinicDate || normalizeClinicDate(encounter.clinicDate) === targetClinicDate) &&
        isEncounterStillOnRoomBoard(encounter)
    );
  }

  function getRoomConflictDetails(roomNumber, currentEncounterId, incomingAssignment = {}) {
    const targetClinicDate =
      incomingAssignment.clinicDate ||
      incomingAssignment.clinic_date ||
      selectedEncounter?.clinicDate ||
      boardClinicDate;

    const activeRows = getActiveRoomRows(roomNumber, targetClinicDate).filter(
      ({ encounter }) => String(encounter.id) !== String(currentEncounterId)
    );

    if (activeRows.length === 0) {
      return {
        hasAnyOccupant: false,
        hasConflict: false,
        sameOwnerReuse: false,
        occupiedByNames: [],
        ownerKeys: [],
        rows: [],
      };
    }

    const incomingOwnerKey = getEncounterOwnerKey(incomingAssignment);

    const ownerKeys = Array.from(
      new Set(activeRows.map(({ encounter }) => getEncounterOwnerKey(encounter)).filter(Boolean))
    );

    const occupiedByNames = Array.from(
      new Set(activeRows.map(({ patient }) => getPatientBoardName(patient)).filter(Boolean))
    );

    const sameOwnerReuse =
      !!incomingOwnerKey &&
      ownerKeys.length > 0 &&
      ownerKeys.every((key) => key === incomingOwnerKey);

    return {
      hasAnyOccupant: true,
      hasConflict: !sameOwnerReuse,
      sameOwnerReuse,
      occupiedByNames,
      ownerKeys,
      rows: activeRows,
    };
  }


  const roomMap = useMemo(() => {
    const map = {};
    ROOM_OPTIONS.forEach((room) => {
      map[room.number] = null;
    });

    boardEncounterRows.forEach(({ patient, encounter }) => {
      if (
        encounter.roomNumber &&
        encounter.status !== "done" &&
        encounter.soapStatus !== "signed"
      ) {
        map[Number(encounter.roomNumber)] = { patient, encounter };
      }
    });

    return map;
  }, [boardEncounterRows]);

  const roomDropdownOptions = useMemo(() => {
    return ROOM_OPTIONS.map((room) => {
      const roomRows = getActiveRoomRows(room.number, boardClinicDate);

      const occupied = roomRows.length > 0;

      const occupiedByNames = Array.from(
        new Set(roomRows.map(({ patient }) => getPatientBoardName(patient)).filter(Boolean))
      );

      const assignedStudentsInRoom = Array.from(
        new Set(
          roomRows
            .map(({ encounter }) => (encounter.assignedStudent || "").trim())
            .filter(Boolean)
        )
      );

      const assignedUpperLevelsInRoom = Array.from(
        new Set(
          roomRows
            .map(({ encounter }) => (encounter.assignedUpperLevel || "").trim())
            .filter(Boolean)
        )
      );

      return {
        ...room,
        occupied,
        occupiedBy: occupiedByNames.join(", "),
        occupiedByNames,
        assignedStudentsInRoom,
        assignedUpperLevelsInRoom,
        activeEncounterCount: roomRows.length,
        statusLabel: occupied ? "Occupied" : "Available",
        displayLabel: `${room.label} — ${room.area}`,
      };
    });
  }, [allEncounterRows, boardClinicDate]);


  function updateIntakeField(field, value) {
    if (field === "dob") {
      const age = calculateAge(value);
      setIntakeForm((prev) => ({
        ...prev,
        dob: value,
        age,
        over65: age ? Number(age) > 65 : false,
      }));
      return;
    }

    setIntakeForm((prev) => {
      const updated = { ...prev, [field]: value };

      if ((field === "htn" || field === "dm") && !updated.htn && !updated.dm) {
        updated.labsLast6Months = "";
      }

      if (
        (field === "mentalHealthCombined" || field === "counseling") &&
        updated.mentalHealthCombined === "N/A" &&
        updated.counseling === "N/A"
      ) {
        updated.anyMentalHealthPositive = false;
      }

      return updated;
    });
  }

  function applyMatchedPatientToIntake() {
    if (!intakeMatchPatientId) return;

    const matchedPatient = patients.find((p) => p.id === intakeMatchPatientId);
    if (!matchedPatient) return;

    setAutoFilledMatchPatientId(intakeMatchPatientId);

    setIntakeForm((prev) => ({
      ...prev,
      firstName: prev.firstName || matchedPatient.firstName || "",
      preferredName: prev.preferredName || matchedPatient.preferredName || "",
      mrn: prev.mrn || matchedPatient.mrn || "",
      last4ssn: prev.last4ssn || matchedPatient.last4ssn || "",
      dob: prev.dob || matchedPatient.dob || "",
      age: prev.age || matchedPatient.age || "",
      phone: prev.phone || matchedPatient.phone || "",
      pronouns: prev.pronouns || matchedPatient.pronouns || "",
      ethnicity: prev.ethnicity || matchedPatient.ethnicity || "",
      sex: prev.sex || matchedPatient.sex || "",
      over65:
        prev.over65 ||
        (matchedPatient.age ? Number(matchedPatient.age) > 65 : false),
    }));
  }

  function isToday(dateString) {
    if (!dateString) return false;

    const date = new Date(dateString);
    const today = new Date();

    return (
      date.getFullYear() === today.getFullYear() &&
      date.getMonth() === today.getMonth() &&
      date.getDate() === today.getDate()
    );
  }

  function joinActiveNames(list) {
    return list
      .map((profile) => (profile.full_name || "").trim())
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b))
      .join(", ");
  }

  async function loadProfiles() {
    try {
      setLoadingProfiles(true);
      setProfilesMessage("");
      const data = await fetchProfiles();
      setProfiles(data);
    } catch (error) {
      console.error("Failed to load profiles:", error);
      setProfilesMessage(`Failed to load users: ${error.message}`);
    } finally {
      setLoadingProfiles(false);
    }

  }

  const activeTodayProfiles = useMemo(() => {
    return profiles.filter((profile) => isToday(profile.last_seen_at));
  }, [profiles]);

  const activeStudents = useMemo(() => {
    return activeTodayProfiles.filter(
      (profile) => profile.role === "student" || profile.role === "leadership"
    );
  }, [activeTodayProfiles]);

  const studentNameOptions = useMemo(() => {
    const activeNames = activeStudents
      .map((profile) => (profile.full_name || "").trim())
      .filter(Boolean);

    const inactiveNames = profiles
      .filter(
        (profile) =>
          (profile.role === "student" || profile.role === "leadership") &&
          !activeStudents.some((active) => active.id === profile.id)
      )
      .map((profile) => (profile.full_name || "").trim())
      .filter(Boolean);

    return [
      ...activeNames.sort((a, b) => a.localeCompare(b)),
      ...inactiveNames.sort((a, b) => a.localeCompare(b)),
    ];
  }, [profiles, activeStudents]);

  const assignedStudentNames = useMemo(() => {
    const names = new Set();

    allEncounterRows.forEach(({ encounter }) => {
      const name = (encounter.assignedStudent || "").trim();

      if (
        name &&
        encounter.status !== "done" &&
        encounter.soapStatus !== "signed"
      ) {
        names.add(name);
      }
    });

    return names;
  }, [allEncounterRows]);

  const activeUpperLevels = useMemo(() => {
    return activeTodayProfiles.filter((profile) => profile.role === "upper_level");
  }, [activeTodayProfiles]);

  const upperLevelNameOptions = useMemo(() => {
    const activeNames = activeUpperLevels
      .map((profile) => (profile.full_name || "").trim())
      .filter(Boolean);

    const inactiveNames = profiles
      .filter(
        (profile) =>
          profile.role === "upper_level" &&
          !activeUpperLevels.some((active) => active.id === profile.id)
      )
      .map((profile) => (profile.full_name || "").trim())
      .filter(Boolean);

    return [...activeNames.sort((a, b) => a.localeCompare(b)), ...inactiveNames.sort((a, b) => a.localeCompare(b))];
  }, [profiles, activeUpperLevels]);

  const activeAttendings = useMemo(() => {
    return activeTodayProfiles.filter((profile) => profile.role === "attending");
  }, [activeTodayProfiles]);

  useEffect(() => {
    const ms12StudentsOnly = (activeStudents || []).filter(
      (profile) => profile.role === "student"
    );

    setClinicSummary((prev) => ({
      ...prev,
      attendingNames: prev.attendingNames || joinActiveNames(activeAttendings),
      ms34Names: prev.ms34Names || joinActiveNames(activeUpperLevels),
      ms12Names: prev.ms12Names || joinActiveNames(ms12StudentsOnly),
    }));
  }, [activeAttendings, activeUpperLevels, activeStudents]);

  const canAccessSpecialtyQueue =
    userRole === "leadership" ||
    userRole === "student" ||
    userRole === "upper_level" ||
    userRole === "attending" ||
    currentSpecialtyAccess.length > 0;

  async function handleChangeProfileRole(
    profileId,
    nextRole,
    nextClassification = null,
    extraUpdates = {}
  ) {
    if (!isLeadershipView) return;

    const currentUserId = session?.user?.id;

    const currentProfile = profiles.find((profile) => profile.id === profileId);
    const effectiveRole = nextRole ?? currentProfile?.role ?? "student";
    const effectiveClassification =
      nextClassification !== null
        ? nextClassification
        : currentProfile?.classification ?? null;

    if (profileId === currentUserId && effectiveRole !== "leadership") {
      setProfilesMessage("You cannot remove your own leadership role.");
      return;
    }

    const previousProfiles = profiles;

    setProfiles((prev) =>
      prev.map((profile) =>
        profile.id === profileId
          ? {
            ...profile,
            role: effectiveRole,
            classification: effectiveClassification,
            ...extraUpdates,
          }
          : profile
      )
    );

    try {
      setSavingProfileId(profileId);
      setProfilesMessage("");

      if (Object.keys(extraUpdates).length > 0) {
        await updateProfileDetails(profileId, {
          role: effectiveRole,
          classification: effectiveClassification,
          ...extraUpdates,
        });
      } else {
        await updateProfileRole(profileId, effectiveRole, effectiveClassification);
      }

      setProfilesMessage("User updated successfully.");
    } catch (error) {
      console.error("Failed to update profile role:", error);
      setProfiles(previousProfiles);
      setProfilesMessage(`Failed to update user: ${error.message}`);
    } finally {
      setSavingProfileId(null);
    }
  }

  async function handleSaveProfileName(profileId) {
    const trimmedName = editingProfileNameValue.trim();

    if (!trimmedName) {
      setProfilesMessage("Full name cannot be blank.");
      return;
    }

    const previousProfiles = profiles;

    setProfiles((prev) =>
      prev.map((profile) =>
        profile.id === profileId
          ? { ...profile, full_name: trimmedName }
          : profile
      )
    );

    try {
      setSavingProfileId(profileId);
      setProfilesMessage("");
      await updateProfileDetails(profileId, { full_name: trimmedName });
      setEditingProfileNameId(null);
      setEditingProfileNameValue("");
      setProfilesMessage("User updated successfully.");
    } catch (error) {
      console.error("Failed to update profile name:", error);
      setProfiles(previousProfiles);
      setProfilesMessage(`Failed to update user: ${error.message}`);
    } finally {
      setSavingProfileId(null);
    }
  }

  async function handleApproveUser(profileId) {
    if (!isLeadershipView) return;

    const previousProfiles = profiles;

    setProfiles((prev) =>
      prev.map((profile) =>
        profile.id === profileId
          ? {
            ...profile,
            approval_status: "approved",
            approved_by: session?.user?.id || null,
            approved_at: new Date().toISOString(),
          }
          : profile
      )
    );

    try {
      setSavingProfileId(profileId);
      setProfilesMessage("");
      await updateProfileDetails(profileId, {
        approval_status: "approved",
        approved_by: session?.user?.id || null,
        approved_at: new Date().toISOString(),
      });
      setProfilesMessage("User approved successfully.");
    } catch (error) {
      console.error("Failed to approve user:", error);
      setProfiles(previousProfiles);
      setProfilesMessage(`Failed to approve user: ${error.message}`);
    } finally {
      setSavingProfileId(null);
    }
  }

  function openEditIntake() {
    if (!selectedPatient || !selectedEncounter) return;

    setIntakeForm({
      patientId: selectedPatient.id,
      firstName: selectedPatient.firstName || "",
      lastName: selectedPatient.lastName || "",
      preferredName: selectedPatient.preferredName || "",
      mrn: selectedPatient.mrn || "",
      last4ssn: selectedPatient.last4ssn || "",
      dob: selectedPatient.dob || "",
      age: selectedPatient.age || "",
      phone: selectedPatient.phone || "",
      sex: selectedPatient.sex || "",
      ethnicity: selectedPatient.ethnicity || "",
      pronouns: selectedPatient.pronouns || "",
      dailyNumber: selectedEncounter.dailyNumber || "",
      newReturning: selectedEncounter.newReturning || "",
      ttuStudent: selectedPatient.ttuStudent || false,
      visitLocation: selectedEncounter.visitLocation || "",
      chiefComplaint: selectedEncounter.chiefComplaint || "",
      notes: selectedEncounter.notes || "",
      transportation: selectedEncounter.transportation || "",
      needsElevator: selectedEncounter.needsElevator || false,
      spanishSpeaking: selectedEncounter.spanishSpeaking || false,
      over65: selectedPatient.age ? Number(selectedPatient.age) > 65 : false,
      mammogramStatus:
        selectedEncounter.mammogramStatus || selectedEncounter.mammogramPapSmear || "",
      papStatus: selectedEncounter.papStatus || "",
      fluShot: selectedEncounter.fluShot || "",
      htn: selectedEncounter.htn || false,
      dm: selectedEncounter.dm || false,
      labsLast6Months: selectedEncounter.labsLast6Months || "",
      nicotineUse: selectedEncounter.nicotineUse || "",
      nicotineDetails: selectedEncounter.nicotineDetails || "",
      substanceUseConcern: selectedEncounter.substanceUseConcern || "",
      substanceUseTreatment: selectedEncounter.substanceUseTreatment || "",
      substanceUseNotes: selectedEncounter.substanceUseNotes || "",
      dermatology: selectedEncounter.dermatology || "N/A",
      ophthalmology: selectedEncounter.ophthalmology || "N/A",
      optometry: selectedEncounter.optometry || "N/A",
      diabeticEyeExamPastYear: selectedEncounter.diabeticEyeExamPastYear || "N/A",
      physicalTherapy: selectedEncounter.physicalTherapy || "N/A",
      mentalHealthCombined: selectedEncounter.mentalHealthCombined || "N/A",
      counseling: selectedEncounter.counseling || "N/A",
      anyMentalHealthPositive: selectedEncounter.anyMentalHealthPositive || false,
      visitType: selectedEncounter.visitType || "general",
      specialtyType: selectedEncounter.specialtyType || "",
    });

    setEditingPatientId(selectedPatient.id);
    setIsEditingIntake(true);
    setIntakeTab(0);
    setShowIntakeModal(true);
  }

  function buildProgramEntriesFromIntake(patient, intakeForm, coordinatorName = "") {
    const entries = [];
    const createdAt = new Date().toISOString();

    function hasText(value) {
      return typeof value === "string" && value.trim() !== "" && value.trim() !== "N/A";
    }

    function buildReason(serviceValue, fallbackChiefComplaint, finalFallback = "") {
      if (hasText(serviceValue)) return serviceValue.trim();
      if (hasText(fallbackChiefComplaint)) return fallbackChiefComplaint.trim();
      if (hasText(finalFallback)) return finalFallback.trim();
      return "";
    }

    function pushEntry(programType, serviceValue, fallbackChiefComplaint, finalFallback = "") {
      const reason = buildReason(serviceValue, fallbackChiefComplaint, finalFallback);
      if (!reason) return;

      entries.push({
        id: Date.now() + Math.floor(Math.random() * 100000),
        patientId: patient.id,
        patientName: `${patient.firstName || ""} ${patient.lastName || ""}`.trim(),
        mrn: patient.mrn || "",
        dob: patient.dob || "",
        phone: patient.phone || "",
        programType,
        reason,
        assignedCoordinator: coordinatorName || "",
        status: "New Referral",
        specialtyDate: "",
        scheduleType: "",
        schedulePosition: null,
        appointmentSlot: "",
        notes: "",
        createdAt,
      });
    }

    const chiefComplaint = intakeForm.chiefComplaint || "";

    if (hasText(intakeForm.physicalTherapy)) {
      pushEntry("Physical Therapy", intakeForm.physicalTherapy, chiefComplaint);
    }

    if (hasText(intakeForm.dermatology)) {
      pushEntry("Dermatology", intakeForm.dermatology, chiefComplaint);
    }

    if (hasText(intakeForm.ophthalmology)) {
      pushEntry("Ophthalmology", intakeForm.ophthalmology, chiefComplaint);
    }

    if (hasText(intakeForm.mentalHealthCombined)) {
      pushEntry("Mental Health", intakeForm.mentalHealthCombined, chiefComplaint);
    }

    if (hasText(intakeForm.counseling)) {
      pushEntry("Counseling", intakeForm.counseling, chiefComplaint);
    }

    if (
      intakeForm.substanceUseTreatment === "Yes" ||
      intakeForm.substanceUseTreatment === "Maybe"
    ) {
      pushEntry(
        "Addiction Medicine",
        intakeForm.substanceUseNotes,
        chiefComplaint,
        "Substance use treatment requested"
      );

    }
    if (intakeForm.mammogramStatus === "Interested") {
      pushEntry(
        "Mammogram",
        "Mammogram screening requested",
        chiefComplaint,
        "Mammogram screening requested"
      );
    }

    if (intakeForm.colonoscopyStatus === "Interested") {
      pushEntry(
        "Colonoscopy",
        "Colonoscopy screening requested",
        chiefComplaint,
        "Colonoscopy screening requested"
      );
    }

    return entries;
  }

  async function createProgramEntriesFromIntake(patient, intakeForm) {
    const coordinatorName =
      profiles.find((profile) => profile.id === session?.user?.id)?.full_name || "";

    const entries = buildProgramEntriesFromIntake(patient, intakeForm, coordinatorName);

    if (entries.length === 0) return;

    const isCompletedProgramEntry = (entry) =>
      String(entry?.status || "").trim().toLowerCase() === "completed";

    for (const entry of entries) {
      const existingEntry = programEntries.find(
        (existing) =>
          String(existing.patientId) === String(entry.patientId) &&
          existing.programType === entry.programType &&
          !isCompletedProgramEntry(existing)
      );

      if (existingEntry) {
        const nextReason = existingEntry.reason?.includes(entry.reason)
          ? existingEntry.reason
          : `${existingEntry.reason || ""}${existingEntry.reason ? " | " : ""}${entry.reason}`;

        const nextNotes = [
          existingEntry.notes || "",
          entry.notes || entry.reason
            ? `Added from intake ${new Date().toLocaleDateString()}: ${entry.notes || entry.reason}`
            : "",
        ]
          .filter(Boolean)
          .join("\n");

        await updateProgramEntry(existingEntry.id, "reason", nextReason);
        await updateProgramEntry(existingEntry.id, "notes", nextNotes);
        continue;
      }

      await addProgramEntry(entry);
    }
  }

  async function submitPatient() {
    if (!intakeForm.firstName || !intakeForm.lastName || !intakeForm.dob || !intakeForm.chiefComplaint) {
      return;
    }
    if (intakeForm.mrn.trim() && mrnExists(patients, intakeForm.mrn, editingPatientId)) {
      window.alert("That MRN is already being used by another patient. Please use a different MRN.");
      return;
    }
    const potentialDuplicate = findPotentialDuplicatePatient(
      patients,
      intakeForm.firstName,
      intakeForm.lastName,
      intakeForm.dob,
      intakeForm.last4ssn,
      editingPatientId
    );

    if (potentialDuplicate) {
      const shouldContinue = window.confirm(
        `Possible duplicate found:\n\n${getFullPatientName(potentialDuplicate)}\nDOB: ${potentialDuplicate.dob || "—"}\nLast 4 SSN: ${potentialDuplicate.last4ssn || "—"}\nMRN: ${potentialDuplicate.mrn || "—"}\n\nPress OK to continue anyway, or Cancel to review.`
      );

      if (!shouldContinue) return;
    }

    if (isSubmittingIntakeRef.current) return;
    isSubmittingIntakeRef.current = true;
    setIsSubmittingIntake(true);

    if (isEditingIntake && selectedPatient && selectedEncounter) {
      try {
        console.log("editingPatientId:", editingPatientId);
        console.log("selectedEncounterId:", selectedEncounter.id);

        const savedPatient = await updatePatientInSupabase(editingPatientId, {
          firstName: intakeForm.firstName,
          lastName: intakeForm.lastName,
          preferredName: intakeForm.preferredName,
          dob: intakeForm.dob,
          ...(intakeForm.mrn.trim() ? { mrn: intakeForm.mrn.trim() } : {}),
          last4ssn: intakeForm.last4ssn,
          phone: intakeForm.phone,
          pronouns: intakeForm.pronouns,
          ethnicity: intakeForm.ethnicity,
          sex: intakeForm.sex,
          ttuStudent: intakeForm.ttuStudent,
        });

        console.log("savedPatient update worked:", savedPatient);
        const nextStatus = "ready";

        const savedEncounter = await updateEncounterInSupabase(selectedEncounter.id, {
          chiefComplaint: intakeForm.chiefComplaint,
          notes: intakeForm.notes,
          dailyNumber: intakeForm.dailyNumber,
          newReturning: intakeForm.newReturning,
          visitLocation: intakeForm.visitLocation,
          transportation: intakeForm.transportation,
          needsElevator: intakeForm.needsElevator,
          spanishSpeaking: intakeForm.spanishSpeaking,
          mammogramStatus: intakeForm.mammogramStatus,
          colonoscopyStatus: intakeForm.colonoscopyStatus,
          papStatus: intakeForm.papStatus,
          fluShot: intakeForm.fluShot,
          htn: intakeForm.htn,
          dm: intakeForm.dm,
          labsLast6Months: intakeForm.labsLast6Months,
          nicotineUse: intakeForm.nicotineUse,
          nicotineDetails: intakeForm.nicotineDetails,
          substanceUseConcern: intakeForm.substanceUseConcern,
          substanceUseTreatment: intakeForm.substanceUseTreatment,
          substanceUseNotes: intakeForm.substanceUseNotes,
          dermatology: intakeForm.dermatology,
          ophthalmology: intakeForm.ophthalmology,
          optometry: intakeForm.optometry,
          diabeticEyeExamPastYear: intakeForm.diabeticEyeExamPastYear,
          physicalTherapy: intakeForm.physicalTherapy,
          mentalHealthCombined: intakeForm.mentalHealthCombined,
          counseling: intakeForm.counseling,
          anyMentalHealthPositive: intakeForm.anyMentalHealthPositive,
          visitType: intakeForm.visitType,
          specialtyType: intakeForm.specialtyType,
          leadershipIntakeComplete: true,
          status: nextStatus,
        });

        console.log("savedEncounter update worked:", savedEncounter);

        setPatients((prev) =>
          prev.map((patient) =>
            patient.id === editingPatientId
              ? {
                ...patient,
                ...savedPatient,
                preferredName: intakeForm.preferredName,
                last4ssn: intakeForm.last4ssn,
                age: intakeForm.age,
                phone: intakeForm.phone,
                sex: intakeForm.sex,
                ethnicity: intakeForm.ethnicity,
                pronouns: intakeForm.pronouns,
                ttuStudent: intakeForm.ttuStudent,
                encounters: patient.encounters.map((encounter) =>
                  encounter.id === selectedEncounter.id
                    ? {
                      ...encounter,
                      status: nextStatus,
                      leadershipIntakeComplete: true,
                      dailyNumber: intakeForm.dailyNumber,
                      newReturning: intakeForm.newReturning,
                      visitLocation: intakeForm.visitLocation,
                      chiefComplaint: intakeForm.chiefComplaint,
                      notes: intakeForm.notes,
                      transportation: intakeForm.transportation,
                      needsElevator: intakeForm.needsElevator,
                      spanishSpeaking: intakeForm.spanishSpeaking,
                      mammogramStatus: intakeForm.mammogramStatus,
                      papStatus: intakeForm.papStatus,
                      fluShot: intakeForm.fluShot,
                      colonoscopyStatus: intakeForm.colonoscopyStatus,
                      htn: intakeForm.htn,
                      dm: intakeForm.dm,
                      labsLast6Months: intakeForm.labsLast6Months,
                      nicotineUse: intakeForm.nicotineUse,
                      nicotineDetails: intakeForm.nicotineDetails,
                      substanceUseConcern: intakeForm.substanceUseConcern,
                      substanceUseTreatment: intakeForm.substanceUseTreatment,
                      substanceUseNotes: intakeForm.substanceUseNotes,
                      dermatology: intakeForm.dermatology,
                      ophthalmology: intakeForm.ophthalmology,
                      optometry: intakeForm.optometry,
                      diabeticEyeExamPastYear: intakeForm.diabeticEyeExamPastYear,
                      physicalTherapy: intakeForm.physicalTherapy,
                      mentalHealthCombined: intakeForm.mentalHealthCombined,
                      counseling: intakeForm.counseling,
                      anyMentalHealthPositive: intakeForm.anyMentalHealthPositive,
                      visitType: intakeForm.visitType,
                      specialtyType: intakeForm.specialtyType,
                    }
                    : encounter
                ),
              }
              : patient
          )
        );
        await createProgramEntriesFromIntake(
          {
            ...selectedPatient,
            firstName: intakeForm.firstName,
            lastName: intakeForm.lastName,
            mrn: intakeForm.mrn.trim() || selectedPatient.mrn || "",
            dob: intakeForm.dob,
            phone: intakeForm.phone,
          },
          intakeForm
        );

        setShowIntakeModal(false);
        setIntakeTab(0);
        setIntakeMatchPatientId(null);
        setAutoFilledMatchPatientId(null);
        setIsEditingIntake(false);
        setEditingPatientId(null);
        setActiveView("registration");
        isSubmittingIntakeRef.current = false;
        setIsSubmittingIntake(false);
        return;
      } catch (error) {
        console.error("Failed to update intake in Supabase:", error);
        window.alert(`Supabase save error: ${error.message}`);
        isSubmittingIntakeRef.current = false;
        setIsSubmittingIntake(false);
        return;
      }
    }

    const baseEncounter = createEncounterFromIntake(intakeForm);

    const encounter = {
      ...baseEncounter,
      status: "ready",
      clinicDate: normalizeClinicDate(baseEncounter.clinicDate) || formatClinicDate(),
      createdAt: baseEncounter.createdAt || new Date().toISOString(),
    };


    if (potentialDuplicate) {
      try {
        const savedEncounter = await createEncounterInSupabase(
          potentialDuplicate.id,
          encounter
        );

        const intakeData = savedEncounter.intake_data || {};

        const hydratedEncounter = {
          ...encounter,
          id: savedEncounter.id,
          clinicDate: savedEncounter.clinic_date || encounter.clinicDate,
          createdAt: savedEncounter.created_at || encounter.createdAt,
          chiefComplaint:
            savedEncounter.chief_complaint || encounter.chiefComplaint || "",
          status: mapDbStatusToUi(savedEncounter.status),
          roomNumber: savedEncounter.room || encounter.roomNumber || "",

          dailyNumber: intakeData.dailyNumber ?? encounter.dailyNumber ?? "",
          newReturning: intakeData.newReturning ?? encounter.newReturning ?? "Returning",
          visitLocation: intakeData.visitLocation ?? encounter.visitLocation ?? "In Clinic",
          transportation: intakeData.transportation ?? encounter.transportation ?? "",
          needsElevator: intakeData.needsElevator ?? encounter.needsElevator ?? false,
          spanishSpeaking: intakeData.spanishSpeaking ?? encounter.spanishSpeaking ?? false,
          mammogramStatus:
            intakeData.mammogramStatus ??
            intakeData.mammogramPapSmear ??
            encounter.mammogramStatus ??
            encounter.mammogramPapSmear ??
            "",
          papStatus:
            intakeData.papStatus ??
            encounter.papStatus ??
            "",
          fluShot: intakeData.fluShot ?? encounter.fluShot ?? "",
          htn: intakeData.htn ?? encounter.htn ?? false,
          dm: intakeData.dm ?? encounter.dm ?? false,
          labsLast6Months:
            intakeData.labsLast6Months ?? encounter.labsLast6Months ?? "",
          nicotineUse: intakeData.nicotineUse ?? encounter.nicotineUse ?? "",
          nicotineDetails: intakeData.nicotineDetails ?? encounter.nicotineDetails ?? "",
          substanceUseConcern: intakeData.substanceUseConcern ?? encounter.substanceUseConcern ?? "",
          substanceUseTreatment: intakeData.substanceUseTreatment ?? encounter.substanceUseTreatment ?? "",
          substanceUseNotes: intakeData.substanceUseNotes ?? encounter.substanceUseNotes ?? "",
          dermatology: intakeData.dermatology ?? encounter.dermatology ?? "N/A",
          ophthalmology: intakeData.ophthalmology ?? encounter.ophthalmology ?? "N/A",
          optometry: intakeData.optometry ?? encounter.optometry ?? "N/A",
          diabeticEyeExamPastYear:
            intakeData.diabeticEyeExamPastYear ??
            encounter.diabeticEyeExamPastYear ??
            "N/A",
          physicalTherapy:
            intakeData.physicalTherapy ?? encounter.physicalTherapy ?? "N/A",
          mentalHealthCombined:
            intakeData.mentalHealthCombined ??
            encounter.mentalHealthCombined ??
            "N/A",
          counseling: intakeData.counseling ?? encounter.counseling ?? "N/A",
          anyMentalHealthPositive:
            intakeData.anyMentalHealthPositive ??
            encounter.anyMentalHealthPositive ??
            false,
          visitType: intakeData.visitType ?? encounter.visitType ?? "general",
          specialtyType: intakeData.specialtyType ?? encounter.specialtyType ?? "",
          importedSendOutLabs:
            savedEncounter.imported_send_out_labs ||
            savedEncounter.importedSendOutLabs ||
            encounter.importedSendOutLabs ||
            [],
        };

        setPatients((prev) =>
          prev.map((patient) =>
            patient.id === potentialDuplicate.id
              ? {
                ...patient,
                mrn: patient.mrn || intakeForm.mrn.trim(),
                firstName: intakeForm.firstName,
                lastName: intakeForm.lastName,
                preferredName: intakeForm.preferredName,
                last4ssn: intakeForm.last4ssn,
                dob: intakeForm.dob,
                age: intakeForm.age,
                phone: intakeForm.phone,
                sex: intakeForm.sex,
                ethnicity: intakeForm.ethnicity,
                pronouns: intakeForm.pronouns,
                ttuStudent: intakeForm.ttuStudent,
                encounters: [hydratedEncounter, ...(patient.encounters || [])],
              }
              : patient
          )
        );

        setSelectedPatientId(potentialDuplicate.id);
        setSelectedEncounterId(savedEncounter.id);
        await createProgramEntriesFromIntake(
          {
            ...potentialDuplicate,
            firstName: intakeForm.firstName,
            lastName: intakeForm.lastName,
            mrn: potentialDuplicate.mrn || intakeForm.mrn.trim() || "",
            dob: intakeForm.dob,
            phone: intakeForm.phone,
          },
          intakeForm
        );
      } catch (error) {
        console.error("Failed to create duplicate-patient encounter:", error);
        window.alert(`Supabase save error: ${error.message}`);
        isSubmittingIntakeRef.current = false;
        setIsSubmittingIntake(false);
        return;
      }
    } else {
      try {
        const patientToSave = {
          ...intakeForm,
          mrn: intakeForm.mrn.trim() || "",
        };

        const savedPatient = await createPatientInSupabase(patientToSave);

        const savedEncounter = await createEncounterInSupabase(savedPatient.id, encounter);

        const hydratedPatient = {
          ...savedPatient,
          preferredName: intakeForm.preferredName || savedPatient.preferredName || "",
          last4ssn: intakeForm.last4ssn || "",
          phone: intakeForm.phone || "",
          sex: intakeForm.sex || "",
          ethnicity: intakeForm.ethnicity || "",
          pronouns: intakeForm.pronouns || "",
          ttuStudent: intakeForm.ttuStudent || false,
          allergies: "",
          medications: [],
          encounters: [
            (() => {
              const intakeData = savedEncounter.intake_data || {};

              return {
                ...encounter,
                id: savedEncounter.id,
                clinicDate: savedEncounter.clinic_date || encounter.clinicDate,
                createdAt: savedEncounter.created_at || encounter.createdAt,
                chiefComplaint:
                  savedEncounter.chief_complaint || encounter.chiefComplaint || "",
                status: mapDbStatusToUi(savedEncounter.status),
                roomNumber: savedEncounter.room || encounter.roomNumber || "",

                dailyNumber:
                  intakeData.dailyNumber ?? encounter.dailyNumber ?? "",
                newReturning:
                  intakeData.newReturning ?? encounter.newReturning ?? "Returning",
                visitLocation:
                  intakeData.visitLocation ?? encounter.visitLocation ?? "In Clinic",
                transportation:
                  intakeData.transportation ?? encounter.transportation ?? "",
                needsElevator:
                  intakeData.needsElevator ?? encounter.needsElevator ?? false,
                spanishSpeaking:
                  intakeData.spanishSpeaking ?? encounter.spanishSpeaking ?? false,
                mammogramStatus:
                  intakeData.mammogramStatus ??
                  intakeData.mammogramPapSmear ??
                  encounter.mammogramStatus ??
                  encounter.mammogramPapSmear ??
                  "",
                papStatus:
                  intakeData.papStatus ??
                  encounter.papStatus ??
                  "",
                fluShot: intakeData.fluShot ?? encounter.fluShot ?? "",
                htn: intakeData.htn ?? encounter.htn ?? false,
                dm: intakeData.dm ?? encounter.dm ?? false,
                labsLast6Months:
                  intakeData.labsLast6Months ?? encounter.labsLast6Months ?? "",
                nicotineUse: intakeData.nicotineUse ?? encounter.nicotineUse ?? "",
                nicotineDetails: intakeData.nicotineDetails ?? encounter.nicotineDetails ?? "",
                substanceUseConcern: intakeData.substanceUseConcern ?? encounter.substanceUseConcern ?? "",
                substanceUseTreatment: intakeData.substanceUseTreatment ?? encounter.substanceUseTreatment ?? "",
                substanceUseNotes: intakeData.substanceUseNotes ?? encounter.substanceUseNotes ?? "",
                dermatology:
                  intakeData.dermatology ?? encounter.dermatology ?? "N/A",
                ophthalmology:
                  intakeData.ophthalmology ?? encounter.ophthalmology ?? "N/A",
                optometry:
                  intakeData.optometry ?? encounter.optometry ?? "N/A",
                diabeticEyeExamPastYear:
                  intakeData.diabeticEyeExamPastYear ??
                  encounter.diabeticEyeExamPastYear ??
                  "N/A",
                physicalTherapy:
                  intakeData.physicalTherapy ?? encounter.physicalTherapy ?? "N/A",
                mentalHealthCombined:
                  intakeData.mentalHealthCombined ??
                  encounter.mentalHealthCombined ??
                  "N/A",
                counseling:
                  intakeData.counseling ?? encounter.counseling ?? "N/A",
                anyMentalHealthPositive:
                  intakeData.anyMentalHealthPositive ??
                  encounter.anyMentalHealthPositive ??
                  false,
                visitType: intakeData.visitType ?? encounter.visitType ?? "",
                specialtyType: intakeData.specialtyType ?? encounter.specialtyType ?? "",
              };
            })(),
          ],
        };

        setPatients((prev) => [hydratedPatient, ...prev]);
        setSelectedPatientId(hydratedPatient.id);
        setSelectedEncounterId(savedEncounter.id);
        await createProgramEntriesFromIntake(hydratedPatient, intakeForm);
      } catch (error) {
        console.error("Supabase save error:", error);
        window.alert(`Supabase save error: ${error.message}`);
        isSubmittingIntakeRef.current = false;
        setIsSubmittingIntake(false);
        return;
      }
    }
    isSubmittingIntakeRef.current = false;
    setIsSubmittingIntake(false);
    setShowIntakeModal(false);
    setIntakeTab(0);
    setIntakeForm(EMPTY_FORM);
    setIntakeMatchPatientId(null);
    setIsEditingIntake(false);
    setEditingPatientId(null);
    setAutoFilledMatchPatientId(null);
    setActiveView("chart");
  }


  function openPatientFromFilteredView(patientId) {
    setDashboardSelectedPatientId(patientId);

    const matchingRows = visibleEncounterRows.filter(
      ({ patient }) => patient.id === patientId
    );

    if (matchingRows.length > 0) {
      openPatientChart(patientId, matchingRows[0].encounter.id);
      return;
    }

    openPatientChart(patientId);
  }

  function openPatientEditModal() {
    const patientForEdit = dashboardSelectedPatient || selectedPatient;

    if (!patientForEdit) {
      alert("Select a patient first.");
      return;
    }

    setDashboardSelectedPatientId(patientForEdit.id);
    setShowPatientInfoEditModal(true);
  }

  async function saveDashboardPatientEdits(patientId, updates, encounterId = null, encounterUpdates = null) {
    const trimmedMrn = (updates.mrn || "").trim();

    if (trimmedMrn && mrnExists(patients, trimmedMrn, patientId)) {
      alert("That MRN is already being used by another patient. Please use a different MRN.");
      return;
    }

    try {
      const savedPatient = await updatePatientInSupabase(patientId, {
        ...updates,
        mrn: trimmedMrn,
      });

      let savedEncounter = null;

      if (encounterId && encounterUpdates) {
        savedEncounter = await updateEncounterInSupabase(encounterId, encounterUpdates);
      }

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === patientId
            ? {
              ...patient,
              ...savedPatient,
              ...updates,
              mrn: trimmedMrn,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === encounterId
                  ? {
                    ...encounter,
                    ...(savedEncounter || {}),
                    ...(encounterUpdates || {}),
                  }
                  : encounter
              ),
            }
            : patient
        )
      );
    } catch (error) {
      console.error("Failed to save patient edits:", error);
      showToast({
        title: "Failed to save patient edits",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  function openPatientChart(patientId, encounterId = null) {
    const patient = patients.find((p) => p.id === patientId);
    if (!patient) return;

    let encounter = null;

    if (encounterId) {
      encounter = patient.encounters.find((e) => e.id === encounterId);
    } else if (selectedClinicDate) {
      encounter =
        patient.encounters.find(
          (e) => normalizeClinicDate(e.clinicDate) === selectedClinicDate
        ) || patient.encounters[0];
    } else {
      encounter = patient.encounters[0];
    }

    setSelectedPatientId(patientId);
    setDashboardSelectedPatientId(patientId);
    setSelectedEncounterId(encounter?.id || null);

    setAssignmentForm({
      studentName: encounter?.assignedStudent || "",
      upperLevelName: encounter?.assignedUpperLevel || "",
      roomNumber: encounter?.roomNumber || "",
    });

    setCurrentVitals(EMPTY_VITALS);
    setEditingVitalsIndex(null);
    setNewMedication(EMPTY_MEDICATION);
    setEditingMedicationId(null);
    setShowMedicationModal(false);
    setActiveView("chart");
  }
  async function startNewEncounter() {
    if (!selectedPatient) return;
    if (!(userRole === "leadership" || userRole === "undergraduate")) return;

    const newEncounter = {
      id: Date.now(),
      clinicDate: formatClinicDate(),
      createdAt: new Date().toISOString(),
      newReturning: "Returning",
      visitLocation: "In Clinic",
      chiefComplaint: "",
      notes: "",
      transportation: "",
      needsElevator: false,
      spanishSpeaking: false,
      mammogramStatus: "",
      papStatus: "",
      fluShot: "",
      htn: false,
      dm: false,
      labsLast6Months: "",
      nicotineUse: "",
      nicotineDetails: "",
      substanceUseConcern: "",
      substanceUseTreatment: "",
      substanceUseNotes: "",
      dermatology: "N/A",
      ophthalmology: "N/A",
      optometry: "N/A",
      diabeticEyeExamPastYear: "N/A",
      physicalTherapy: "N/A",
      mentalHealthCombined: "N/A",
      counseling: "N/A",
      anyMentalHealthPositive: false,
      status: "started",
      assignedStudent: "",
      assignedUpperLevel: "",
      roomNumber: "",
      vitalsHistory: [],
      soapSubjective: "",
      soapObjective: "",
      soapAssessment: "",
      soapPlan: "",
      soapSavedAt: "",
    };

    try {
      const savedEncounter = await createEncounterInSupabase(
        selectedPatient.id,
        newEncounter
      );

      const hydratedEncounter = {
        ...newEncounter,
        id: savedEncounter.id,
        clinicDate: savedEncounter.clinic_date || newEncounter.clinicDate,
        createdAt: savedEncounter.created_at || newEncounter.createdAt,
        chiefComplaint:
          savedEncounter.chief_complaint || newEncounter.chiefComplaint || "",
        status: mapDbStatusToUi(savedEncounter.status),
        roomNumber: savedEncounter.room || "",
      };

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: [hydratedEncounter, ...patient.encounters],
            }
            : patient
        )
      );

      setSelectedEncounterId(savedEncounter.id);
      setAssignmentForm({
        studentName: "",
        upperLevelName: "",
        roomNumber: "",
      });
      setCurrentVitals(EMPTY_VITALS);
      setEditingVitalsIndex(null);
    } catch (error) {
      console.error("Failed to start new encounter:", error);
      window.alert(`Supabase save error: ${error.message}`);
    }
  }

  async function deleteEncounter(encounterId) {
    if (!selectedPatient || !encounterId) return;
    if (!(userRole === "leadership" || userRole === "undergraduate")) return;

    const confirmed = window.confirm(
      "Delete this encounter? This cannot be undone."
    );
    if (!confirmed) return;

    try {
      await deleteEncounterInSupabase(encounterId);

      const remainingEncounters = selectedPatient.encounters.filter(
        (encounter) => encounter.id !== encounterId
      );

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: remainingEncounters,
            }
            : patient
        )
      );

      if (selectedEncounterId === encounterId) {
        setSelectedEncounterId(remainingEncounters[0]?.id || null);
      }
    } catch (error) {
      console.error("Failed to delete encounter:", error);
      alert(`Failed to delete encounter: ${error.message}`);
    }
  }

  function lockLeadershipActions() {
    setLeadershipActionLocked(true);
    window.setTimeout(() => {
      setLeadershipActionLocked(false);
    }, 800);
  }
  function updateEncounterField(field, value) {
    if (!selectedPatient || !selectedEncounter) return;

    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? {
            ...patient,
            encounters: patient.encounters.map((encounter) =>
              encounter.id === selectedEncounter.id
                ? { ...encounter, [field]: value }
                : encounter
            ),
          }
          : patient
      )
    );
  }

  async function saveEncounterField(field, value) {
    if (!selectedEncounter) return;

    try {
      await updateEncounterInSupabase(selectedEncounter.id, {
        [field]: value,
      });
    } catch (error) {
      console.error(`Failed to save ${field}:`, error);
      alert(`Failed to save ${field}: ${error.message}`);
    }
  }

  function updateSoapDraftField(field, value) {
    setSoapDraft((prev) => {
      if (field === "ophthalmologyNote") {
        return {
          ...prev,
          ophthalmologyNote: {
            ...EMPTY_OPHTHO_NOTE,
            ...(value || {}),
          },
        };
      }

      return {
        ...prev,
        [field]: value,
      };
    });
  }

  async function saveInHouseLabs(nextLabs) {
    if (!selectedPatient || !selectedEncounter) return;

    try {
      await updateEncounterInSupabase(selectedEncounter.id, {
        inHouseLabs: nextLabs,
      });

      updateEncounterField("inHouseLabs", nextLabs);
    } catch (error) {
      console.error("Failed to save in-house labs:", error);
      alert(`Failed to save in-house labs: ${error.message}`);
    }
  }

  async function saveSendOutLabs(nextLabs) {
    if (!selectedPatient || !selectedEncounter) return;

    try {
      await updateEncounterInSupabase(selectedEncounter.id, {
        sendOutLabs: nextLabs,
      });

      updateEncounterField("sendOutLabs", nextLabs);
    } catch (error) {
      console.error("Failed to save send-out labs:", error);
      alert(`Failed to save send-out labs: ${error.message}`);
    }
  }

  async function applyEncounterTransition(encounterId, updates) {
    await updateEncounterInSupabase(encounterId, updates);

    setPatients((prev) =>
      prev.map((patient) => ({
        ...patient,
        encounters: patient.encounters.map((encounter) =>
          encounter.id === encounterId
            ? { ...encounter, ...updates }
            : encounter
        ),
      }))
    );
  }

  async function markMedicationsReady(encounterId) {
    if (!session?.user?.id) return;

    await updateEncounterInSupabase(encounterId, {
      pharmacyStatus: "meds_ready",
      pharmacyReadyAt: new Date().toISOString(),
      pharmacyReadyBy: session.user.id,
      pharmacyNotifiedAt: null,
      pharmacyNotifiedBy: null,
    });

    refreshClinicData?.();
  }

  async function markPatientSentToPharmacy(encounterId) {
    if (!session?.user?.id) return;

    await updateEncounterInSupabase(encounterId, {
      pharmacyStatus: "patient_sent",
      pharmacyNotifiedAt: new Date().toISOString(),
      pharmacyNotifiedBy: session.user.id,
    });

    refreshClinicData?.();
  }

  async function markMedicationsPickedUp(encounterId) {
    if (!session?.user?.id) return;

    const targetEncounter = allEncounterRows
      .map(({ encounter }) => encounter)
      .find((encounter) => encounter?.id === encounterId);

    const pickedUpAt = new Date().toISOString();
    const updates = {
      pharmacyStatus: "picked_up",
      pharmacyPickedUpAt: pickedUpAt,
      pharmacyNotifiedAt: pickedUpAt,
      pharmacyNotifiedBy: session.user.id,
    };

    if (targetEncounter?.visitType === "refill_only") {
      updates.status = "done";
      updates.doneAt = targetEncounter.doneAt || pickedUpAt;
      updates.visitCompletedAt = targetEncounter.visitCompletedAt || pickedUpAt;
    }

    await updateEncounterInSupabase(encounterId, updates);

    refreshClinicData?.();
  }

  async function finalizeClinicDay(rowsToFinalize = []) {
    if (!isLeadershipView) return;

    const rows = rowsToFinalize.filter(({ encounter }) => encounter?.id);
    if (rows.length === 0) return;

    const finalizedAt = new Date().toISOString();

    function isRefillOnly(encounter) {
      return (encounter?.visitType || encounter?.visit_type) === "refill_only";
    }

    await Promise.all(
      rows.map(({ encounter }) => {
        const pharmacyStatus =
          encounter.pharmacyStatus || encounter.pharmacy_status || "";

        const updates = {
          status: "done",
          doneAt: encounter.doneAt || encounter.done_at || finalizedAt,
          visitCompletedAt:
            encounter.visitCompletedAt ||
            encounter.visit_completed_at ||
            finalizedAt,
        };

        if (isRefillOnly(encounter)) {
          if (pharmacyStatus === "meds_ready" || pharmacyStatus === "patient_sent") {
            updates.pharmacyStatus = "meds_not_picked_up";
          } else if (!pharmacyStatus || pharmacyStatus === "waiting") {
            updates.pharmacyStatus = "no_meds_needed";
          }
        }

        return updateEncounterInSupabase(encounter.id, updates);
      })
    );

    const finalizedIds = new Set(rows.map(({ encounter }) => String(encounter.id)));

    setPatients((prev) =>
      prev.map((patient) => ({
        ...patient,
        encounters: patient.encounters.map((encounter) =>
          finalizedIds.has(String(encounter.id))
            ? {
              ...encounter,
              status: "done",
              doneAt: encounter.doneAt || finalizedAt,
              visitCompletedAt: encounter.visitCompletedAt || finalizedAt,
              ...(((encounter.visitType || encounter.visit_type) === "refill_only" &&
                (encounter.pharmacyStatus === "meds_ready" ||
                  encounter.pharmacyStatus === "patient_sent"))
                ? { pharmacyStatus: "meds_not_picked_up" }
                : {}),
              ...(((encounter.visitType || encounter.visit_type) === "refill_only" &&
                (!encounter.pharmacyStatus || encounter.pharmacyStatus === "waiting"))
                ? { pharmacyStatus: "no_meds_needed" }
                : {}),
            }
            : encounter
        ),
      }))
    );

    refreshClinicData?.();
  }

  async function clearPharmacyStatus(encounterId) {
    await updateEncounterInSupabase(encounterId, {
      pharmacyStatus: "",
      pharmacyReadyAt: null,
      pharmacyReadyBy: null,
      pharmacyNotifiedAt: null,
      pharmacyNotifiedBy: null,
    });

    refreshClinicData?.();
  }

  async function updateLabTracking(encounterId, updates) {
    const nextUpdates = {
      ...updates,
    };

    await updateEncounterInSupabase(encounterId, nextUpdates);

    setPatients((prev) =>
      prev.map((patient) => ({
        ...patient,
        encounters: patient.encounters.map((encounter) =>
          encounter.id === encounterId
            ? { ...encounter, ...nextUpdates }
            : encounter
        ),
      }))
    );

    refreshClinicData?.();
  }

  async function assignEncounterFromQueue(encounterId, updates) {
    if (!canManageRooms) return;

    const targetRow = allEncounterRows.find(
      ({ encounter }) => encounter.id === encounterId
    );
    if (!targetRow) return;

    const { patient, encounter } = targetRow;

    const nextStudent =
      updates.assignedStudent !== undefined
        ? updates.assignedStudent
        : encounter.assignedStudent || "";

    const nextUpperLevel =
      updates.assignedUpperLevel !== undefined
        ? updates.assignedUpperLevel
        : encounter.assignedUpperLevel || "";

    const nextRoomNumber =
      updates.roomNumber !== undefined
        ? updates.roomNumber
        : encounter.roomNumber || "";

    if (!nextRoomNumber) {
      showToast({
        title: "Room required",
        message: "Please select a room before assigning this patient.",
        type: "warning",
      });
      return;
    }

    if (!nextStudent && !nextUpperLevel) {
      showToast({
        title: "Assignee required",
        message: "Please assign a student or upper level before starting the visit.",
        type: "warning",
      });
      return;
    }

    const numericRoom = Number(nextRoomNumber);

    if (!canAssignRoom(encounter, numericRoom)) {
      showToast({
        title: "Room restriction",
        message: "Pap smear patients cannot be assigned to Room 9 or Room 10.",
        type: "warning",
      });
      return;
    }

    const conflict = getRoomConflictDetails(numericRoom, encounterId, {
      assignedStudent: nextStudent,
      assignedUpperLevel: nextUpperLevel,
      clinicDate: encounter.clinicDate,
    });

    if (conflict.hasConflict) {
      const confirmed = window.confirm(
        `This room is currently being used by a different student/provider (${conflict.occupiedByNames.join(", ")}). Assign anyway?`
      );

      if (!confirmed) {
        return;
      }
    }

    try {
      const studentChanged =
        String(nextStudent || "").trim() !== String(encounter.assignedStudent || "").trim();

      const upperLevelChanged =
        String(nextUpperLevel || "").trim() !== String(encounter.assignedUpperLevel || "").trim();

      await applyEncounterTransition(encounterId, {
        assignedStudent: nextStudent,
        assignedUpperLevel: nextUpperLevel,
        roomNumber: String(numericRoom),
        status: "in_visit",

        studentAssignedAt:
          nextStudent && (!encounter.studentAssignedAt || studentChanged)
            ? new Date().toISOString()
            : encounter.studentAssignedAt || null,

        upperLevelAssignedAt:
          nextUpperLevel && (!encounter.upperLevelAssignedAt || upperLevelChanged)
            ? new Date().toISOString()
            : encounter.upperLevelAssignedAt || null,

        skipUpperLevel: nextUpperLevel ? false : encounter.skipUpperLevel,
        skipUpperLevelBy: nextUpperLevel ? null : encounter.skipUpperLevelBy,
        skipUpperLevelAt: nextUpperLevel ? null : encounter.skipUpperLevelAt,
      });

    } catch (error) {
      console.error("Failed to assign encounter from queue:", error);
      showToast({
        title: "Failed to save assignment",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  async function assignEncounter() {
    if (!canManageRooms) return;
    if (leadershipActionLocked) return;
    if (!selectedPatient || !selectedEncounter) return;

    if (!assignmentForm.roomNumber) {
      showToast({
        title: "Room required",
        message: "Please select a room before assigning this patient.",
        type: "warning",
      });
      return;
    }

    if (!assignmentForm.studentName && !assignmentForm.upperLevelName) {
      showToast({
        title: "Assignee required",
        message: "Please assign a student or upper level before starting the visit.",
        type: "warning",
      });
      return;
    }

    const roomNumber = Number(assignmentForm.roomNumber);

    if (!canAssignRoom(selectedEncounter, roomNumber)) {
      showToast({
        title: "Room restriction",
        message: "Pap smear patients cannot be assigned to Room 9 or Room 10.",
        type: "warning",
      });
      return;
    }

    const nextAssignedStudent =
      assignmentForm.studentName || selectedEncounter.assignedStudent || "";

    const nextAssignedUpperLevel =
      assignmentForm.upperLevelName || selectedEncounter.assignedUpperLevel || "";

    const conflict = getRoomConflictDetails(roomNumber, selectedEncounter.id, {
      assignedStudent: nextAssignedStudent,
      assignedUpperLevel: nextAssignedUpperLevel,
      clinicDate: selectedEncounter.clinicDate,
    });

    if (conflict.hasConflict) {
      const confirmed = window.confirm(
        `This room is currently being used by a different student/provider (${conflict.occupiedByNames.join(", ")}). Assign anyway?`
      );

      if (!confirmed) {
        return;
      }
    }
    lockLeadershipActions();

    try {
      const studentChanged =
        String(nextAssignedStudent || "").trim() !== String(selectedEncounter.assignedStudent || "").trim();

      const upperLevelChanged =
        String(nextAssignedUpperLevel || "").trim() !== String(selectedEncounter.assignedUpperLevel || "").trim();

      await applyEncounterTransition(selectedEncounter.id, {
        roomNumber: String(roomNumber),
        status: "in_visit",
        assignedStudent: nextAssignedStudent,
        assignedUpperLevel: nextAssignedUpperLevel,

        studentAssignedAt:
          nextAssignedStudent && (!selectedEncounter.studentAssignedAt || studentChanged)
            ? new Date().toISOString()
            : selectedEncounter.studentAssignedAt || null,

        upperLevelAssignedAt:
          nextAssignedUpperLevel && (!selectedEncounter.upperLevelAssignedAt || upperLevelChanged)
            ? new Date().toISOString()
            : selectedEncounter.upperLevelAssignedAt || null,

        skipUpperLevel: nextAssignedUpperLevel ? false : selectedEncounter.skipUpperLevel,
        skipUpperLevelBy: nextAssignedUpperLevel ? null : selectedEncounter.skipUpperLevelBy,
        skipUpperLevelAt: nextAssignedUpperLevel ? null : selectedEncounter.skipUpperLevelAt,
      });

    } catch (error) {
      console.error("Failed to assign encounter:", error);
      showToast({
        title: "Failed to assign room",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }
  async function assignEncounterToRoom(roomNumber) {
    if (!canManageRooms) return;
    if (!selectedPatient || !selectedEncounter) {
      showToast({
        title: "No chart open",
        message: "Open a patient chart first before assigning a room.",
        type: "warning",
      });
      return;
    }

    const numericRoom = Number(roomNumber);

    if (!canAssignRoom(selectedEncounter, numericRoom)) {
      showToast({
        title: "Room restriction",
        message: "Pap smear patients cannot be assigned to Room 9 or Room 10.",
        type: "warning",
      });
      return;
    }

    const conflict = getRoomConflictDetails(numericRoom, selectedEncounter.id, {
      assignedStudent: assignmentForm.studentName || selectedEncounter.assignedStudent,
      assignedUpperLevel: assignmentForm.upperLevelName || selectedEncounter.assignedUpperLevel,
    });

    if (conflict.hasConflict) {
      const confirmed = window.confirm(
        `This room is currently being used by a different student/provider (${conflict.occupiedByNames.join(", ")}). Select it anyway?`
      );

      if (!confirmed) {
        return;
      }
    }

    setAssignmentForm((prev) => ({
      ...prev,
      roomNumber: String(numericRoom),
    }));
  }
  async function deletePatientCompletely(patientId) {
    const patientToDelete = patients.find(
      (patient) => String(patient.id) === String(patientId)
    );

    const confirmed = window.confirm(
      "Delete this patient completely? This cannot be undone."
    );
    if (!confirmed) return;

    try {
      await deletePapEntriesForPatient(patientId);
      await deleteProgramEntriesForPatient(
        patientId,
        patientToDelete ? getFullPatientName(patientToDelete) : "",
        patientToDelete?.dob || ""
      );
      await deleteRefillRequestsForPatient(patientId);
      await deletePatientInSupabase(patientId);

      setPapEntries((prev) =>
        prev.filter((entry) => String(entry.patientId) !== String(patientId))
      );

      setProgramEntries((prev) =>
        prev.filter((entry) => String(entry.patientId) !== String(patientId))
      );

      setRefillRequests((prev) =>
        prev.filter((req) => String(req.patient_id) !== String(patientId))
      );

      setPatients((prev) => prev.filter((p) => p.id !== patientId));

      if (String(selectedPatientId) === String(patientId)) {
        setSelectedPatientId(null);
        setSelectedEncounterId(null);
      }
    } catch (error) {
      console.error("Delete failed:", error);
      alert(error.message);
    }
  }

  async function updateEncounterStatus(status) {
    if (!canManageRooms) return;
    if (leadershipActionLocked) return;
    if (!selectedEncounter) return;

    lockLeadershipActions();

    const updates =
      status === "ready"
        ? {
          status: "ready",
          roomNumber: "",
          assignedStudent: "",
          assignedUpperLevel: "",
          studentAssignedAt: null,
          upperLevelAssignedAt: null,
          skipUpperLevel: false,
          skipUpperLevelBy: null,
          skipUpperLevelAt: null,
        }
        : { status };

    try {
      await applyEncounterTransition(selectedEncounter.id, updates);
    } catch (error) {
      console.error("Failed to update encounter status:", error);
      showToast({
        title: "Failed to update status",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }
  async function clearEncounterRoom() {
    if (!canManageRooms) return;
    if (leadershipActionLocked) return;
    if (!selectedPatient || !selectedEncounter) return;

    lockLeadershipActions();

    try {
      await applyEncounterTransition(selectedEncounter.id, {
        status: "done",
        visitCompletedAt:
          selectedEncounter.visitCompletedAt || new Date().toISOString(),
      });
    } catch (error) {
      console.error("Failed to complete visit / free room:", error);
      showToast({
        title: "Failed to complete visit",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  function updatePatientField(field, value) {
    if (!selectedPatient) return;

    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? { ...patient, [field]: value }
          : patient
      )
    );
  }

  function updateVitalsField(field, value) {
    setCurrentVitals((prev) => {
      const next = { ...prev };

      if (field === "bp") next.bp = normalizeBp(value);
      else if (field === "temp") next.temp = value.replace(/[^\d.]/g, "").slice(0, 5);
      else if (field === "spo2") {
        const digits = value.replace(/[^\d]/g, "").slice(0, 3);
        let num = digits ? Number(digits) : "";
        if (num !== "" && num > 100) num = 100;
        next.spo2 = num === "" ? "" : String(num);
      } else if (field === "weight") next.weight = value.replace(/[^\d.]/g, "").slice(0, 6);
      else if (field === "height") next.height = normalizeHeight(value);
      else if (field === "pain") next.pain = normalizePain(value);
      else if (field === "hr" || field === "rr") next[field] = value.replace(/[^\d]/g, "").slice(0, 3);
      else next[field] = value;

      next.bmi = calculateBmi(next.weight, next.height);
      return next;
    });
  }

  async function saveVitals() {
    if (!selectedPatient || !selectedEncounter) return;

    const hasAnyValue = Object.values(currentVitals).some((value) => value.trim() !== "");
    if (!hasAnyValue) return;

    const vitalsEntry = {
      ...currentVitals,
      recordedAt: new Date().toLocaleString(),
    };

    const existingHistory = selectedEncounter.vitalsHistory || [];

    const nextVitalsHistory =
      editingVitalsIndex !== null
        ? existingHistory.map((entry, index) =>
          index === editingVitalsIndex
            ? { ...entry, ...vitalsEntry }
            : entry
        )
        : [vitalsEntry, ...existingHistory];

    try {
      await updateEncounterInSupabase(selectedEncounter.id, {
        vitalsHistory: nextVitalsHistory,
      });

      setPatients((prev) =>
        prev.map((patient) => {
          if (patient.id !== selectedPatient.id) return patient;

          return {
            ...patient,
            encounters: patient.encounters.map((encounter) => {
              if (encounter.id !== selectedEncounter.id) return encounter;

              return {
                ...encounter,
                vitalsHistory: nextVitalsHistory,
              };
            }),
          };
        })
      );

      setCurrentVitals(EMPTY_VITALS);
      setEditingVitalsIndex(null);
    } catch (error) {
      console.error("Failed to save vitals:", error);
      alert(`Failed to save vitals: ${error.message}`);
    }

    setCurrentVitals(EMPTY_VITALS);
    setEditingVitalsIndex(null);
  }


  function startEditVitals(entry, index) {
    setCurrentVitals({
      bp: entry.bp || "",
      hr: entry.hr || "",
      temp: entry.temp || "",
      rr: entry.rr || "",
      spo2: entry.spo2 || "",
      weight: entry.weight || "",
      height: entry.height || "",
      bmi: entry.bmi || "",
      pain: entry.pain || "",
    });
    setEditingVitalsIndex(index);
  }
  async function prescribeFromFormulary(item) {
    if (!canPrescribeMeds) return;
    if (!selectedPatient || !selectedEncounter) {
      alert("Open a patient chart first before prescribing.");
      return;
    }

    const medicationToAdd = {
      name: item.name || "",
      dosage: item.strength || "",
      frequency: "Daily",
      route: item.dosageForm || "",
      dispenseAmount: "",
      refillCount: "",
      instructions: "",
      isActive: true,
    };

    const tempMedicationId = `temp-rx-${Date.now()}`;

    const optimisticMedication = {
      id: tempMedicationId,
      ...medicationToAdd,
    };

    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? {
            ...patient,
            medicationList: [
              ...(patient.medicationList || []),
              optimisticMedication,
            ],
          }
          : patient
      )
    );

    setActiveView("chart");

    try {
      const savedMedication = await createMedicationInSupabase(
        selectedPatient.id,
        medicationToAdd,
        selectedEncounter.id
      );

      const hydratedMedication = {
        id: savedMedication.id,
        name: savedMedication.name || "",
        dosage: savedMedication.dosage || "",
        frequency: savedMedication.frequency || "",
        route: savedMedication.route || "",
        isActive: savedMedication.is_active ?? true,
      };

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              medicationList: (patient.medicationList || []).map((med) =>
                med.id === tempMedicationId ? hydratedMedication : med
              ),
            }
            : patient
        )
      );
    } catch (error) {
      console.error("Failed to prescribe medication:", error);
      showToast({
        title: "Failed to prescribe medication",
        message: error.message,
        type: "error",
        duration: 5000,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              medicationList: (patient.medicationList || []).filter(
                (med) => med.id !== tempMedicationId
              ),
            }
            : patient
        )
      );
    }
  }
  async function addOrUpdateMedication() {
    if (!selectedPatient || !selectedEncounter) return;
    if (!newMedication.name.trim()) return;

    if (editingMedicationId !== null) {
      const previousMedications = selectedPatient.medicationList || [];

      const optimisticMedications = previousMedications.map((med) =>
        med.id === editingMedicationId
          ? {
            ...med,
            ...newMedication,
            id: editingMedicationId,
            startedDate:
              newMedication.startedDate ||
              newMedication.medicationStartedAt ||
              med.startedDate ||
              med.medicationStartedAt ||
              "",
            medicationStartedAt:
              newMedication.medicationStartedAt ||
              newMedication.startedDate ||
              med.medicationStartedAt ||
              med.startedDate ||
              "",
            lastUpdatedEncounterId: selectedEncounter.id,
          }
          : med
      );

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              medicationList: optimisticMedications,
            }
            : patient
        )
      );

      setNewMedication(EMPTY_MEDICATION);
      setEditingMedicationId(null);
      setShowMedicationModal(false);

      try {
        await updateMedicationInSupabase(editingMedicationId, {
          ...newMedication,
          lastUpdatedEncounterId: selectedEncounter.id,
        });
      } catch (error) {
        console.error("Failed to save medication:", error);
        showToast({
          title: "Failed to save medication",
          message: error.message,
          type: "error",
          duration: 5000,
        });

        setPatients((prev) =>
          prev.map((patient) =>
            patient.id === selectedPatient.id
              ? {
                ...patient,
                medicationList: previousMedications,
              }
              : patient
          )
        );
      }

      return;
    }

    const tempMedicationId = `temp-${Date.now()}`;

    const optimisticMedication = {
      id: tempMedicationId,
      name: newMedication.name || "",
      dosage: newMedication.dosage || "",
      frequency: newMedication.frequency || "",
      route: newMedication.route || "",
      dispenseAmount: newMedication.dispenseAmount || "",
      refillCount: newMedication.refillCount || "",
      instructions: newMedication.instructions || "",
      lastUpdatedEncounterId: selectedEncounter.id,
      isActive: newMedication.isActive ?? true,
      startedDate:
        newMedication.startedDate ||
        newMedication.medicationStartedAt ||
        new Date().toISOString().slice(0, 10),
      medicationStartedAt:
        newMedication.medicationStartedAt ||
        newMedication.startedDate ||
        new Date().toISOString().slice(0, 10),
    };
    setPatients((prev) =>
      prev.map((patient) =>
        patient.id === selectedPatient.id
          ? {
            ...patient,
            medicationList: [
              ...(patient.medicationList || []),
              optimisticMedication,
            ],
          }
          : patient
      )
    );

    setNewMedication(EMPTY_MEDICATION);
    setEditingMedicationId(null);
    setShowMedicationModal(false);

    try {
      const savedMedication = await createMedicationInSupabase(
        selectedPatient.id,
        newMedication,
        selectedEncounter.id
      );

      const hydratedMedication = {
        id: savedMedication.id,
        name: savedMedication.name || "",
        dosage: savedMedication.dosage || "",
        frequency: savedMedication.frequency || "",
        route: savedMedication.route || "",
        dispenseAmount: savedMedication.dispense_amount ?? "",
        refillCount: savedMedication.refill_count ?? "",
        instructions: savedMedication.instructions || "",
        lastUpdatedEncounterId: savedMedication.last_updated_encounter_id || null,
        isActive: savedMedication.is_active ?? true,
        startedDate: savedMedication.medication_started_at || "",
        medicationStartedAt: savedMedication.medication_started_at || "",
      };

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              medicationList: (patient.medicationList || []).map((med) =>
                med.id === tempMedicationId ? hydratedMedication : med
              ),
            }
            : patient
        )
      );
    } catch (error) {
      console.error("Failed to save medication:", error);
      showToast({
        title: "Failed to save medication",
        message: error.message,
        type: "error",
        duration: 5000,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              medicationList: (patient.medicationList || []).filter(
                (med) => med.id !== tempMedicationId
              ),
            }
            : patient
        )
      );
    }
  }

  async function submitRefillRequestFromModal() {
    if (!selectedPatient || !refillSourceMedicationId || !session?.user?.id) return;
    if (!newMedication.name?.trim()) return;

    try {
      await handleCreateRefillRequest(
        selectedPatient.id,
        refillSourceMedicationId,
        session.user.id,
        {
          name: newMedication.name || "",
          dosage: newMedication.dosage || "",
          frequency: newMedication.frequency || "",
          route: newMedication.route || "",
          dispenseAmount: newMedication.dispenseAmount || "",
          refillCount: newMedication.refillCount || "",
          instructions: newMedication.instructions || "",
          isActive: newMedication.isActive ?? true,
        }
      );

      setShowMedicationModal(false);
      setNewMedication(EMPTY_MEDICATION);
      setEditingMedicationId(null);
      setIsRefillRequestMode(false);
      setRefillSourceMedicationId(null);

      showToast({
        title: "Refill submitted",
        message: "The refill request was saved and is now pending approval.",
        type: "success",
      });
    } catch (error) {
      console.error("Failed to create refill request:", error);
      alert(`Failed to create refill request: ${error.message}`);
    }
  }

  function startEditMedication(med) {
    setNewMedication({
      name: med.name || "",
      dosage: med.dosage || "",
      frequency: med.frequency || "",
      route: med.route || "",
      dispenseAmount: med.dispenseAmount || "",
      refillCount: med.refillCount || "",
      instructions: med.instructions || "",
      isActive: med.isActive,
      startedDate:
        med.startedDate ||
        med.medicationStartedAt ||
        med.medication_started_at ||
        "",
      medicationStartedAt:
        med.medicationStartedAt ||
        med.medication_started_at ||
        med.startedDate ||
        "",
    });
    setEditingMedicationId(med.id);
    setShowMedicationModal(true);
  }

  function startRefillRequest(med) {
    setNewMedication({
      name: med.name || "",
      dosage: med.dosage || "",
      frequency: med.frequency || "",
      route: med.route || "",
      dispenseAmount: med.dispenseAmount || "",
      refillCount: med.refillCount || "",
      instructions: med.instructions || "",
      isActive: med.isActive ?? true,
      startedDate:
        med.startedDate ||
        med.medicationStartedAt ||
        med.medication_started_at ||
        "",
      medicationStartedAt:
        med.medicationStartedAt ||
        med.medication_started_at ||
        med.startedDate ||
        "",
    });

    setEditingMedicationId(null);
    setIsRefillRequestMode(true);
    setRefillSourceMedicationId(med.id);
    setShowMedicationModal(true);
  }

  async function toggleMedicationActive(medicationId) {
    if (!selectedPatient || !selectedEncounter) return;

    const existingMedication = (selectedPatient.medicationList || []).find(
      (med) => med.id === medicationId
    );
    if (!existingMedication) return;

    const nextIsActive = !existingMedication.isActive;

    try {
      await updateMedicationInSupabase(medicationId, {
        isActive: nextIsActive,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              medicationList: (patient.medicationList || []).map((med) =>
                med.id === medicationId
                  ? { ...med, isActive: nextIsActive }
                  : med
              ),
            }
            : patient
        )
      );
    } catch (error) {
      console.error("Failed to toggle medication:", error);
      showToast({
        title: "Failed to update medication",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  async function deleteMedication(medicationId) {
    if (!selectedPatient || !selectedEncounter) return;

    const confirmed = window.confirm("Delete this medication?");
    if (!confirmed) return;

    try {
      const previousMedications = selectedPatient.medicationList || [];

      // 🔥 optimistic update FIRST
      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              medicationList: previousMedications.filter(
                (med) => med.id !== medicationId
              ),
            }
            : patient
        )
      );

      try {
        await deleteMedicationInSupabase(medicationId);
      } catch (error) {
        console.error("Failed to delete medication:", error);
        showToast({
          title: "Failed to delete medication",
          message: error.message,
          type: "error",
          duration: 5000,
        });

        // 🔁 rollback if failure
        setPatients((prev) =>
          prev.map((patient) =>
            patient.id === selectedPatient.id
              ? {
                ...patient,
                medicationList: previousMedications,
              }
              : patient
          )
        );
      }
    } catch (error) {
      console.error("Failed to delete medication:", error);
      showToast({
        title: "Failed to delete medication",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  async function handleCreateRefillRequest(
    patientId,
    medicationId,
    userId,
    medicationPayload
  ) {
    if (!patientId || !medicationId || !userId) {
      throw new Error("Missing refill request info.");
    }

    const existingPending = refillRequests.some(
      (req) =>
        String(req.patient_id) === String(patientId) &&
        String(req.medication_id) === String(medicationId) &&
        (!req.status || String(req.status).toLowerCase() === "pending")
    );

    if (existingPending) {
      throw new Error("A pending refill request already exists for this medication.");
    }

    const saved = await createRefillRequest(
      patientId,
      medicationId,
      userId,
      medicationPayload
    );

    setRefillRequests((prev) => [saved, ...prev]);

    return saved;
  }

  async function handleDeleteRefillRequest(refillRequestId) {
    if (!refillRequestId) {
      throw new Error("Missing refill request id.");
    }

    const targetRequest = refillRequests.find(
      (req) => String(req.id) === String(refillRequestId)
    );

    if (!targetRequest) {
      throw new Error("Refill request not found.");
    }

    const status = String(targetRequest.status || "pending").toLowerCase();
    if (status !== "pending") {
      throw new Error("Only pending refill requests can be removed.");
    }

    await deleteRefillRequestInSupabase(refillRequestId);

    setRefillRequests((prev) =>
      prev.filter((req) => String(req.id) !== String(refillRequestId))
    );
  }

  async function handleApproveRefillRequestWithPin(
    refillRequestId,
    attendingId,
    pin
  ) {
    if (!refillRequestId) {
      throw new Error("Missing refill request id.");
    }

    if (!attendingId) {
      throw new Error("Please select an attending.");
    }

    if (!pin || pin.length !== 4) {
      throw new Error("PIN must be 4 digits.");
    }

    const attending = profiles.find(
      (profile) => String(profile.id) === String(attendingId)
    );

    if (!attending) {
      throw new Error("Attending not found.");
    }

    if (!attending.signature_pin_set) {
      throw new Error("This attending has not set up a signature PIN yet.");
    }

    const targetRequest = refillRequests.find(
      (req) => String(req.id) === String(refillRequestId)
    );

    if (!targetRequest) {
      throw new Error("Refill request not found.");
    }

    const { data: pinValid, error: pinError } = await supabase.rpc(
      "verify_signature_pin",
      {
        target_user_id: attendingId,
        raw_pin: pin,
      }
    );

    if (pinError) {
      throw new Error(`Could not verify PIN: ${pinError.message}`);
    }

    if (!pinValid) {
      throw new Error("Incorrect PIN.");
    }

    const payload = targetRequest.request_payload || null;

    if (payload) {
      const updatedMedication = await updateMedicationInSupabase(
        targetRequest.medication_id,
        {
          name: payload.name || "",
          dosage: payload.dosage || "",
          frequency: payload.frequency || "",
          route: payload.route || "",
          dispenseAmount: payload.dispenseAmount || "",
          refillCount: payload.refillCount || "",
          instructions: payload.instructions || "",
          isActive: payload.isActive ?? true,
          lastUpdatedEncounterId: null,
        }
      );

      setPatients((prev) =>
        prev.map((patient) =>
          String(patient.id) === String(targetRequest.patient_id)
            ? {
              ...patient,
              medicationList: (patient.medicationList || []).map((med) =>
                String(med.id) === String(targetRequest.medication_id)
                  ? {
                    ...med,
                    name: updatedMedication.name || "",
                    dosage: updatedMedication.dosage || "",
                    frequency: updatedMedication.frequency || "",
                    route: updatedMedication.route || "",
                    dispenseAmount: updatedMedication.dispense_amount ?? "",
                    refillCount: updatedMedication.refill_count ?? "",
                    instructions: updatedMedication.instructions || "",
                    isActive: updatedMedication.is_active ?? true,
                    lastUpdatedEncounterId:
                      updatedMedication.last_updated_encounter_id || null,
                  }
                  : med
              ),
            }
            : patient
        )
      );
    }

    const saved = await approveRefillRequestInSupabase(
      refillRequestId,
      attendingId
    );

    setRefillRequests((prev) =>
      prev.map((req) =>
        req.id === refillRequestId ? saved : req
      )
    );

    return saved;
  }

  async function handleApproveRefillRequestAsSignedInAttending(refillRequestId) {
    if (!refillRequestId) {
      throw new Error("Missing refill request id.");
    }

    if (!session?.user?.id) {
      throw new Error("No signed-in user found.");
    }

    if (userRole !== "attending") {
      throw new Error("Only attendings can use direct refill approval.");
    }

    const attendingId = session.user.id;

    const attending = profiles.find(
      (profile) => String(profile.id) === String(attendingId)
    );

    if (!attending) {
      throw new Error("Signed-in attending not found.");
    }

    const targetRequest = refillRequests.find(
      (req) => String(req.id) === String(refillRequestId)
    );

    if (!targetRequest) {
      throw new Error("Refill request not found.");
    }

    const payload = targetRequest.request_payload || null;

    if (payload) {
      const updatedMedication = await updateMedicationInSupabase(
        targetRequest.medication_id,
        {
          name: payload.name || "",
          dosage: payload.dosage || "",
          frequency: payload.frequency || "",
          route: payload.route || "",
          dispenseAmount: payload.dispenseAmount || "",
          refillCount: payload.refillCount || "",
          instructions: payload.instructions || "",
          isActive: payload.isActive ?? true,
          lastUpdatedEncounterId: null,
        }
      );

      setPatients((prev) =>
        prev.map((patient) =>
          String(patient.id) === String(targetRequest.patient_id)
            ? {
              ...patient,
              medicationList: (patient.medicationList || []).map((med) =>
                String(med.id) === String(targetRequest.medication_id)
                  ? {
                    ...med,
                    name: updatedMedication.name || "",
                    dosage: updatedMedication.dosage || "",
                    frequency: updatedMedication.frequency || "",
                    route: updatedMedication.route || "",
                    dispenseAmount: updatedMedication.dispense_amount ?? "",
                    refillCount: updatedMedication.refill_count ?? "",
                    instructions: updatedMedication.instructions || "",
                    isActive: updatedMedication.is_active ?? true,
                    lastUpdatedEncounterId:
                      updatedMedication.last_updated_encounter_id || null,
                  }
                  : med
              ),
            }
            : patient
        )
      );
    }

    const saved = await approveRefillRequestInSupabase(
      refillRequestId,
      attendingId
    );

    setRefillRequests((prev) =>
      prev.map((req) =>
        req.id === refillRequestId ? saved : req
      )
    );

    return saved;
  }

  async function addOrUpdateAllergy() {
    if (!selectedPatient) return;
    if (!newAllergy.allergen.trim()) return;

    if (editingAllergyId !== null) {
      try {
        await updateAllergyInSupabase(editingAllergyId, newAllergy);

        setPatients((prev) =>
          prev.map((patient) =>
            patient.id === selectedPatient.id
              ? {
                ...patient,
                allergyList: (patient.allergyList || []).map((allergy) =>
                  allergy.id === editingAllergyId
                    ? { ...allergy, ...newAllergy, id: editingAllergyId }
                    : allergy
                ),
              }
              : patient
          )
        );
      } catch (error) {
        console.error("Failed to update allergy:", error);
        showToast({
          title: "Failed to update allergy",
          message: error.message,
          type: "error",
          duration: 5000,
        });
        return;
      }
    } else {
      try {
        const savedAllergy = await createAllergyInSupabase(selectedPatient.id, newAllergy);

        setPatients((prev) =>
          prev.map((patient) =>
            patient.id === selectedPatient.id
              ? {
                ...patient,
                allergyList: [
                  {
                    id: savedAllergy.id,
                    allergen: savedAllergy.allergen || "",
                    reaction: savedAllergy.reaction || "",
                    severity: savedAllergy.severity || "",
                    notes: savedAllergy.notes || "",
                    isActive: savedAllergy.is_active ?? true,
                  },
                  ...(patient.allergyList || []),
                ],
              }
              : patient
          )
        );
      } catch (error) {
        console.error("Failed to create allergy:", error);
        showToast({
          title: "Failed to create allergy",
          message: error.message,
          type: "error",
          duration: 5000,
        });
        return;
      }
    }

    setNewAllergy(EMPTY_ALLERGY);
    setEditingAllergyId(null);
    setShowAllergyModal(false);
  }

  function startEditAllergy(allergy) {
    setNewAllergy({
      allergen: allergy.allergen || "",
      reaction: allergy.reaction || "",
      severity: allergy.severity || "",
      notes: allergy.notes || "",
      isActive: allergy.isActive ?? true,
    });
    setEditingAllergyId(allergy.id);
    setShowAllergyModal(true);
  }

  async function deleteAllergy(allergyId) {
    if (!selectedPatient) return;

    const confirmed = window.confirm("Delete this allergy?");
    if (!confirmed) return;

    try {
      await deleteAllergyInSupabase(allergyId);

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              allergyList: (patient.allergyList || []).filter(
                (allergy) => allergy.id !== allergyId
              ),
            }
            : patient
        )
      );
    } catch (error) {
      console.error("Failed to delete allergy:", error);
      showToast({
        title: "Failed to delete allergy",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  async function saveSoapNote(showConfirmation = true) {
    if (!selectedPatient || !selectedEncounter || !session?.user?.id || !userRole) return;

    const currentSoapStatus = selectedEncounter.soapStatus || "draft";

    const authorId = showConfirmation
      ? session.user.id
      : (selectedEncounter.soapAuthorId || session.user.id);

    const authorRole = showConfirmation
      ? userRole
      : (selectedEncounter.soapAuthorRole || userRole);

    const isOphthoEncounter =
      selectedEncounter?.specialtyType === "ophthalmology";

    const ophtho = {
      ...EMPTY_OPHTHO_NOTE,
      ...(soapDraft.ophthalmologyNote || {}),
    };

    const soapSubjectiveToSave = isOphthoEncounter
      ? ophtho.hpi || ""
      : soapDraft.soapSubjective || "";

    const soapObjectiveToSave = isOphthoEncounter
      ? [
        `Medical / Ocular History:\n${ophtho.ocularHistory || ""}`,
        `VA Distant:\nOD: ${ophtho.vaOd || ""}\nOS: ${ophtho.vaOs || ""}`,
        `PH:\nOD: ${ophtho.phOd || ""}\nOS: ${ophtho.phOs || ""}`,
        `IOP:\nOD: ${ophtho.iopOd || ""}\nOS: ${ophtho.iopOs || ""}`,
        `External:\nOD: ${ophtho.externalOd || ""}\nOS: ${ophtho.externalOs || ""}`,
        `Slit Lamp:\nOD: ${ophtho.slitLampOd || ""}\nOS: ${ophtho.slitLampOs || ""}`,
        `Dilated Fundus Exam:\nOD: ${ophtho.fundusOd || ""}\nOS: ${ophtho.fundusOs || ""}`,
      ].join("\n\n")
      : soapDraft.soapObjective || "";

    const soapAssessmentToSave = isOphthoEncounter
      ? ophtho.assessment || ""
      : soapDraft.soapAssessment || "";

    const soapPlanToSave = isOphthoEncounter
      ? ophtho.plan || ""
      : soapDraft.soapPlan || "";

    try {
      setSoapBusy(true);

      if (showConfirmation) {
        setSoapUiMessage("Saving...");
      }

      await updateEncounterInSupabase(selectedEncounter.id, {
        soapSubjective: soapSubjectiveToSave,
        soapObjective: soapObjectiveToSave,
        soapAssessment: soapAssessmentToSave,
        soapPlan: soapPlanToSave,
        notes: soapDraft.notes || "",
        soapAuthorId: authorId,
        soapAuthorRole: authorRole,
        soapStatus: currentSoapStatus,
        ophthalmologyNote: isOphthoEncounter ? ophtho : null,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    soapSubjective: soapSubjectiveToSave,
                    soapObjective: soapObjectiveToSave,
                    soapAssessment: soapAssessmentToSave,
                    soapPlan: soapPlanToSave,
                    notes: soapDraft.notes || "",
                    soapAuthorId: authorId,
                    soapAuthorRole: authorRole,
                    soapStatus: currentSoapStatus,
                    soapSavedAt: new Date().toLocaleString(),
                    ophthalmologyNote: isOphthoEncounter ? ophtho : null,
                  }
                  : encounter
              ),
            }
            : patient
        )
      );

      if (showConfirmation) {
        showSoapMessage("SOAP note saved.");
      }
    } catch (error) {
      console.error("Failed to save SOAP note:", error);
      showSoapMessage(`Failed to save SOAP note: ${error.message}`);
    } finally {
      setSoapBusy(false);
    }
  }

  async function submitSoapForUpperLevel() {
    if (!selectedPatient || !selectedEncounter || !session?.user?.id || !userRole) return;

    const missingFields = getMissingSoapFields(soapDraft);
    if (missingFields.length > 0) {
      showSoapMessage(`Complete before submitting: ${missingFields.join(", ")}`);
      return false;
    }

    const authorId = selectedEncounter.soapAuthorId || session.user.id;
    const authorRole = selectedEncounter.soapAuthorRole || userRole;

    try {
      setSoapBusy(true);
      setSoapUiMessage("Saving...");

      await updateEncounterInSupabase(selectedEncounter.id, {
        soapSubjective: soapDraft.soapSubjective || "",
        soapObjective: soapDraft.soapObjective || "",
        soapAssessment: soapDraft.soapAssessment || "",
        soapPlan: soapDraft.soapPlan || "",
        notes: soapDraft.notes || "",
        soapAuthorId: authorId,
        soapAuthorRole: authorRole,
        soapStatus: "awaiting_upper",
        ophthalmologyNote:
          selectedEncounter?.specialtyType === "ophthalmology"
            ? {
              ...EMPTY_OPHTHO_NOTE,
              ...(soapDraft.ophthalmologyNote || {}),
            }
            : null,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    soapSubjective: soapDraft.soapSubjective || "",
                    soapObjective: soapDraft.soapObjective || "",
                    soapAssessment: soapDraft.soapAssessment || "",
                    soapPlan: soapDraft.soapPlan || "",
                    notes: soapDraft.notes || "",
                    soapAuthorId: authorId,
                    soapAuthorRole: authorRole,
                    soapStatus: "awaiting_upper",
                    soapSavedAt: new Date().toLocaleString(),
                  }
                  : encounter
              ),
            }
            : patient
        )
      );
      await logAuditEvent("soap_submitted_upper", {
        soapStatus: "awaiting_upper",
      });
      await loadAuditLog();
      showSoapMessage("SOAP note submitted for upper-level signature.");
    } catch (error) {
      console.error("Failed to submit SOAP for upper-level signature:", error);
      showSoapMessage(`Failed to submit SOAP: ${error.message}`);
    } finally {
      setSoapBusy(false);
    }
  }

  async function submitSoapForAttending() {
    if (!selectedPatient || !selectedEncounter || !session?.user?.id || !userRole) return;

    const missingFields = getMissingSoapFields(soapDraft);
    if (missingFields.length > 0) {
      showSoapMessage(`Complete before submitting: ${missingFields.join(", ")}`);
      return;
    }

    const authorId = selectedEncounter.soapAuthorId || session.user.id;
    const authorRole = selectedEncounter.soapAuthorRole || userRole;

    try {
      setSoapBusy(true);
      setSoapUiMessage("Saving...");

      await updateEncounterInSupabase(selectedEncounter.id, {
        soapSubjective: soapDraft.soapSubjective || "",
        soapObjective: soapDraft.soapObjective || "",
        soapAssessment: soapDraft.soapAssessment || "",
        soapPlan: soapDraft.soapPlan || "",
        notes: soapDraft.notes || "",
        soapAuthorId: authorId,
        soapAuthorRole: authorRole,
        soapStatus: "awaiting_attending",
        ophthalmologyNote:
          selectedEncounter?.specialtyType === "ophthalmology"
            ? {
              ...EMPTY_OPHTHO_NOTE,
              ...(soapDraft.ophthalmologyNote || {}),
            }
            : null,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    soapSubjective: soapDraft.soapSubjective || "",
                    soapObjective: soapDraft.soapObjective || "",
                    soapAssessment: soapDraft.soapAssessment || "",
                    soapPlan: soapDraft.soapPlan || "",
                    notes: soapDraft.notes || "",
                    soapAuthorId: authorId,
                    soapAuthorRole: authorRole,
                    soapStatus: "awaiting_attending",
                    soapSavedAt: new Date().toLocaleString(),
                  }
                  : encounter
              ),
            }
            : patient
        )
      );

      await logAuditEvent("soap_submitted_attending", {
        soapStatus: "awaiting_attending",
      });
      await loadAuditLog();
      showSoapMessage("SOAP note submitted for attending signature.");
    } catch (error) {
      console.error("Failed to submit SOAP for attending signature:", error);
      showSoapMessage(`Failed to submit SOAP: ${error.message}`);
    } finally {
      setSoapBusy(false);
    }
  }

  async function signSoapAsUpperLevel() {
    if (!selectedPatient || !selectedEncounter || !session?.user?.id || !userRole) return;
    if (!canSignAsUpperLevel) return;

    const missingFields = getMissingSoapFields(soapDraft);
    if (missingFields.length > 0) {
      showSoapMessage(`Complete before submitting: ${missingFields.join(", ")}`);
      return;
    }

    const authorId = selectedEncounter.soapAuthorId || session.user.id;
    const authorRole = selectedEncounter.soapAuthorRole || userRole;
    const signedAt = new Date().toISOString();

    try {
      setSoapBusy(true);
      setSoapUiMessage("Saving...");

      await updateEncounterInSupabase(selectedEncounter.id, {
        soapSubjective: soapDraft.soapSubjective || "",
        soapObjective: soapDraft.soapObjective || "",
        soapAssessment: soapDraft.soapAssessment || "",
        soapPlan: soapDraft.soapPlan || "",
        notes: soapDraft.notes || "",
        soapAuthorId: authorId,
        soapAuthorRole: authorRole,
        upperLevelSignedBy: session.user.id,
        upperLevelSignedAt: signedAt,
        soapStatus: "awaiting_attending",
        ophthalmologyNote:
          selectedEncounter?.specialtyType === "ophthalmology"
            ? {
              ...EMPTY_OPHTHO_NOTE,
              ...(soapDraft.ophthalmologyNote || {}),
            }
            : null,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    soapSubjective: soapDraft.soapSubjective || "",
                    soapObjective: soapDraft.soapObjective || "",
                    soapAssessment: soapDraft.soapAssessment || "",
                    soapPlan: soapDraft.soapPlan || "",
                    notes: soapDraft.notes || "",
                    soapAuthorId: authorId,
                    soapAuthorRole: authorRole,
                    soapStatus: "awaiting_attending",
                    soapSavedAt: new Date().toLocaleString(),
                  }
                  : encounter
              ),
            }
            : patient
        )
      );
      await logAuditEvent("soap_signed_upper", {
        soapStatus: "awaiting_attending",
        signedAt,
      });
      await loadProfiles();
      await loadAuditLog();
      showSoapMessage("SOAP note signed by upper-level reviewer.");
    } catch (error) {
      console.error("Failed to sign SOAP as upper-level:", error);
      showSoapMessage(`Failed to sign SOAP: ${error.message}`);
    } finally {
      setSoapBusy(false);
    }
  }

  async function setSkipUpperLevelApproval(enabled) {
    if (!selectedPatient || !selectedEncounter || !session?.user?.id) return;
    if (userRole !== "leadership") return;

    if (!!selectedEncounter?.skipUpperLevel === !!enabled) {
      return;
    }

    const hasSoapStarted =
      !!(soapDraft.soapSubjective || "").trim() ||
      !!(soapDraft.soapObjective || "").trim() ||
      !!(soapDraft.soapAssessment || "").trim() ||
      !!(soapDraft.soapPlan || "").trim() ||
      !!(soapDraft.ophthalmologyNote?.hpi || "").trim() ||
      !!(soapDraft.ophthalmologyNote?.ocularHistory || "").trim() ||
      !!(soapDraft.ophthalmologyNote?.assessment || "").trim() ||
      !!(soapDraft.ophthalmologyNote?.plan || "").trim();

    if (enabled && !hasSoapStarted) {
      showToast({
        title: "SOAP not started",
        message: "Start the note before approving Skip Upper Level.",
        type: "warning",
      });
      return;
    }

    const fromSoapStatus = selectedEncounter?.soapStatus || "draft";
    const toSoapStatus = enabled ? "awaiting_attending" : "draft";

    try {
      const nowIso = new Date().toISOString();

      await updateEncounterInSupabase(selectedEncounter.id, {
        skipUpperLevel: enabled,
        skipUpperLevelBy: enabled ? session.user.id : null,
        skipUpperLevelAt: enabled ? nowIso : null,
        soapStatus: toSoapStatus,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    skipUpperLevel: enabled,
                    skipUpperLevelBy: enabled ? session.user.id : null,
                    skipUpperLevelAt: enabled ? nowIso : null,
                    soapStatus: toSoapStatus,
                  }
                  : encounter
              ),
            }
            : patient
        )
      );

      await refreshClinicData();
      setSelectedPatientId(selectedPatient.id);
      setSelectedEncounterId(selectedEncounter.id);

      await logAuditEvent(
        enabled ? "skip_upper_level_approved" : "skip_upper_level_removed",
        {
          fromSoapStatus,
          toSoapStatus,
          bypassedUpperLevel: enabled,
        }
      );

      await loadAuditLog();

      showToast({
        title: enabled ? "Skip Upper Level approved" : "Skip Upper Level removed",
        message: enabled
          ? "This encounter can now bypass upper level and go directly to attending."
          : "This encounter has been returned to the normal upper-level workflow.",
        type: "success",
      });
    } catch (error) {
      console.error("Failed to update skip upper level approval:", error);
      showToast({
        title: "Update failed",
        message: error.message,
        type: "error",
        duration: 5000,
      });
    }
  }

  async function signSoapAsAttending() {
    if (!selectedPatient || !selectedEncounter || !session?.user?.id || !userRole) return;
    if (!canSignAsAttending) return;

    const missingFields = getMissingSoapFields(soapDraft);
    if (missingFields.length > 0) {
      showSoapMessage(`Complete before submitting: ${missingFields.join(", ")}`);
      return;
    }



    const authorId = selectedEncounter.soapAuthorId || session.user.id;
    const authorRole = selectedEncounter.soapAuthorRole || userRole;
    const signedAt = new Date().toISOString();

    try {
      setSoapBusy(true);
      setSoapUiMessage("Saving...");

      await updateEncounterInSupabase(selectedEncounter.id, {
        soapSubjective: soapDraft.soapSubjective || "",
        soapObjective: soapDraft.soapObjective || "",
        soapAssessment: soapDraft.soapAssessment || "",
        soapPlan: soapDraft.soapPlan || "",
        notes: soapDraft.notes || "",
        soapAuthorId: authorId,
        soapAuthorRole: authorRole,
        attendingSignedBy: session.user.id,
        attendingSignedAt: signedAt,
        soapStatus: "signed",
        status: "done",
        ophthalmologyNote:
          selectedEncounter?.specialtyType === "ophthalmology"
            ? {
              ...EMPTY_OPHTHO_NOTE,
              ...(soapDraft.ophthalmologyNote || {}),
            }
            : null,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    soapSubjective: soapDraft.soapSubjective || "",
                    soapObjective: soapDraft.soapObjective || "",
                    soapAssessment: soapDraft.soapAssessment || "",
                    soapPlan: soapDraft.soapPlan || "",
                    notes: soapDraft.notes || "",
                    soapAuthorId: authorId,
                    soapAuthorRole: authorRole,
                    soapStatus: "signed",
                    status: "done",
                    attendingSignedBy: session.user.id,
                    attendingSignedAt: signedAt,
                    soapSavedAt: new Date().toLocaleString(),
                  }
                  : encounter
              ),
            }
            : patient
        )
      );
      await logAuditEvent("soap_signed_attending", {
        soapStatus: "signed",
        signedAt,
      });
      await loadAuditLog();
      showSoapMessage("SOAP note signed by attending.");
      return true;
    } catch (error) {
      console.error("Failed to sign SOAP as attending:", error);
      showSoapMessage(`Failed to sign SOAP: ${error.message}`);
    } finally {
      setSoapBusy(false);
    }
  }


  async function signSoapAsAttendingWithPin(attendingId, pin) {
    if (!selectedPatient || !selectedEncounter) return false;
    if (!attendingId || pin.length !== 4) return false;

    const missingFields = getMissingSoapFields(soapDraft);
    if (missingFields.length > 0) {
      showSoapMessage(`Complete before submitting: ${missingFields.join(", ")}`);
      return;
    }

    try {
      const attending = profiles.find(
        (a) => String(a.id) === String(attendingId)
      );

      if (!attending) {
        showSoapMessage("Attending not found.");
        return false;
      }

      if (!attending.signature_pin_set) {
        showSoapMessage("This attending has not set up a signature PIN yet.");
        return false;
      }

      const { data: pinValid, error: pinError } = await supabase.rpc(
        "verify_signature_pin",
        {
          target_user_id: attendingId,
          raw_pin: pin,
        }
      );

      if (pinError) {
        console.error("PIN verification failed:", pinError);
        showSoapMessage(`Could not verify PIN: ${pinError.message}`);
        return false;
      }

      if (!pinValid) {
        showSoapMessage("Incorrect PIN.");
        return false;
      }

      const authorId = selectedEncounter.soapAuthorId || session?.user?.id;
      const authorRole = selectedEncounter.soapAuthorRole || userRole;
      const signedAt = new Date().toISOString();

      setSoapBusy(true);
      setSoapUiMessage("Saving...");

      await updateEncounterInSupabase(selectedEncounter.id, {
        soapSubjective: soapDraft.soapSubjective || "",
        soapObjective: soapDraft.soapObjective || "",
        soapAssessment: soapDraft.soapAssessment || "",
        soapPlan: soapDraft.soapPlan || "",
        notes: soapDraft.notes || "",
        soapAuthorId: authorId,
        soapAuthorRole: authorRole,
        attendingSignedBy: attending.id,
        attendingSignedAt: signedAt,
        soapStatus: "signed",
        status: "done",
        ophthalmologyNote:
          selectedEncounter?.specialtyType === "ophthalmology"
            ? {
              ...EMPTY_OPHTHO_NOTE,
              ...(soapDraft.ophthalmologyNote || {}),
            }
            : null,
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    soapSubjective: soapDraft.soapSubjective || "",
                    soapObjective: soapDraft.soapObjective || "",
                    soapAssessment: soapDraft.soapAssessment || "",
                    soapPlan: soapDraft.soapPlan || "",
                    notes: soapDraft.notes || "",
                    soapAuthorId: authorId,
                    soapAuthorRole: authorRole,
                    attendingSignedBy: attending.id,
                    attendingSignedAt: signedAt,
                    soapStatus: "signed",
                    status: "done",
                    soapSavedAt: new Date().toLocaleString(),
                  }
                  : encounter
              ),
            }
            : patient
        )
      );

      await createAuditLog({
        encounterId: selectedEncounter.id,
        patientId: selectedPatient.id,
        actorUserId: attending.id,
        actorName: attending.full_name || "Unknown User",
        actorRole: "attending",
        action: "soap_signed_attending",
        details: {
          soapStatus: "signed",
          signedAt,
          signedByPin: true,
        },
      });

      await loadAuditLog();
      showSoapMessage("SOAP note signed by attending.");
      return true;
    } catch (error) {
      console.error("Failed to sign SOAP with PIN:", error);
      showSoapMessage(`Failed to sign SOAP: ${error.message}`);
      return false;
    } finally {
      setSoapBusy(false);
    }
  }

  async function reopenSoapNote() {
    if (!selectedPatient || !selectedEncounter) return;
    if (!canReopenSoap) return;

    try {
      setSoapBusy(true);
      setSoapUiMessage("Reopening...");

      await updateEncounterInSupabase(selectedEncounter.id, {
        attendingSignedBy: null,
        attendingSignedAt: null,
        soapStatus: "awaiting_attending",
      });

      setPatients((prev) =>
        prev.map((patient) =>
          patient.id === selectedPatient.id
            ? {
              ...patient,
              encounters: patient.encounters.map((encounter) =>
                encounter.id === selectedEncounter.id
                  ? {
                    ...encounter,
                    attendingSignedBy: null,
                    attendingSignedAt: null,
                    soapStatus: "awaiting_attending",
                  }
                  : encounter
              ),
            }
            : patient
        )
      );
      await logAuditEvent("soap_reopened", {
        soapStatus: "awaiting_attending",
      });
      await loadAuditLog();
      showSoapMessage("SOAP note reopened.");
    } catch (error) {
      console.error("Failed to reopen SOAP note:", error);
      showSoapMessage(`Failed to reopen SOAP note: ${error.message}`);
    } finally {
      setSoapBusy(false);
    }
  }


  async function exportClinicSummaryToWord() {
    const clinicDateLabel = selectedClinicDate || formatClinicDate();

    const rowsForDate = summaryPatientRows.filter(
      ({ encounter }) =>
        !selectedClinicDate ||
        normalizeClinicDate(encounter.clinicDate) === selectedClinicDate
    );

    const returningRows = rowsForDate.filter(
      ({ encounter }) => encounter.newReturning === "Returning"
    );

    const newRows = rowsForDate.filter(
      ({ encounter }) => encounter.newReturning === "New"
    );

    const tableBorders = {
      top: { style: "single", size: 1, color: "000000" },
      bottom: { style: "single", size: 1, color: "000000" },
      left: { style: "single", size: 1, color: "000000" },
      right: { style: "single", size: 1, color: "000000" },
      insideHorizontal: { style: "single", size: 1, color: "000000" },
      insideVertical: { style: "single", size: 1, color: "000000" },
    };

    function headerCell(text) {
      return new TableCell({
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text, bold: true })],
          }),
        ],
      });
    }

    function bodyCell(text, align = AlignmentType.LEFT) {
      return new TableCell({
        children: [
          new Paragraph({
            alignment: align,
            children: [new TextRun(String(text ?? ""))],
          }),
        ],
      });
    }

    function blankStaffSideCell() {
      return new TableCell({
        columnSpan: 2,
        children: [new Paragraph({ text: "" })],
      });
    }
    function formatDobForSummary(dob) {
      if (!dob) return "";

      const parts = String(dob).split("-");
      if (parts.length === 3) {
        const [year, month, day] = parts;
        return `${month}-${day}-${year}`;
      }

      return String(dob).replaceAll("/", "-");
    }

    function formatClinicSummaryDateForWord(dateValue) {
      return formatDobForSummary(dateValue || formatClinicDate());
    }

    function patientTableRows(items) {
      return [
        new TableRow({
          children: [
            headerCell("MRN"),
            headerCell("NAME"),
            headerCell("DOB"),
            headerCell("INSURANCE?"),
          ],
        }),
        ...items.map(({ patient }) =>
          new TableRow({
            children: [
              bodyCell(patient.mrn || "", AlignmentType.CENTER),
              bodyCell(getFullPatientName(patient) || "", AlignmentType.LEFT),
              bodyCell(formatDobForSummary(patient.dob) || "", AlignmentType.CENTER),
              bodyCell("", AlignmentType.CENTER),
            ],
          })
        ),
      ];
    }

    const summaryTable = new Table({
      width: {
        size: 100,
        type: WidthType.PERCENTAGE,
      },
      borders: tableBorders,
      rows: [
        new TableRow({
          children: [
            new TableCell({
              columnSpan: 2,
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: [new TextRun({ text: "Clinic Staff", bold: true })],
                }),
              ],
            }),
            new TableCell({
              columnSpan: 2,
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: [new TextRun({ text: "Clinic Numbers", bold: true })],
                }),
              ],
            }),
          ],
        }),

        new TableRow({
          children: [
            bodyCell("Attendings"),
            bodyCell(clinicSummary.attendingNames || ""),
            bodyCell("Returning"),
            bodyCell(returningPatientCount, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            bodyCell("Residents:"),
            bodyCell(clinicSummary.residentNames || ""),
            bodyCell("New"),
            bodyCell(newPatientCount, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            bodyCell("MS3 / MS4"),
            bodyCell(clinicSummary.ms34Names || ""),
            bodyCell("Refill"),
            bodyCell(clinicSummary.refillCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            bodyCell("MS1 / MS2"),
            bodyCell(clinicSummary.ms12Names || ""),
            bodyCell("LWOBS"),
            bodyCell(clinicSummary.lwobsCount || "", AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Labs"),
            bodyCell(clinicSummary.labsCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Mental Health"),
            bodyCell(clinicSummary.mentalHealthCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Addiction Medicine"),
            bodyCell(clinicSummary.addictionMedicineCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Physical Therapy"),
            bodyCell(clinicSummary.ptCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Dermatology"),
            bodyCell(clinicSummary.dermatologyCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Ophthalmology"),
            bodyCell(clinicSummary.ophthalmologyCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Social Work"),
            bodyCell(clinicSummary.socialWorkCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Zoom"),
            bodyCell(clinicSummary.zoomCount ?? 0, AlignmentType.CENTER),
          ],
        }),
        new TableRow({
          children: [
            blankStaffSideCell(),
            bodyCell("Phone"),
            bodyCell(clinicSummary.phoneCount ?? 0, AlignmentType.CENTER),
          ],
        }),
      ],
    });



    const doc = new Document({
      sections: [
        {
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: `Patients Seen: ${formatClinicSummaryDateForWord(clinicDateLabel)}`,
                  bold: true,
                  underline: {},
                }),
              ],
            }),

            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new TextRun({ text: "RETURNING PATIENTS", bold: true })],
            }),

            new Table({
              width: {
                size: 100,
                type: WidthType.PERCENTAGE,
              },
              borders: tableBorders,
              rows: patientTableRows(returningRows),
            }),

            new Paragraph({ text: "" }),

            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new TextRun({ text: "NEW PATIENTS", bold: true })],
            }),

            new Table({
              width: {
                size: 100,
                type: WidthType.PERCENTAGE,
              },
              borders: tableBorders,
              rows: patientTableRows(newRows),
            }),

            new Paragraph({ text: "" }),

            summaryTable,
          ],
        },
      ],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `Clinic Summary - ${clinicDateLabel}.docx`);
  }

  async function handleResetUserPassword(email) {
    if (!email) {
      setProfilesMessage("This user does not have an email saved.");
      return;
    }

    try {
      setProfilesMessage("");
      await sendPasswordReset(email);
      setProfilesMessage(`Password reset email sent to ${email}.`);
    } catch (error) {
      console.error("Failed to send password reset:", error);
      setProfilesMessage(`Failed to send password reset: ${error.message}`);
    }
  }

  async function handleDeleteUser(userId) {
    const confirmText = prompt(
      "Type DELETE to confirm removing this user permanently:"
    );

    if (confirmText !== "DELETE") return;

    try {
      const {
        data: { session: currentSession },
      } = await supabase.auth.getSession();

      if (!currentSession?.access_token) {
        throw new Error("Your session expired. Please sign out and sign back in.");
      }

      const { data, error } = await supabase.functions.invoke("delete-user", {
        body: { userId },
        headers: {
          Authorization: `Bearer ${currentSession.access_token}`,
        },
      });

      if (error) {
        let details = null;

        try {
          details = await error.context.json();
        } catch {
          details = null;
        }

        throw new Error(details?.error || error.message || "Delete failed");
      }

      setProfiles((prev) => prev.filter((p) => p.id !== userId));
      setProfilesMessage("User deleted successfully.");
    } catch (error) {
      console.error("Failed to delete user:", error);
      alert(error.message);
    }
  }

  const lastVisitLabel =
    selectedPatient && sortedSelectedPatientEncounters.length > 1
      ? formatDate(
        normalizeClinicDate(sortedSelectedPatientEncounters[1]?.clinicDate) ||
        sortedSelectedPatientEncounters[1]?.clinicDate
      )
      : "No prior visit";

  if (session && needsOnboarding) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
        <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow">
          <h2 className="mb-2 text-xl font-semibold text-slate-900">
            Complete Your Profile
          </h2>

          <p className="mb-5 text-sm text-slate-600">
            Finish setting up your account before entering the app.
          </p>

          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                Full Name
              </label>
              <input
                className="w-full rounded-lg border px-3 py-3 text-sm"
                value={onboardingFullName}
                onChange={(e) => setOnboardingFullName(e.target.value)}
                placeholder="Enter your full name"
              />
            </div>


            {userRole === "student" || userRole === "upper_level" ? (
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  Classification
                </label>
                <select
                  className="w-full rounded-lg border px-3 py-3 text-sm"
                  value={onboardingClassification}
                  onChange={(e) => setOnboardingClassification(e.target.value)}
                >
                  <option value="">Select classification</option>
                  <option value="MS1">MS1</option>
                  <option value="MS2">MS2</option>
                  <option value="MS3">MS3</option>
                  <option value="MS4">MS4</option>
                </select>
              </div>
            ) : null}

            {authMessage ? (
              <div className="rounded-lg bg-slate-100 px-3 py-2 text-sm text-slate-700">
                {authMessage}
              </div>
            ) : null}

            <button
              onClick={handleCompleteOnboarding}
              disabled={authLoading}
              className="w-full rounded-lg bg-blue-600 px-4 py-3 text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {authLoading ? "Saving..." : "Finish Setup"}
            </button>

            <button
              onClick={handleSignOut}
              disabled={authLoading}
              className="w-full rounded-lg bg-slate-200 px-4 py-3 text-slate-700 hover:bg-slate-300 disabled:cursor-not-allowed disabled:opacity-60"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-slate-100">
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/50 px-4">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl">
            <div className="mb-6 text-center">
              <h1 className="text-2xl font-semibold text-slate-900">FC EMR</h1>
              <p className="mt-2 text-sm text-slate-600">
                Log in to continue or create your account if this is your first time here.
              </p>
            </div>

            <div className="mb-6 flex rounded-xl bg-slate-100 p-1">
              <button
                onClick={() => setAuthMode("login")}
                className={`flex-1 rounded-lg px-4 py-2 text-sm font-medium ${authMode === "login"
                  ? "bg-white text-slate-900 shadow-sm"
                  : "text-slate-600"
                  }`}
              >
                Log In
              </button>
              <button
                onClick={() => setAuthMode("signup")}
                className={`flex-1 rounded-lg px-4 py-2 text-sm font-medium ${authMode === "signup"
                  ? "bg-white text-slate-900 shadow-sm"
                  : "text-slate-600"
                  }`}
              >
                First-Time Sign Up
              </button>
            </div>

            <div className="space-y-4">
              {authMode === "signup" ? (
                <>
                  <input
                    className="w-full rounded-lg border px-3 py-3 text-sm"
                    placeholder="Full name"
                    value={authFullName}
                    onChange={(e) => setAuthFullName(e.target.value)}
                  />

                  <select
                    className="w-full rounded-lg border px-3 py-3 text-sm"
                    value={authRole}
                    onChange={(e) => setAuthRole(e.target.value)}
                  >
                    <option value="">Select role</option>
                    <option value="student">Student</option>
                    <option value="upper_level">Upper Level</option>
                    <option value="attending">Attending</option>
                    <option value="leadership">Leadership</option>
                    <option value="undergraduate">Undergraduate</option>
                    <option value="pharmacy">Pharmacy</option>
                    <option value="lab">Lab</option>
                    <option value="social_work">Social Work</option>
                  </select>

                  {authRole === "student" || authRole === "upper_level" ? (
                    <select
                      className="w-full rounded-lg border px-3 py-3 text-sm"
                      value={authClassification}
                      onChange={(e) => setAuthClassification(e.target.value)}
                    >
                      <option value="">Select classification</option>
                      <option value="MS1">MS1</option>
                      <option value="MS2">MS2</option>
                      <option value="MS3">MS3</option>
                      <option value="MS4">MS4</option>
                    </select>
                  ) : null}

                  {authRole === "attending" ? (
                    <>
                      <input
                        type="password"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        autoComplete="new-password"
                        autoCorrect="off"
                        autoCapitalize="off"
                        spellCheck={false}
                        maxLength={4}
                        className="w-full rounded-lg border px-3 py-3 text-sm"
                        placeholder="4-digit PIN"
                        value={authPin}
                        onChange={(e) =>
                          setAuthPin(e.target.value.replace(/\D/g, "").slice(0, 4))
                        }
                      />

                      <input
                        type="password"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        autoComplete="new-password"
                        autoCorrect="off"
                        autoCapitalize="off"
                        spellCheck={false}
                        maxLength={4}
                        className="w-full rounded-lg border px-3 py-3 text-sm"
                        placeholder="Confirm 4-digit PIN"
                        value={authPinConfirm}
                        onChange={(e) =>
                          setAuthPinConfirm(e.target.value.replace(/\D/g, "").slice(0, 4))
                        }
                      />
                    </>
                  ) : null}
                </>
              ) : null}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  authMode === "login" ? handleSignIn() : handleSignUp();
                }}
              >
                <input
                  className="w-full rounded-lg border px-3 py-3 text-sm"
                  placeholder="Email"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                />

                <input
                  className="w-full rounded-lg border px-3 py-3 text-sm"
                  placeholder="Password"
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                />

                {authMessage ? (
                  <div className="rounded-lg bg-slate-100 px-3 py-2 text-sm text-slate-700">
                    {authMessage}
                  </div>
                ) : null}

                {authMode === "login" ? (
                  <button
                    type="submit"
                    onClick={handleSignIn}
                    disabled={authLoading}
                    className="w-full rounded-lg bg-blue-600 px-4 py-3 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {authLoading ? "Signing In..." : "Log In"}
                  </button>
                ) : (
                  <button
                    type="submit"
                    onClick={handleSignUp}
                    disabled={authLoading}
                    className="w-full rounded-lg bg-slate-800 px-4 py-3 text-sm font-medium text-white hover:bg-slate-900 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {authLoading ? "Creating Account..." : "Create Account"}
                  </button>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }


  if (isBoardDisplayMode) {
    return (
      <BoardDisplay
        ROOM_OPTIONS={ROOM_OPTIONS}
        canOpenCharts={userRole !== "lab"}
        roomMap={roomMap}
        getPatientBoardName={getPatientBoardName}
        getStudentBoardName={getStudentBoardName}
        spanishBadge={spanishBadge}
        htnBadge={htnBadge}
        priorityBadge={priorityBadge}
        newReturningBadge={newReturningBadge}
        elevatorBadge={elevatorBadge}
        diabetesBadge={diabetesBadge}
        fluBadge={fluBadge}
        papBadge={papBadge}
        getStatusClasses={getStatusClasses}
        allEncounterRows={boardEncounterRows}
        todayStaffRoster={todayStaffRoster}
        selectedClinicDate={boardClinicDate}
        tonightSpecialtyNames={tonightSpecialtyNames}
        tonightReservedRooms={tonightReservedRooms}

      />
    );
  }


  return (
    <div className="min-h-screen bg-slate-100 xl:flex">
      <AppSidebar
        activeView={activeView}
        setActiveView={setActiveView}
        setIsEditingIntake={setIsEditingIntake}
        setEditingPatientId={setEditingPatientId}
        setIntakeForm={setIntakeForm}
        setIntakeTab={setIntakeTab}
        setShowIntakeModal={setShowIntakeModal}
        EMPTY_FORM={EMPTY_FORM}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        isLeadershipView={isLeadershipView}
        userRole={userRole}
        canRefillAccess={canRefillAccess}
        canLabQueueAccess={canLabQueueAccess}
        canProgramsAccess={canAccessPrograms}
      />

      <div className="min-w-0 flex-1 bg-slate-100 xl:ml-64 xl:flex xl:flex-col">
        <AppHeader
          activeView={activeView}
          selectedPatient={selectedPatient}
          getFullPatientName={getFullPatientName}
          formatDate={formatDate}
          user={session?.user}
          userRole={userRole}
          handleResetSession={handleResetSession}
          isLeadershipView={isLeadershipView}
          setIsLeadershipView={setIsLeadershipView}
          setIsEditingIntake={setIsEditingIntake}
          setEditingPatientId={setEditingPatientId}
          setIntakeForm={setIntakeForm}
          setIntakeTab={setIntakeTab}
          setShowIntakeModal={setShowIntakeModal}
          EMPTY_FORM={EMPTY_FORM}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />

        {activeView === "lab-import" && (
          <div className="mb-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex flex-col gap-3">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Lab Import</h3>
                <p className="text-sm text-slate-600">
                  Upload a PDF/image for OCR or paste outside lab text below.
                </p>
              </div>

              <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-4">
                <label className="block text-sm font-medium text-slate-700">
                  Upload lab PDF or image
                </label>

                <input
                  type="file"
                  accept="application/pdf,image/*"
                  className="mt-2 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      handleGoogleOCRImport(file);
                    }
                    e.target.value = "";
                  }}
                />

                {ocrUploading && (
                  <p className="mt-2 text-sm text-blue-700">Running OCR...</p>
                )}

                {ocrError && (
                  <p className="mt-2 text-sm text-red-600">{ocrError}</p>
                )}
              </div>

              <textarea
                value={labImportRawText}
                onChange={(e) => setLabImportRawText(e.target.value)}
                placeholder="Paste labs or upload PDF above..."
                className="min-h-[220px] w-full rounded-xl border border-slate-300 px-3 py-3 text-sm text-slate-900"
              />

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={handleParseLabImportText}
                  disabled={ocrUploading}
                  className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
                >
                  Parse Labs
                </button>

                <button
                  onClick={() => {
                    setLabImportRawText("");
                    setLabImportPacket(null);
                    setLabImportPackets([]);
                    setSelectedLabImportPacketId(null);
                    setOcrError("");
                  }}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  Clear
                </button>
              </div>
            </div>
          </div>
        )}



        <div>
          {activeView === "dashboard" && (
            <DashboardView
              isLeadershipView={isLeadershipView}
              canViewAnalytics={
                isLeadershipView || userRole === "undergraduate" || userRole === "attending"
              }
              canEditMrn={userRole === "undergraduate" || isLeadershipView}
              canEditUndergradFields={userRole === "undergraduate" || isLeadershipView}
              canEditAllPatientFields={isLeadershipView}
              canEditPatient={isLeadershipView}
              canDeletePatient={isLeadershipView}
              deletePatientCompletely={deletePatientCompletely}
              openPatientEditModal={openPatientEditModal}
              dashboardSelectedPatient={dashboardSelectedPatient}
              selectedClinicDate={selectedClinicDate}
              setSelectedClinicDate={setSelectedClinicDate}
              filteredVisiblePatients={filteredVisiblePatients}
              visibleEncounterRows={visibleEncounterRows}
              allEncounterRows={allEncounterRows}
              searchForm={searchForm}
              setSearchForm={setSearchForm}
              patientRecordsTitle={patientRecordsTitle}
              openPatientFromFilteredView={openPatientFromFilteredView}
              getFullPatientName={getFullPatientName}
              finalizeClinicDay={finalizeClinicDay}
            />
          )}

          {activeView === "lab-import" && (
            <LabImportView
              packet={labImportPacket}
              packets={labImportPackets}
              selectedPacketId={selectedLabImportPacketId}
              onSelectPacket={handleSelectLabImportPacket}
              onChangeLabs={handleLiveUpdateLabPacketLabs}
              onAfterSaveCleanup={cleanupSavedLabImportPacket}
              onBack={() => {
                setActiveView("dashboard");
              }}
              onExportDebug={handleExportLabDebug}
              onConfirmPatient={(packetId, patient) => {
                if (!packetId || !patient) return;
                handleConfirmLabImportPatient(packetId, patient);
              }}
              onSkip={() => {
                if (!labImportPacket?.packetId) return;
                handleSkipLabImportPacket(labImportPacket.packetId);
              }}
              onSave={async (reviewedLabs, encounterId) => {
                if (!labImportPacket || !labImportPacket.confirmedPatient || !encounterId) {
                  alert("Pick a patient and encounter first.");
                  return;
                }

                try {
                  await updateEncounterInSupabase(encounterId, {
                    importedSendOutLabs: reviewedLabs,
                  });

                  const savedAt = new Date().toISOString();

                  await updateSharedLabImportPacket(labImportPacket.packetId, {
                    parsed_labs_json: reviewedLabs,
                    matched_patient_id: labImportPacket.confirmedPatient.id,
                    matched_encounter_id: encounterId,
                    review_status: "saved",
                    saved_at: savedAt,
                    suspicious_count: (reviewedLabs || []).filter((lab) => !!lab?.suspicious).length,
                    missing_count: (reviewedLabs || []).filter((lab) => !!lab?.missing || !!lab?.autoFilled).length,
                    total_lab_count: (reviewedLabs || []).length,
                  });

                  setLabImportPackets((prev) =>
                    prev.map((packet) =>
                      packet.packetId === labImportPacket.packetId
                        ? {
                          ...packet,
                          labs: reviewedLabs,
                          reviewStatus: "saved",
                          savedAt,
                          matchedEncounterId: encounterId,
                        }
                        : packet
                    )
                  );

                  setLabImportPacket((prev) =>
                    prev && prev.packetId === labImportPacket.packetId
                      ? {
                        ...prev,
                        labs: reviewedLabs,
                        reviewStatus: "saved",
                        savedAt,
                        matchedEncounterId: encounterId,
                      }
                      : prev
                  );

                  await loadSharedLabImportBatch(activeLabImportBatchId || null);

                  showToast({
                    title: "Labs saved",
                    message: "Imported labs were saved successfully.",
                    type: "success",
                  });
                } catch (error) {
                  console.error("Failed to save imported labs:", error);
                  alert(`Failed to save imported labs: ${error.message}`);
                }
              }}
            />
          )}

          {activeView === "registration" && (
            <RegistrationView
              registrationRows={registrationRows}
              selectedClinicDate={selectedClinicDate}
              setSelectedClinicDate={setSelectedClinicDate}
              openUndergradRegistration={openUndergradRegistration}
              openLeadershipRegistration={openLeadershipRegistration}
              getFullPatientName={getFullPatientName}
              formatDate={formatDate}
              newReturningBadge={newReturningBadge}
              dualVisitBadge={dualVisitBadge}
              userRole={userRole}
              isLeadershipView={isLeadershipView}
              onRemoveFromRegistration={removeFromRegistration}
              clinicResourceSettings={clinicResourceSettings}
              onSaveClinicResourceSetting={saveClinicResourceSetting}
            />
          )}

          {activeView === "undergrad-intake" && (userRole === "undergraduate" || isLeadershipView) && (
            <UndergradIntakeView
              onSave={handleUndergradStartEncounter}
              patients={patients}
              tonightSpecialtyNames={tonightSpecialtyNames}
            />
          )}


          {activeView === "lab-queue" && userRole === "lab" && (
            <LabQueueView
              labEncounterRows={labEncounterRows}
              selectedClinicDate={labQueueDate}
              setSelectedClinicDate={setLabQueueDate}
              openPatientChart={openPatientChart}
              getFullPatientName={getFullPatientName}
              onUpdateLabTracking={updateLabTracking}
            />
          )}

          {(activeView === "queue" || activeView === "pharmacy-queue") && (
            <QueueView
              queueMode={activeView === "pharmacy-queue" ? "pharmacy" : "general"}
              userRole={userRole}
              searchForm={searchForm}
              waitingEncounterRows={waitingEncounterRows}
              selectedClinicDate={queueClinicDate}
              setSelectedClinicDate={setQueueClinicDate}
              openPatientChart={openPatientChart}
              getPatientBoardName={getPatientBoardName}
              spanishBadge={spanishBadge}
              priorityBadge={priorityBadge}
              newReturningBadge={newReturningBadge}
              diabetesBadge={diabetesBadge}
              htnBadge={htnBadge}
              elevatorBadge={elevatorBadge}
              fluBadge={fluBadge}
              papBadge={papBadge}
              dualVisitBadge={dualVisitBadge}
              formatWaitTime={formatWaitTime}
              studentNameOptions={studentNameOptions}
              upperLevelNameOptions={upperLevelNameOptions}
              activeStudents={activeStudents}
              activeUpperLevels={activeUpperLevels}
              ROOM_OPTIONS={roomDropdownOptions}
              onAssignFromQueue={assignEncounterFromQueue}
              onMarkMedicationsReady={markMedicationsReady}
              onMarkPatientSentToPharmacy={markPatientSentToPharmacy}
              onClearPharmacyStatus={clearPharmacyStatus}
              onMarkMedicationsPickedUp={markMedicationsPickedUp}
              refillRequests={refillRequests}
              canRefill={canRefill}
              patients={patients}
              activeAttendings={activeAttendings}
              onApproveRefillRequest={handleApproveRefillRequestWithPin}
              profileNameMap={profileNameMap}
              onApproveRefillAsSignedInAttending={handleApproveRefillRequestAsSignedInAttending}
              onDeleteRefillRequest={handleDeleteRefillRequest}
              programEntries={programEntries}
              specialtyAccess={currentSpecialtyAccess}
              papEntries={papEntries}

            />
          )}

          {activeView === "specialty-queue" && canAccessSpecialtyQueue && (
            <SpecialtyQueueView
              specialtyEncounterRows={specialtyEncounterRows}
              openPatientChart={openPatientChart}
              getFullPatientName={getFullPatientName}
              formatDate={formatDate}
              isLeadershipView={isLeadershipView}
              dualVisitBadge={dualVisitBadge}
              selectedClinicDate={specialtyQueueDate}
              setSelectedClinicDate={setSpecialtyQueueDate}
            />
          )}

          {activeView === "board" && (
            <RoomBoard
              ROOM_OPTIONS={ROOM_OPTIONS}
              selectedClinicDate={boardClinicDate}
              setSelectedClinicDate={setRoomBoardDate}
              canOpenCharts={userRole !== "lab"}
              roomMap={roomMap}
              allEncounterRows={boardEncounterRows}
              assignedCount={assignedCount}
              inVisitCount={inVisitCount}
              getPatientBoardName={getPatientBoardName}
              getStudentBoardName={getStudentBoardName}
              spanishBadge={spanishBadge}
              priorityBadge={priorityBadge}
              newReturningBadge={newReturningBadge}
              elevatorBadge={elevatorBadge}
              diabetesBadge={diabetesBadge}
              htnBadge={htnBadge}
              fluBadge={fluBadge}
              papBadge={papBadge}
              getStatusClasses={getStatusClasses}
              assignEncounterToRoom={assignEncounterToRoom}
              selectedPatient={selectedPatient}
              selectedEncounter={selectedEncounter}
              openPatientChart={openPatientChart}
              isLeadershipView={canManageRooms}
              SPECIALTY_ROOM_RULES={specialtyRoomRulesForBoard}
              todayStaffRoster={todayStaffRoster}
              onTodayStaffRosterChange={setTodayStaffRoster}
              onTodayStaffRosterSave={handleSaveTodayStaffRoster}
              tonightSpecialtyNames={tonightSpecialtyNames}
              tonightReservedRooms={tonightReservedRooms}
            />
          )}
          {activeView === "formulary" && (
            <FormularyView
              formulary={formulary}
              onAddMedication={addFormularyItem}
              onEditMedication={editFormularyItem}
              onDeleteMedication={removeFormularyItem}
              onToggleStock={toggleFormularyStock}
              onPrescribeMedication={prescribeFromFormulary}
              selectedPatient={selectedPatient}
              isLeadershipView={canModifyFormulary}
            />
          )}

          {activeView === "users" && isLeadershipView && (
            <UserManagementView
              profiles={filteredProfiles}
              loadingProfiles={loadingProfiles}
              savingProfileId={savingProfileId}
              onChangeRole={handleChangeProfileRole}
              onRefresh={loadProfiles}
              currentUserId={session?.user?.id || null}
              message={profilesMessage}
              userSearch={userSearch}
              setUserSearch={setUserSearch}
              editingProfileNameId={editingProfileNameId}
              setEditingProfileNameId={setEditingProfileNameId}
              editingProfileNameValue={editingProfileNameValue}
              setEditingProfileNameValue={setEditingProfileNameValue}
              onSaveProfileName={handleSaveProfileName}
              showOnlyActiveToday={showOnlyActiveToday}
              setShowOnlyActiveToday={setShowOnlyActiveToday}
              onApproveUser={handleApproveUser}
              onDeleteUser={handleDeleteUser}
              onResetPassword={handleResetUserPassword}
            />
          )}

          {activeView === "chart" && selectedPatient && (
            <ChartView
              selectedPatient={selectedPatient}
              selectedEncounter={selectedEncounter}
              selectedEncounterId={selectedEncounterId}
              normalizeClinicDate={normalizeClinicDate}
              setActiveView={setActiveView}
              startNewEncounter={startNewEncounter}
              deleteEncounter={deleteEncounter}
              canStartEncounter={userRole === "leadership" || userRole === "undergraduate"}
              openEditIntake={openEditIntake}
              isLeadershipView={isLeadershipView}
              getFullPatientName={getFullPatientName}
              lastVisitLabel={lastVisitLabel}
              openPatientChart={openPatientChart}
              spanishBadge={spanishBadge}
              papBadge={papBadge}
              dualVisitBadge={dualVisitBadge}
              pharmacyStatusBadge={pharmacyStatusBadge}
              diabetesBadge={diabetesBadge}
              elevatorBadge={elevatorBadge}
              fluBadge={fluBadge}
              priorityBadge={priorityBadge}
              newReturningBadge={newReturningBadge}
              assignmentForm={assignmentForm}
              setAssignmentForm={setAssignmentForm}
              studentNameOptions={studentNameOptions}
              assignedStudentNames={assignedStudentNames}
              upperLevelNameOptions={upperLevelNameOptions}
              ROOM_OPTIONS={roomDropdownOptions}
              isPapRestricted={isPapRestricted}
              assignEncounter={assignEncounter}
              leadershipActionLocked={leadershipActionLocked}
              updateEncounterStatus={updateEncounterStatus}
              clearEncounterRoom={clearEncounterRoom}
              sortedMedications={sortedMedications}
              activeMedicationCount={activeMedicationCount}
              toggleMedicationActive={toggleMedicationActive}
              startEditMedication={startEditMedication}
              deleteMedication={deleteMedication}
              setEditingMedicationId={setEditingMedicationId}
              setNewMedication={setNewMedication}
              setShowMedicationModal={setShowMedicationModal}
              EMPTY_MEDICATION={EMPTY_MEDICATION}
              startEditAllergy={startEditAllergy}
              deleteAllergy={deleteAllergy}
              setShowAllergyModal={setShowAllergyModal}
              setEditingAllergyId={setEditingAllergyId}
              setNewAllergy={setNewAllergy}
              EMPTY_ALLERGY={EMPTY_ALLERGY}
              updatePatientField={updatePatientField}
              currentVitals={currentVitals}
              updateVitalsField={updateVitalsField}
              saveVitals={saveVitals}
              saveInHouseLabs={saveInHouseLabs}
              saveSendOutLabs={saveSendOutLabs}
              editingVitalsIndex={editingVitalsIndex}
              startEditVitals={startEditVitals}
              saveSoapNote={saveSoapNote}
              soapAutoSaveEnabled={true}
              updateEncounterField={updateEncounterField}
              saveEncounterField={saveEncounterField}
              formatDate={formatDate}
              soapStatus={selectedEncounter?.soapStatus || "draft"}
              canSignAsUpperLevel={canSignAsUpperLevel}
              canSignAsAttending={canSignAsAttending}
              signSoapAsUpperLevel={signSoapAsUpperLevel}
              signSoapAsAttending={signSoapAsAttending}
              canSubmitForUpperLevel={canSubmitForUpperLevel}
              canSubmitForAttending={canSubmitForAttending}
              submitSoapForUpperLevel={submitSoapForUpperLevel}
              submitSoapForAttending={submitSoapForAttending}
              soapBusy={soapBusy}
              soapUiMessage={soapUiMessage}
              formatRoleLabel={formatRoleLabel}
              canReopenSoap={canReopenSoap}
              reopenSoapNote={reopenSoapNote}
              auditEntries={auditEntries}
              auditLoading={auditLoading}
              soapAuthorName={soapAuthorName}
              upperLevelSignerName={upperLevelSignerName}
              attendingSignerName={attendingSignerName}
              activeStudents={activeStudents}
              activeUpperLevels={activeUpperLevels}
              activeAttendings={activeAttendings}
              signSoapAsAttendingWithPin={signSoapAsAttendingWithPin}
              soapDraft={soapDraft}
              updateSoapDraftField={updateSoapDraftField}
              openPatientEditModal={openPatientEditModal}
              canRefill={canRefill}
              currentUserId={session?.user?.id}
              onStartRefillRequest={startRefillRequest}
              refillRequests={refillRequests}
              profileNameMap={profileNameMap}
              setSkipUpperLevelApproval={setSkipUpperLevelApproval}
            />
          )}

          <ToastStack toasts={toasts} onDismiss={dismissToast} />

          {activeView === "summary" && isLeadershipView && (
            <ClinicSummaryView
              selectedClinicDate={selectedClinicDate}
              setSelectedClinicDate={setSelectedClinicDate}
              clinicSummary={clinicSummary}
              setClinicSummary={setClinicSummary}
              newPatientCount={newPatientCount}
              returningPatientCount={returningPatientCount}
              totalPatientCount={totalPatientCount}
              exportClinicSummaryToWord={exportClinicSummaryToWord}
              specialtyCounts={specialtyCounts}
              autoLwobsCount={autoLwobsCount}
              autoRefillPatientCount={autoRefillPatientCount}
              onRefreshSummary={refreshClinicSummaryData}
              summaryRefreshStatus={summaryRefreshStatus}
            />
          )}

          {activeView === "programs" && canAccessPrograms && (
            <ProgramsView
              programEntries={programEntries}
              addProgramEntry={addProgramEntry}
              updateProgramEntry={updateProgramEntry}
              removeProgramEntry={removeProgramEntry}
              patients={patients}
              selectedClinicDate={selectedClinicDate}
              isLeadershipView={isLeadershipView}
              specialtyAccess={currentSpecialtyAccess}
              leadershipOptions={profiles
                .filter((profile) => profile.role === "leadership")
                .map((profile) => (profile.full_name || "").trim())
                .filter(Boolean)
                .sort((a, b) => a.localeCompare(b))}
            />
          )}

          {activeView === "pap" && isLeadershipView && (
            <PAPView
              papEntries={papEntries}
              addPapEntry={addPapEntry}
              updatePapEntry={updatePapEntry}
              removePapEntry={removePapEntry}
              patients={patients}
              leadershipOptions={profiles
                .filter((profile) => profile.role === "leadership")
                .map((profile) => (profile.full_name || "").trim())
                .filter(Boolean)
                .sort((a, b) => a.localeCompare(b))}
            />
          )}

        </div>
      </div>


      <MedicationModal
        showMedicationModal={showMedicationModal}
        selectedPatient={selectedPatient}
        editingMedicationId={editingMedicationId}
        newMedication={newMedication}
        setNewMedication={setNewMedication}
        setShowMedicationModal={(value) => {
          setShowMedicationModal(value);
          if (!value) {
            setIsRefillRequestMode(false);
            setRefillSourceMedicationId(null);
            setEditingMedicationId(null);
            setNewMedication(EMPTY_MEDICATION);
          }
        }}
        setEditingMedicationId={setEditingMedicationId}
        addOrUpdateMedication={isRefillRequestMode ? submitRefillRequestFromModal : addOrUpdateMedication}
        EMPTY_MEDICATION={EMPTY_MEDICATION}
        isRefillRequestMode={isRefillRequestMode}
      />
      <AllergyModal
        showAllergyModal={showAllergyModal}
        selectedPatient={selectedPatient}
        editingAllergyId={editingAllergyId}
        newAllergy={newAllergy}
        setNewAllergy={setNewAllergy}
        setShowAllergyModal={setShowAllergyModal}
        setEditingAllergyId={setEditingAllergyId}
        addOrUpdateAllergy={addOrUpdateAllergy}
        EMPTY_ALLERGY={EMPTY_ALLERGY}
      />

      <IntakeModal
        showIntakeModal={showIntakeModal}
        setShowIntakeModal={setShowIntakeModal}
        intakeTab={intakeTab}
        setIntakeTab={setIntakeTab}
        intakeForm={intakeForm}
        updateIntakeField={updateIntakeField}
        submitPatient={submitPatient}
        isSubmittingIntake={isSubmittingIntake}
        isEditingIntake={isEditingIntake}
        intakeMatchPatientId={intakeMatchPatientId}
        intakeMatchedPatient={intakeMatchedPatient}
        autoFilledMatchPatientId={autoFilledMatchPatientId}
        applyMatchedPatientToIntake={applyMatchedPatientToIntake}
        clinicResourceSettings={clinicResourceSettings}
        programEntries={programEntries}
      />

      <UndergradRegistrationModal
        show={showUndergradRegistrationModal}
        form={undergradRegistrationForm}
        setForm={setUndergradRegistrationForm}
        onClose={() => {
          setShowUndergradRegistrationModal(false);
          setRegistrationPatientId(null);
          setRegistrationEncounterId(null);
          setUndergradRegistrationForm(EMPTY_UNDERGRAD_REGISTRATION_FORM);
        }}
        onSubmit={saveUndergradRegistration}
        tonightSpecialtyNames={tonightSpecialtyNames}
      />

      <PatientInfoEditModal
        show={showPatientInfoEditModal}
        patient={dashboardSelectedPatient || selectedPatient}
        selectedEncounter={selectedEncounter}
        canEditUndergradFields={userRole === "undergraduate" || isLeadershipView}
        canEditAllPatientFields={isLeadershipView}
        canEditEncounterFields={userRole === "undergraduate" || isLeadershipView}
        onClose={() => setShowPatientInfoEditModal(false)}
        onSave={async (patientId, updates, encounterId, encounterUpdates) => {
          await saveDashboardPatientEdits(patientId, updates, encounterId, encounterUpdates);
          setShowPatientInfoEditModal(false);
        }}
      />
    </div>
  );
}