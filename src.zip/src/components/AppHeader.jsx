export default function AppHeader({
  activeView,
  selectedPatient,
  getFullPatientName,
  formatDate,
  user,
  userRole,
  handleResetSession,
  isLeadershipView,
  setIsEditingIntake,
  setEditingPatientId,
  setIntakeForm,
  setIntakeTab,
  setShowIntakeModal,
  EMPTY_FORM,
  sidebarOpen,
  setSidebarOpen,
}) {
  return (
    <div className="sticky top-0 z-40 border-b bg-white shadow-sm">
      <div className="flex flex-col gap-3 px-4 py-4 sm:px-6">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="rounded-lg border border-slate-300 px-3 py-2 text-slate-700 lg:hidden"
            >
              ☰
            </button>

            <div className="min-w-0">
              <h2 className="truncate text-lg font-semibold text-slate-800 sm:text-2xl">
                {activeView === "dashboard" && "Clinic Dashboard"}
                {activeView === "queue" && "Live Waiting Queue"}
                {activeView === "board" && "Main Room Board"}
                {activeView === "formulary" && "Clinic Formulary"}
                {activeView === "chart" ? "Patient Chart" : ""}
              </h2>

              <p className="text-sm text-slate-500">
                {new Date().toLocaleDateString()}
              </p>

              {activeView === "chart" && selectedPatient && (
                <p className="mt-1 text-xs text-slate-500 sm:text-sm">
                  {getFullPatientName(selectedPatient)} • MRN {selectedPatient.mrn || "—"}
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">

          <div className="flex items-center gap-3">
            <div className="text-sm">
              <p className="font-medium text-slate-800">
                {user?.user_metadata?.full_name || "User"}
              </p>
              <p className="text-xs text-slate-500 capitalize">
                {userRole?.replace("_", " ")}
              </p>
            </div>

            <span className="rounded-full bg-slate-200 px-3 py-1 text-xs font-medium text-slate-700 capitalize">
              {userRole?.replace("_", " ")}
            </span>

            <button
              onClick={handleResetSession}
              className="rounded-lg bg-yellow-500 px-3 py-2 text-xs text-white hover:bg-yellow-600"
            >
              Refresh Session
            </button>
          </div>

          {userRole === "leadership" && (
            <button
              onClick={() => {
                const url = `${window.location.origin}${window.location.pathname}?display=board`;
                window.open(url, "_blank", "width=1600,height=900");
              }}
              className="rounded-lg bg-slate-700 px-4 py-2 text-white hover:bg-slate-800"
            >
              Open Display Board
            </button>
          )}
          {userRole === "leadership" && (
            <button
              onClick={() => {
                setIsEditingIntake(false);
                setEditingPatientId(null);
                setIntakeForm(EMPTY_FORM);
                setIntakeTab(0);
                setShowIntakeModal(true);
              }}
              className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              + Add Patient
            </button>
          )}
        </div>
      </div>
    </div>
  );
}